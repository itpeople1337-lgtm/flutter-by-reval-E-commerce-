import 'package:cloud_firestore/cloud_firestore.dart';

class CategoryModel {
  late String categoryId, name, selectedType;

  CategoryModel({
    required this.categoryId,
    required this.name,
    required this.selectedType,
  });

  factory CategoryModel.fromJson(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return CategoryModel(
      categoryId: doc.id,
      name: data['name'],
      selectedType: data['selectedType'],
    );
  }

  toJson() {
    return {
      'categoryId': categoryId,
      'name': name,
      'selectedType': selectedType,
    };
  }
}

extension NumberParsing on String {
  double toDouble() {
    return double.parse(this);
  }
}
