/////////////////////////////// 0 ////////////////////////////////
class ExpensesReportModel {
  late String id;
  late DateTime date;
  late String expenseType;
  late double amount;

  ExpensesReportModel({
    required this.id,
    required this.date,
    required this.expenseType,
    required this.amount,
  });

  // Convert the model to a map for Firestore
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'date': date,
      'expenseType': expenseType,
      'amount': amount,
    };
  }

  // Create a factory method to convert Firestore data to the model
  factory ExpensesReportModel.fromMap(Map<String, dynamic> map) {
    return ExpensesReportModel(
      id: map['id'],
      date: map['date'],
      expenseType: map['expenseType'],
      amount: map['amount'],
    );
  }
}

class ProfitLoss {
  String month;
  double totalPurchases;
  double totalSales;
  double totalExpenses;
  double profit;

  ProfitLoss({
    required this.month,
    required this.totalPurchases,
    required this.totalSales,
    required this.totalExpenses,
    this.profit = 0.0,
  });

  void calculateProfit() {
    profit = totalSales - totalPurchases - totalExpenses;
  }
}

//////////////////////////////////////////////////////
class Sales {
  String type;
  double totalSales;

  Sales({
    required this.type,
    required this.totalSales,
  });
}

/////////////////////////////////////////////////////
class TransactionsModel {
  late String id;
  late DateTime date;
  late double amount;
  late String type;
  late String productName;
  late String description;

  TransactionsModel({
    required this.id,
    required this.date,
    required this.type,
    required this.productName,
    required this.description,
    required this.amount,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'date': date,
      'type': type,
      'productName': productName,
      'description': description,
      'amount': amount,
    };
  }

  factory TransactionsModel.fromMap(Map<String, dynamic> map) {
    return TransactionsModel(
      id: map['id'],
      date: map['date'],
      type: map['type'],
      productName: map['productName'],
      description: map['description'],
      amount: map['amount'],
    );
  }
}

///////////////////////////// 4 ///////////////////////////////////
class PurchasesSupplierModel {
  late String id;
  late String name;
  late double totalPurchases;

  PurchasesSupplierModel({
    required this.id,
    required this.name,
    required this.totalPurchases,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'totalPurchases': totalPurchases,
    };
  }

  factory PurchasesSupplierModel.fromMap(Map<String, dynamic> map) {
    return PurchasesSupplierModel(
      id: map['id'],
      name: map['name'],
      totalPurchases: map['totalPurchases'],
    );
  }
}

//////////////////////////// 6 ////////////////////////////////////
class DebtsCustomerModel {
  late String id;
  late String customerID;
  late String customerName;
  late double totalDebts;

  DebtsCustomerModel({
    required this.id,
    required this.customerID,
    required this.customerName,
    required this.totalDebts,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customerID': customerID,
      'customerName': customerName,
      'totalDebts': totalDebts,
    };
  }

  factory DebtsCustomerModel.fromMap(Map<String, dynamic> map) {
    return DebtsCustomerModel(
      id: map['id'],
      customerID: map['customerID'],
      customerName: map['customerName'],
      totalDebts: map['totalDebts'],
    );
  }
}

//////////////////////////// 7 ////////////////////////////////////
class DebtsSupplierModel {
  late String id;
  late String supplierID;
  late String supplierName;
  late double totalDebts;

  DebtsSupplierModel({
    required this.id,
    required this.supplierID,
    required this.supplierName,
    required this.totalDebts,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'supplierID': supplierID,
      'supplierName': supplierName,
      'totalDebts': totalDebts,
    };
  }

  factory DebtsSupplierModel.fromMap(Map<String, dynamic> map) {
    return DebtsSupplierModel(
      id: map['id'],
      supplierID: map['supplierID'],
      supplierName: map['supplierName'],
      totalDebts: map['totalDebts'],
    );
  }
}

///////////////////////////// 12/ ///////////////////////////////////
class RecorderReportModel {
  late String id;
  late String action;
  late String description;
  late DateTime date;

  RecorderReportModel({
    required this.id,
    required this.action,
    required this.description,
    required this.date,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'action': action,
      'description': description,
      'date': date,
    };
  }

  factory RecorderReportModel.fromMap(Map<String, dynamic> map) {
    return RecorderReportModel(
      id: map['id'],
      action: map['action'],
      description: map['description'],
      date: map['date'],
    );
  }
}
