import 'package:cloud_firestore/cloud_firestore.dart';

class StoreModel {
  late String storeId, name;

  StoreModel({
    required this.storeId,
    required this.name,
  });

  factory StoreModel.fromJson(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return StoreModel(
      storeId: doc.id,
      name: data['name'],
    );
  }

  toJson() {
    return {
      'storeId': storeId,
      'name': name,
    };
  }
}

extension NumberParsing on String {
  double toDouble() {
    return double.parse(this);
  }
}
