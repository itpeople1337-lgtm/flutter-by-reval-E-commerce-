import 'package:cloud_firestore/cloud_firestore.dart';

class DebtsModel {
  late String clientName,
      clientType,
      amountReceived,
      totalDebt,
      remainingDebt,
      date,
      notes,
      docId;

  DebtsModel({
    required this.clientName,
    required this.clientType,
    required this.date,
    required this.amountReceived,
    required this.remainingDebt,
    required this.notes,
    required this.docId,
    required this.totalDebt,
  });

  factory DebtsModel.fromJson(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return DebtsModel(
      docId: doc.id,
      clientName: data['clientName'],
      date: data['date'],
      clientType: data['clientType'],
      amountReceived: data['amountReceived'],
      remainingDebt: data['remainingDebt'],
      notes: data['notes'],
      totalDebt: data['totalDebt'],
    );
  }

  toJson() {
    return {
      'docId': docId,
      'date': date,
      'clientName': clientName,
      'clientType': clientType,
      'amountReceived': amountReceived,
      'remainingDebt': remainingDebt,
      'notes': notes,
      'totalDebt': totalDebt,
    };
  }
}

extension NumberParsing on String {
  double toDouble() {
    return double.parse(this);
  }
}
