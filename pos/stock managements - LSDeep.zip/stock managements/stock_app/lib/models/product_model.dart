import 'package:cloud_firestore/cloud_firestore.dart';

class ProductModel {
  late String name,
      details,
      sellingprice,
      purchaseprice,
      barcode,
      quantity,
      image,
      productId;
  late String category;
  late String color;
  late String storeName;
  late String date;

//
  ProductModel({
    required this.name,
    required this.date,
    required this.details,
    required this.sellingprice,
    required this.purchaseprice,
    required this.color,
    required this.quantity,
    required this.barcode,
    required this.productId,
    required this.category,
    required this.image,
    required this.storeName,
  });

  factory ProductModel.fromJson(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    // final DateTime dateTime = (data['date'] as Timestamp).toDate();
    return ProductModel(
      productId: doc.id,
      name: data['name'],
      storeName: data['storeName'],
      date: data['date'],
      details: data['details'],
      image: data['image'],
      sellingprice: data['sellingprice'],
      purchaseprice: data['purchaseprice'],
      color: data['colors'],
      barcode: data['barcode'],
      category: data['category'],
      quantity: data['quantity'],
    );
  }

  toJson() {
    return {
      'name': name,
      'image': image,
      'storeName': storeName,
      'date': date,
      'barcode': barcode,
      'details': details,
      'quantity': quantity,
      'colors': color,
      'sellingprice': sellingprice,
      'purchaseprice': purchaseprice,
      'productId': productId,
      'category': category,
    };
  }
}

extension NumberParsing on String {
  double toDouble() {
    return double.parse(this);
  }
}
