import 'package:cloud_firestore/cloud_firestore.dart';

class ExpenseModel {
  late String amount, name, store, expenseId, category;
  DateTime date;

  ExpenseModel({
    required this.expenseId,
    required this.name,
    required this.amount,
    required this.date,
    required this.category,
    required this.store,
  });

  factory ExpenseModel.fromJson(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return ExpenseModel(
      expenseId: doc.id,
      name: data['name'],
      amount: data['amount'],
      date: (data['date'] as Timestamp).toDate(),
      category: data['category'],
      store: data['store'],
    );
  }

  toJson() {
    return {
      'expenseId': expenseId,
      'name': name,
      'amount': amount,
      'date': date,
      'category': category,
      'store': store,
    };
  }
}

extension NumberParsing on String {
  double toDouble() {
    return double.parse(this);
  }
}
