import 'package:cloud_firestore/cloud_firestore.dart';

class InOutModel {
  late String clientName, docNo, docType, docId, details;
  late double quantity, price;

  DateTime date;
  // List ids;

  InOutModel({
    required this.clientName,
    required this.date,
    required this.docNo,
    required this.quantity,
    required this.price,
    required this.docType,
    required this.docId,
    required this.details,
    //  required this.ids,
  });

  factory InOutModel.fromJson(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return InOutModel(
      docId: doc.id,
      clientName: data['clientName'],
      // date: data['date'],
      date: (data['date'] as Timestamp).toDate(),
      docNo: data['docNo'],
      quantity: data['quantity'],
      price: data['price'],
      docType: data['docType'],
      details: data['details'],
      // ids: data['ids'],
    );
  }

  toJson() {
    return {
      'docId': docId,
      'date': date,
      'clientName': clientName,
      'docNo': docNo,
      'quantity': quantity,
      'price': price,
      'docType': docType,
      'details': details,
      // 'ids': ids,
    };
  }
}

extension NumberParsing on String {
  double toDouble() {
    return double.parse(this);
  }
}
