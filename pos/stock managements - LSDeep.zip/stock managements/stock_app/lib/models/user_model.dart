// import 'chat_model.dart';

import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel {
  late String? userId, email, name, pic, aboutMe;
  //DateTime? lastMessageTime;

  UserModel({
    this.userId,
    this.email,
    this.name,
    this.pic,
    //  this.lastMessageTime,
  });

  UserModel.fromJson(Map<dynamic, dynamic> map) {
    userId = map['userId'];
    email = map['email'];
    name = map['name'];
    pic = map['pic'];
  }

  toJson() {
    return {
      'userId': userId,
      'email': email,
      'name': name,
      'pic': pic,
    };
  }
}

class CompanyInfoModel {
  String? id;
  late String companyName, companyAddress, companyEmail, image, companySign;

  CompanyInfoModel({
    this.id,
    required this.companyName,
    required this.companyAddress,
    required this.companyEmail,
    required this.image,
    required this.companySign,
  });

  factory CompanyInfoModel.fromJson(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return CompanyInfoModel(
      id: doc.id,
      companyName: data['companyName'],
      companyAddress: data['companyAddress'],
      companyEmail: data['companyEmail'],
      companySign: data['companySign'],
      image: data['image'],
    );
  }

  toJson() {
    return {
      'companyName': companyName,
      'companyAddress': companyAddress,
      'companyEmail': companyEmail,
      'image': image,
      'companySign': companySign,
    };
  }
}
