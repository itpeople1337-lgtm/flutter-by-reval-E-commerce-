import 'package:cloud_firestore/cloud_firestore.dart';

class SupplierModel {
  late String name,
      address,
      email,
      phone,
      textId,
      notes,
      bankDetails,
      supplierId;

  SupplierModel({
    required this.supplierId,
    required this.name,
    required this.address,
    required this.email,
    required this.phone,
    required this.textId,
    required this.notes,
    required this.bankDetails,
  });

  factory SupplierModel.fromJson(DocumentSnapshot doc) {
    Map data = doc.data() as Map<String, dynamic>;
    return SupplierModel(
      supplierId: doc.id,
      name: data['name'],
      address: data['address'],
      email: data['email'],
      phone: data['phone'],
      textId: data['textId'],
      notes: data['notes'],
      bankDetails: data['bankDetails'],
    );
  }

  toJson() {
    return {
      'supplierId': supplierId,
      'name': name,
      'address': address,
      'email': email,
      'phone': phone,
      'textId': textId,
      'notes': notes,
      'bankDetails': bankDetails,
    };
  }
}

extension NumberParsing on String {
  double toDouble() {
    return double.parse(this);
  }
}
