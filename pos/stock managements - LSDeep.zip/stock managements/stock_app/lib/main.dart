import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:stock_app/controllers/localization_controller.dart';
import 'package:stock_app/core/helper/binding.dart';
import 'package:stock_app/core/localiization/translations.dart';
import 'package:stock_app/firebase_options.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/services/db/db_helper.dart';
import 'package:stock_app/services/local_services.dart';
import 'package:stock_app/views/control_view.dart';
import 'package:sizer/sizer.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: []);
  await initServices();
  await DBHelper.initDb();
  runApp(const MyApp());
}

//  Get.to(() => Page())
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    final controller = Get.put(LocalController());
    debugInvertOversizedImages = true;

    return Sizer(
      builder: (context, orientation, deviceType) => GetMaterialApp(
        defaultTransition: Transition.fadeIn,
        initialBinding: Binding(),
        theme: controller.appTheme,
        home: const ControlView(),
        debugShowCheckedModeBanner: false,
        title: 'Stock Management', //Text(LocaleKeys.title).tr()
        getPages: AppPages.routes,
        translations: MyTranslations(),
        locale: controller.language,
      ),
    );
  }
}

///   - flutter clean

 //- flutter build apk --release

// - flutter install
