import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:stock_app/models/product_model.dart';

class ProductService {
  // final CollectionReference _productsCollection =
  //     FirebaseFirestore.instance.collection('Products');

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

//get all products
  // Future<List<QueryDocumentSnapshot>> getProductsFromFirestore() async {
  //   var products = await _firestore.collection('Products').get();
  //   return products.docs;
  // }

  Future<List<ProductModel>> getProductsFromFirestore() async {
    var snapshot = await _firestore.collection('products').get();

    return snapshot.docs.map((doc) => ProductModel.fromJson(doc)).toList();
    // return products.docs;
  }

  Future<void> updateProductInFirestore(ProductModel updatedProduct) async {
    try {
      await FirebaseFirestore.instance
          .collection('products')
          .doc(updatedProduct.productId)
          .update(updatedProduct.toJson());
    } catch (e) {
      print('Error updating product: $e');
      // Handle the error as needed
    }
  }

  Future<void> deleteProductFromFirestore(String productId) async {
    try {
      await FirebaseFirestore.instance
          .collection('products')
          .doc(productId)
          .delete();
    } catch (e) {
      print('Error deleting product: $e');
      // Handle the error as needed
    }
  }

  /// flash sale products
  Future<List<ProductModel>> getProductsByFlash() async {
    var snapshot = await _firestore
        .collection('Products')
        .orderBy('flash', descending: true)
        .limit(10)
        .get();
    return snapshot.docs.map((doc) => ProductModel.fromJson(doc)).toList();
    // return products.docs;
  }

  /// best Selling products
  Future<List<ProductModel>> getProductsByBestSales() async {
    var snapshot = await _firestore
        .collection('Products')
        .orderBy('soldCount', descending: true)
        .limit(10)
        .get();
    return snapshot.docs.map((doc) => ProductModel.fromJson(doc)).toList();
    // return products.docs;
  }

  /// new products
  Future<List<ProductModel>> getProductsByNew() async {
    var snapshot = await _firestore
        .collection('Products')
        .orderBy('createdAt', descending: true)
        .limit(10)
        .get();
    return snapshot.docs.map((doc) => ProductModel.fromJson(doc)).toList();
    // return products.docs;
  }

  /// recomended products
  Future<List<ProductModel>> getProductsByRecomended() async {
    var snapshot = await _firestore
        .collection('Products')
        .orderBy('rating', descending: true)
        .limit(10)
        .get();
    return snapshot.docs.map((doc) => ProductModel.fromJson(doc)).toList();
    // return products.docs;
  }
}
