import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:stock_app/models/customer_model.dart';

class CustomerServices {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<CustomerModel>> getCustomersIdFromFirestore() async {
    var snapshot = await _firestore.collection('customers').get();
    return snapshot.docs.map((doc) => CustomerModel.fromJson(doc)).toList();
    // return products.docs;
  }

  Future<void> updateCustomerIdInFirestore(
      CustomerModel updatedCustomer) async {
    try {
      await FirebaseFirestore.instance
          .collection('customers')
          .doc(updatedCustomer.customerId)
          .update(updatedCustomer.toJson());
    } catch (e) {
      print('Error updating customer: $e');
      // Handle the error as needed
    }
  }

  Future<void> deleteCustomerIdFromFirestore(String customerId) async {
    try {
      await FirebaseFirestore.instance
          .collection('customers')
          .doc(customerId)
          .delete();
    } catch (e) {
      print('Error deleting customer: $e');
      // Handle the error as needed
    }
  }
}
