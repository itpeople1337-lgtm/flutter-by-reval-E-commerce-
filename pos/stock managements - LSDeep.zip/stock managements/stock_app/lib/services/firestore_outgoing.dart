import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:stock_app/models/in_out_model.dart';

class OutgoingServices {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<InOutModel>> getOutgoingProductsFromFirestore() async {
    var snapshot = await _firestore
        .collection('outgoing')
        //  .where('docType', isEqualTo: 'Outgoing')
        .get();
    return snapshot.docs.map((doc) => InOutModel.fromJson(doc)).toList();
    // return products.docs;
  }

  Future<void> updateOutgoingInFirestore(InOutModel updatedInOutModel) async {
    try {
      await FirebaseFirestore.instance
          .collection('outgoing')
          .doc(updatedInOutModel.docId)
          .update(updatedInOutModel.toJson());
    } catch (e) {
      print('Error updating outgoing: $e');
      // Handle the error as needed
    }
  }

  Future<void> deleteOutgoingFromFirestore(String docId) async {
    try {
      await FirebaseFirestore.instance
          .collection('outgoing')
          .doc(docId)
          .delete();
    } catch (e) {
      print('Error deleting outgoing: $e');
      // Handle the error as needed
    }
  }
}
