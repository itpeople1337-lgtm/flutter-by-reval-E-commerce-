import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:stock_app/models/supplier_model.dart';

class SupplierServices {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<SupplierModel>> getSuppliersFromFirestore() async {
    var snapshot = await _firestore.collection('suppliers').get();

    return snapshot.docs.map((doc) => SupplierModel.fromJson(doc)).toList();
    // return products.docs;
  }

  Future<void> updateSupplierInFirestore(SupplierModel updatedSupplier) async {
    try {
      await FirebaseFirestore.instance
          .collection('suppliers')
          .doc(updatedSupplier.supplierId)
          .update(updatedSupplier.toJson());
    } catch (e) {
      print('Error updating Supplier: $e');
      // Handle the error as needed
    }
  }

  Future<void> deleteSupplierFromFirestore(String supplierId) async {
    try {
      await FirebaseFirestore.instance
          .collection('suppliers')
          .doc(supplierId)
          .delete();
    } catch (e) {
      print('Error Supplier product: $e');
      // Handle the error as needed
    }
  }
}
