import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:stock_app/models/debts_model.dart';

class DebtsServices {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<DebtsModel>> getDebtsCustomersFromFirestore() async {
    var snapshot = await _firestore
        .collection('debts')
        .where('clientType', isEqualTo: 'Customer')
        .get();

    return snapshot.docs.map((doc) => DebtsModel.fromJson(doc)).toList();
    // return products.docs;
  }

  Future<List<DebtsModel>> getDebtsSuppliersFromFirestore() async {
    var snapshot = await _firestore
        .collection('debts')
        .where('clientType', isEqualTo: 'Supplier')
        .get();

    return snapshot.docs.map((doc) => DebtsModel.fromJson(doc)).toList();
    // return products.docs;
  }

  Future<void> updateDebtsInFirestore(DebtsModel updatedDebtsModel) async {
    try {
      await FirebaseFirestore.instance
          .collection('debts')
          .doc(updatedDebtsModel.docId)
          .update(updatedDebtsModel.toJson());
    } catch (e) {
      print('Error updating debts: $e');
      // Handle the error as needed
    }
  }

  Future<void> deleteDebtsFromFirestore(String docId) async {
    try {
      await FirebaseFirestore.instance.collection('debts').doc(docId).delete();
    } catch (e) {
      print('Error deleting debts: $e');
      // Handle the error as needed
    }
  }
}
