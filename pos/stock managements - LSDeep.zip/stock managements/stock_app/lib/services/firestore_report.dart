import 'package:cloud_firestore/cloud_firestore.dart';

class FireStoreReport {
  CollectionReference<Map<String, dynamic>> getReportsCollection() {
    return FirebaseFirestore.instance.collection('reports');
  }

//////////////////////////////////////////////////////////////////////////////
  CollectionReference<Map<String, dynamic>> getExpensesCollection(
      String reportId) {
    return getReportsCollection().doc(reportId).collection('Expenses');
  }

  CollectionReference<Map<String, dynamic>> getTransactionsCollection(
      String reportId) {
    return getReportsCollection().doc(reportId).collection('Transactions');
  }

  CollectionReference<Map<String, dynamic>> getPurchasesSupplierCollection(
      String reportId) {
    return getReportsCollection().doc(reportId).collection('PurchasesSupplier');
  }

  CollectionReference<Map<String, dynamic>> getStockMovementCollection(
      String reportId) {
    return getReportsCollection().doc(reportId).collection('StockMovement');
  }

  CollectionReference<Map<String, dynamic>> getDebtsCustomerCollection(
      String reportId) {
    return getReportsCollection().doc(reportId).collection('DebtsCustomer');
  }

  CollectionReference<Map<String, dynamic>> getDebtsSupplierCollection(
      String reportId) {
    return getReportsCollection().doc(reportId).collection('DebtsSupplier');
  }

  CollectionReference<Map<String, dynamic>> getRecorderReportsCollection(
      String reportId) {
    return getReportsCollection().doc(reportId).collection('RecorderReport');
  }
}
