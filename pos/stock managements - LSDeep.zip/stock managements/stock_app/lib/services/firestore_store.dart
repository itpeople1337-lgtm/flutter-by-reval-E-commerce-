import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:stock_app/models/store_model.dart';

class StoreServices {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<StoreModel>> getStoreIdFromFirestore() async {
    var snapshot = await _firestore.collection('stores').get();
    return snapshot.docs.map((doc) => StoreModel.fromJson(doc)).toList();
  }

  Future<void> updateStoreIdInFirestore(StoreModel updatedStore) async {
    try {
      await FirebaseFirestore.instance
          .collection('stores')
          .doc(updatedStore.storeId)
          .update(updatedStore.toJson());
    } catch (e) {
      print('Error updating stores: $e');
    }
  }

  Future<void> deleteStoreIdFromFirestore(String storeId) async {
    try {
      await FirebaseFirestore.instance
          .collection('stores')
          .doc(storeId)
          .delete();
    } catch (e) {
      print('Error deleting stores: $e');
      // Handle the error as needed
    }
  }
}
