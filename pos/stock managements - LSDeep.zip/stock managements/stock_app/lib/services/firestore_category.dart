import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:stock_app/models/category_model.dart';

class CategoryServices {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<CategoryModel>> getCategoryByProductIdFromFirestore() async {
    var snapshot = await _firestore
        .collection('categories')
        .where('selectedType', isEqualTo: 'Products')
        .get();
    return snapshot.docs.map((doc) => CategoryModel.fromJson(doc)).toList();
  }

  Future<List<CategoryModel>> getCategoryByExpenseIdFromFirestore() async {
    var snapshot = await _firestore
        .collection('categories')
        .where('selectedType', isEqualTo: 'Expenses')
        .get();
    return snapshot.docs.map((doc) => CategoryModel.fromJson(doc)).toList();
  }

  Future<void> updateCategoryIdInFirestore(
      CategoryModel updatedCategory) async {
    try {
      await FirebaseFirestore.instance
          .collection('categories')
          .doc(updatedCategory.categoryId)
          .update(updatedCategory.toJson());
    } catch (e) {
      print('Error updating categories: $e');
    }
  }

  Future<void> deleteCategoryIdFromFirestore(String categoryId) async {
    try {
      await FirebaseFirestore.instance
          .collection('categories')
          .doc(categoryId)
          .delete();
    } catch (e) {
      print('Error deleting categories: $e');
      // Handle the error as needed
    }
  }
}
