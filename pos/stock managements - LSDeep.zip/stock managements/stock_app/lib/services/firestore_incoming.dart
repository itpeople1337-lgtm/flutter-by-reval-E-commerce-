import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:stock_app/models/in_out_model.dart';

class IncomingServices {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<InOutModel>> getIncomingProductsFromFirestore() async {
    var snapshot = await _firestore
        .collection('incoming')
        // .where('docType', isEqualTo: 'Incoming')
        .get();

    return snapshot.docs.map((doc) => InOutModel.fromJson(doc)).toList();
  }

  Future<void> updateIncomingInFirestore(InOutModel updatedInOutModel) async {
    try {
      await FirebaseFirestore.instance
          .collection('incoming')
          .doc(updatedInOutModel.docId)
          .update(updatedInOutModel.toJson());
    } catch (e) {
      print('Error updating incoming: $e');
      // Handle the error as needed
    }
  }

  Future<void> deleteIncomingFromFirestore(String docId) async {
    try {
      await FirebaseFirestore.instance
          .collection('incoming')
          .doc(docId)
          .delete();
    } catch (e) {
      print('Error deleting incoming: $e');
      // Handle the error as needed
    }
  }
}
