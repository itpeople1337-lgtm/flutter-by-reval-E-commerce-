import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:stock_app/models/expense_model.dart';

class ExpenseServices {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<ExpenseModel>> getExpensesIdFromFirestore() async {
    var snapshot = await _firestore.collection('expenses').get();
    return snapshot.docs.map((doc) => ExpenseModel.fromJson(doc)).toList();
    // return products.docs;
  }

  Future<void> updateExpenseIdInFirestore(ExpenseModel updatedExpense) async {
    try {
      await FirebaseFirestore.instance
          .collection('expenses')
          .doc(updatedExpense.expenseId)
          .update(updatedExpense.toJson());
    } catch (e) {
      print('Error updating expense: $e');
      // Handle the error as needed
    }
  }

  Future<void> deleteExpenseIdFromFirestore(String expenseId) async {
    try {
      await FirebaseFirestore.instance
          .collection('expenses')
          .doc(expenseId)
          .delete();
    } catch (e) {
      print('Error deleting expense: $e');
      // Handle the error as needed
    }
  }
}
