import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stock_app/controllers/report_controller.dart';

// ignore: must_be_immutable
class Chart extends StatelessWidget {
  Chart({super.key});

  final ReportsController controller = Get.put(ReportsController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(10),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                margin: const EdgeInsets.symmetric(vertical: 10),
                color: Colors.green[50],
                child: Text(
                  '165'.tr,
                  style: const TextStyle(fontSize: 20),
                ),
              ),
              // Obx(
              //   () =>
              AspectRatio(
                aspectRatio: 1,
                child: BarChart(
                  BarChartData(
                      titlesData: FlTitlesData(
                        rightTitles: AxisTitles(
                          axisNameSize: 30,
                          axisNameWidget: Text('168'.tr),
                        ),
                        topTitles: AxisTitles(
                          axisNameSize: 30,
                          axisNameWidget: Text('169'.tr),
                        ),
                      ),
                      borderData: FlBorderData(
                        border: const Border(
                          top: BorderSide.none,
                          right: BorderSide.none,
                          left: BorderSide(width: 1),
                          bottom: BorderSide(width: 1),
                        ),
                      ),
                      groupsSpace: 10,
                      barGroups: [
                        // for (var i = 0;
                        //     i < controller.salesListMonth.length;
                        //     i++) ...[
                        //   BarChartGroupData(
                        //     x: i + 1,
                        //     barRods: [
                        //       BarChartRodData(
                        //         toY: controller.salesListMonth[i].totalSales /
                        //             100, //50,
                        //         fromY: 0,
                        //         width: 10,
                        //         color: Colors.amber,
                        //       ),
                        //     ],
                        //   ),
                        // ],
// here uncomment the above values and comment under vales to calculate real result
                        BarChartGroupData(
                          x: 1,
                          barRods: [
                            BarChartRodData(
                              toY: 50,
                              fromY: 0,
                              width: 10,
                              color: Colors.amber,
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 2,
                          barRods: [
                            BarChartRodData(
                              toY: 100,
                              fromY: 0,
                              width: 10,
                              color: Colors.amber,
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 3,
                          barRods: [
                            BarChartRodData(
                              toY: 200,
                              fromY: 0,
                              width: 10,
                              color: Colors.amber,
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 4,
                          barRods: [
                            BarChartRodData(
                              toY: 110,
                              fromY: 0,
                              width: 10,
                              color: Colors.amber,
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 5,
                          barRods: [
                            BarChartRodData(
                              toY: 150,
                              fromY: 0,
                              width: 10,
                              color: Colors.amber,
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 6,
                          barRods: [
                            BarChartRodData(
                              toY: 180,
                              fromY: 0,
                              width: 10,
                              color: Colors.amber,
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 7,
                          barRods: [
                            BarChartRodData(
                              toY: 140,
                              fromY: 0,
                              width: 10,
                              color: Colors.amber,
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 8,
                          barRods: [
                            BarChartRodData(
                              toY: 190,
                              fromY: 0,
                              width: 10,
                              color: Colors.amber,
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 9,
                          barRods: [
                            BarChartRodData(
                              toY: 240,
                              fromY: 0,
                              width: 10,
                              color: Colors.amber,
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 10,
                          barRods: [
                            BarChartRodData(
                              toY: 211,
                              fromY: 0,
                              width: 10,
                              color: Colors.amber,
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 11,
                          barRods: [
                            BarChartRodData(
                              toY: 178,
                              fromY: 0,
                              width: 10,
                              color: Colors.amber,
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 12,
                          barRods: [
                            BarChartRodData(
                              toY: 190,
                              fromY: 0,
                              width: 10,
                              color: Colors.amber,
                            )
                          ],
                        ),
                      ]),
                ),
              ),
              // ),
              Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                margin: const EdgeInsets.symmetric(vertical: 20),
                color: Colors.green[50],
                child: Text(
                  '166'.tr,
                  style: const TextStyle(fontSize: 20),
                ),
              ),
              // Obx(
              //   () =>
              AspectRatio(
                aspectRatio: 1,
                child: Padding(
                  padding: const EdgeInsets.all(0),
                  child: LineChart(
                    LineChartData(
                      lineBarsData: [
                        LineChartBarData(
                          spots: [
                            // ignore: unused_local_variable
                            // for (var i = 0;
                            //     i < controller.profitLossList.length;
                            //     i++) ...[
                            //   FlSpot(i + 1,
                            //       controller.profitLossList[i].profit / 1000)
                            // ]
// here uncomment the above values and comment under vales to calculate real result

                            const FlSpot(1, 4),
                            const FlSpot(2, 7),
                            const FlSpot(3, 6),
                            const FlSpot(4, 2.5),
                            const FlSpot(5, 5),
                            const FlSpot(6, 2),
                            const FlSpot(7, 8),
                            const FlSpot(8, 6),
                            const FlSpot(9, 7),
                            const FlSpot(10, 5),
                            const FlSpot(11, 2.5),
                            const FlSpot(12, 4),
                          ],
                          isCurved: true,
                          dotData: const FlDotData(show: true),
                          //barWidth: 5,
                          belowBarData: BarAreaData(
                            color: Colors.green,
                            // show: true,
                          ),
                        ),
                      ],
                      minX: 1,
                      maxX: 12,
                      minY: -9,
                      maxY: 9,
                      //   backgroundColor: Colors.black,
                      titlesData: FlTitlesData(
                        // show: false,
                        bottomTitles: const AxisTitles(
                          // axisNameWidget: Text('X axis'),
                          sideTitles: SideTitles(
                            showTitles: true,
                            // reservedSize: 30,
                            interval: 1,
                            //   getTitlesWidget: (value, meta) {
                            //     String text = '';
                            //     switch (value.toInt()) {
                            //       case 0:
                            //         text = 'Monday';
                            //         break;
                            //       case 6:
                            //         text = 'Tusday';
                            //         break;
                            //       case 9:
                            //         text = 'Thursday';
                            //         break;
                            //       // default:
                            //     }
                            //     return Text(text);
                            //   },
                          ),
                        ),
                        leftTitles: const AxisTitles(
                          //  axisNameWidget: Text('Y axis'),
                          sideTitles: SideTitles(
                            showTitles: true,
                            // reservedSize: 40,
                            interval: 1,
                            // getTitlesWidget: (value, meta) {
                            //   String text = '';
                            //   switch (value.toInt()) {
                            //     case 0:
                            //       text = 'Monday';
                            //       break;
                            //     case 3:
                            //       text = 'Tusday';
                            //       break;
                            //     case 7:
                            //       text = 'Thursday';
                            //       break;
                            //     // default:
                            //   }
                            //   return Text(text);
                            // },
                          ),
                        ),
                        rightTitles: AxisTitles(
                          axisNameSize: 30,
                          axisNameWidget: Text('170'.tr),
                          //  sideTitles: false,
                        ),
                        topTitles: AxisTitles(
                          axisNameSize: 30,
                          axisNameWidget: Text('169'.tr),
                          //  sideTitles: false,
                        ),
                      ),
                      gridData: FlGridData(
                        //show: false,
                        drawHorizontalLine: true,
                        getDrawingHorizontalLine: (value) => const FlLine(
                          // color: Colors.green,
                          strokeWidth: .5,
                        ),
                        drawVerticalLine: true,
                        getDrawingVerticalLine: (value) => const FlLine(
                          //   color: Colors.amber,
                          strokeWidth: .5,
                        ),
                      ),
                      borderData: FlBorderData(
                          show: true,
                          border: Border.all(
                              // color: Colors.red,
                              //width: 5,
                              )),
                    ),
                  ),
                ),
              ),
              // ),
              Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                margin: const EdgeInsets.symmetric(vertical: 20),
                color: Colors.green[50],
                child: Text(
                  '167'.tr,
                  style: const TextStyle(fontSize: 20),
                ),
              ),
              // Obx(
              //   () =>
              AspectRatio(
                aspectRatio: 1,
                child: BarChart(
                  BarChartData(
                      titlesData: FlTitlesData(
                        rightTitles: AxisTitles(
                            axisNameSize: 30, axisNameWidget: Text('171'.tr)),
                        topTitles: AxisTitles(
                            axisNameSize: 30, axisNameWidget: Text('169'.tr)),
                      ),
                      borderData: FlBorderData(
                        border: const Border(
                          top: BorderSide.none,
                          right: BorderSide.none,
                          left: BorderSide(width: 1),
                          bottom: BorderSide(width: 1),
                        ),
                      ),
                      groupsSpace: 10,
                      barGroups: [
                        // for (var i = 0;
                        //     i < controller.salesListMonth.length;
                        //     i++) ...[
                        //   BarChartGroupData(
                        //     x: i + 1,
                        //     barRods: [
                        //       BarChartRodData(
                        //         toY: controller.salesListMonth[i].totalSales /
                        //             100, //50,
                        //         fromY: 0,
                        //         width: 10,
                        //         color: Colors.amber,
                        //       ),
                        //     ],
                        //   ),
                        // ],
// here uncomment the above values and comment under vales to calculate real result

                        BarChartGroupData(
                          x: 1,
                          barRods: [
                            BarChartRodData(
                              toY: 30,
                              fromY: 0,
                              width: 10,
                              color: const Color.fromARGB(255, 219, 139, 110),
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 2,
                          barRods: [
                            BarChartRodData(
                              toY: 80,
                              fromY: 0,
                              width: 10,
                              color: const Color.fromARGB(255, 219, 139, 110),
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 3,
                          barRods: [
                            BarChartRodData(
                              toY: 170,
                              fromY: 0,
                              width: 10,
                              color: const Color.fromARGB(255, 219, 139, 110),
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 4,
                          barRods: [
                            BarChartRodData(
                              toY: 100,
                              fromY: 0,
                              width: 10,
                              color: const Color.fromARGB(255, 219, 139, 110),
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 5,
                          barRods: [
                            BarChartRodData(
                              toY: 150,
                              fromY: 0,
                              width: 10,
                              color: const Color.fromARGB(255, 219, 139, 110),
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 6,
                          barRods: [
                            BarChartRodData(
                              toY: 190,
                              fromY: 0,
                              width: 10,
                              color: const Color.fromARGB(255, 219, 139, 110),
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 7,
                          barRods: [
                            BarChartRodData(
                              toY: 188,
                              fromY: 0,
                              width: 10,
                              color: const Color.fromARGB(255, 219, 139, 110),
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 8,
                          barRods: [
                            BarChartRodData(
                              toY: 150,
                              fromY: 0,
                              width: 10,
                              color: const Color.fromARGB(255, 219, 139, 110),
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 9,
                          barRods: [
                            BarChartRodData(
                              toY: 250,
                              fromY: 0,
                              width: 10,
                              color: const Color.fromARGB(255, 219, 139, 110),
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 10,
                          barRods: [
                            BarChartRodData(
                              toY: 170,
                              fromY: 0,
                              width: 10,
                              color: const Color.fromARGB(255, 219, 139, 110),
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 11,
                          barRods: [
                            BarChartRodData(
                              toY: 230,
                              fromY: 0,
                              width: 10,
                              color: const Color.fromARGB(255, 219, 139, 110),
                            )
                          ],
                        ),
                        BarChartGroupData(
                          x: 12,
                          barRods: [
                            BarChartRodData(
                              toY: 190,
                              fromY: 0,
                              width: 10,
                              color: const Color.fromARGB(255, 219, 139, 110),
                            )
                          ],
                        ),
                      ]),
                ),
              ),
              // ),
            ],
          ),
        ),
      ),
    );
  }
}
