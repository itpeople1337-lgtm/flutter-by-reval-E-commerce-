// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/category_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/core/functions/handle.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/views/home/categories/categories.dart';
import 'package:stock_app/widgets/custom_button.dart';
import 'package:stock_app/widgets/custom_text.dart';
import 'package:stock_app/widgets/custom_textFormField.dart';

class AddCategory extends StatelessWidget {
  // ignore: prefer_final_fields
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  Color color = Colors.white;
  final c = Get.find<CategoryController>();

  AddCategory({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CategoryController>(
      builder: (_) => Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              //  mainAxisAlignment: MainAxisAlignment.s,
              children: [
                const SizedBox(
                  height: 5,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          onPressed: () {
                            openDialogExit(Routes.CATEGORIES);
                            // Get.back();
                          },
                          icon: const Icon(
                            Icons.arrow_back_ios,
                            color: Colors.red,
                          ),
                        ),
                        const SizedBox(
                          width: 15,
                        ),
                        Text(
                          '76'.tr,
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 18.sp,
                            // fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    submit(),
                  ],
                ),
                Form(
                  key: _formKey,
                  child: CustomTextFormField(
                    title: '',
                    hintText: '17'.tr,
                    validatorFn: (value) {
                      if (value!.isEmpty) {
                        return '29'.tr;
                      }
                      return null;
                    },
                    onSavedFn: (value) {
                      c.name = value!;
                    },
                  ),
                ),
                SizedBox(
                  height: 6.h,
                ),
                Container(
                  alignment: Alignment.center,
                  //width: 300,
                  child: DropdownButton(
                    hint: Text(
                      '67'.tr,
                    ),
                    value: c.selectedType,
                    onChanged: (newValue) {
                      c.getType(newValue!);
                    },
                    items: c.categoryType.map((cuttype) {
                      return DropdownMenuItem(
                        value: cuttype,
                        child: Text(cuttype),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  CustomButton submit() {
    return CustomButton(
      'submit'.toUpperCase(),
      () async {
        if (c.selectedType!.isEmpty) {
          Get.snackbar('70'.tr, '77'.tr, snackPosition: SnackPosition.TOP);
        } else {
          if (_formKey.currentState!.validate()) {
            _formKey.currentState!.save();

            await c.addCategoryToFireStore();

            Get.dialog(
              AlertDialog(
                content: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.check_circle_outline_outlined,
                        color: appColor,
                        size: 100,
                      ),
                      CustomText(
                        text: '78'.tr,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: primaryColor,
                        alignment: Alignment.center,
                      ),
                      const SizedBox(
                        height: 40,
                      ),
                      CustomButton(
                        '73'.tr,
                        () {
                          // Get.back();
                          // Get.to(() => const Categories());
                          Get.offNamed(Routes.CATEGORIES);
                        },
                      ),
                    ],
                  ),
                ),
              ),
              barrierDismissible: false,
            );

            //  Get.back();
          }
        }
      },
    );
  }
}
