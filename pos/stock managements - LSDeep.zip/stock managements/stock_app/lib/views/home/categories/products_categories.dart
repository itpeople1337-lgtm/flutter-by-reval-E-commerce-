import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/category_controller.dart';
import 'package:stock_app/core/constants/app_images.dart';
import 'package:stock_app/models/category_model.dart';
import 'package:stock_app/views/home/categories/add_category.dart';
import 'package:stock_app/widgets/custom_text.dart';

class ListProductsCategories extends StatelessWidget {
  const ListProductsCategories({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(
            height: 20,
          ),
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: IconButton(
                  onPressed: () {
                    Get.back();
                  },
                  icon: const Icon(
                    Icons.arrow_back_ios,
                    color: Colors.red,
                  ),
                ),
              ),
              const SizedBox(
                width: 10,
              ),
              Expanded(
                child: CustomText(
                  text: '83'.tr,
                  fontSize: 14.sp,
                ),
              ),
            ],
          ),
          SizedBox(
            height: 3.h,
          ),
          ListViewProductsCategories(),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Get.to(
            () => AddCategory(),
            transition: Transition.downToUp,
            duration: const Duration(milliseconds: 400),
          );
        },
        tooltip: '76'.tr,
        elevation: 5,
        backgroundColor: Colors.purple[900],
        child: const Icon(Icons.add),
      ),
    );
  }
}

class ListViewProductsCategories extends StatelessWidget {
  final controller = Get.find<CategoryController>();

  ListViewProductsCategories({
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: controller.getCategoriesByProductFromFireStore(),
        builder: (context, snapshot) {
          return Obx(
            () => Expanded(
              child: Padding(
                padding: EdgeInsets.only(right: 4.w, left: 4.w, bottom: 2.h),
                // height: 320.h,
                child: ListView.separated(
                  separatorBuilder: (context, index) {
                    return const Divider();
                  },
                  itemCount: controller.listCategoriesProducts.length,
                  itemBuilder: (context, index) {
                    CategoryModel categoryModel =
                        controller.listCategoriesProducts[index];
                    return Dismissible(
                      key: Key(categoryModel.categoryId),
                      background: Container(
                        color: Colors.red,
                        alignment: Alignment.centerRight,
                        padding: EdgeInsets.only(right: 33.w),
                        child: const Icon(
                          Icons.delete_forever,
                          color: Colors.white,
                          size: 40,
                        ),
                      ),
                      onDismissed: (direction) {
                        if (direction == DismissDirection.endToStart) {
                          controller.deleteCategoryToFireStore(
                              categoryModel.categoryId);
                        }
                      },
                      child: GestureDetector(
                        onTap: () {
                          Get.back(result: categoryModel.name);
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                color: Colors.white,
                              ),
                              height: 6.h,
                              // width: 50.w,
                              child: Image.asset(
                                ImagesAssets.bestProduct,
                                fit: BoxFit.contain,
                                cacheHeight: 105,
                                cacheWidth: 105,
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            CustomText(
                              text: '${categoryModel.name} ',
                              fontSize: 10.sp,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          );
        });
  }
}
