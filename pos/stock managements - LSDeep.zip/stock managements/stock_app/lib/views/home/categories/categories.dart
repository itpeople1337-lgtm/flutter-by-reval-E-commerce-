import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/core/constants/app_images.dart';
import 'package:stock_app/routes.dart';

class Categories extends StatelessWidget {
  const Categories({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          const SizedBox(
            height: 20,
          ),
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: IconButton(
                  onPressed: () {
                    //  Get.back();
                    Get.offNamed(Routes.MAINHOME);
                  },
                  icon: const Icon(
                    Icons.arrow_back_ios,
                    color: Colors.red,
                  ),
                ),
              ),
              const SizedBox(
                width: 20,
              ),
              Text(
                '79'.tr,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 18.sp,
                ),
              ),
            ],
          ),
          SizedBox(
            height: 4.h,
          ),
          ListTile(
            leading: Image.asset(
              ImagesAssets.bestProduct,
              cacheHeight: 105,
              cacheWidth: 105,
              //fit: BoxFit.fill,
              //width: 100,
              // height: 100,
            ),
            title: Text(
              '80'.tr,
              style: TextStyle(
                fontSize: 14.sp,
              ),
            ),
            onTap: () {
              Get.toNamed(Routes.ALLProductsCategories);
            },
          ),
          SizedBox(
            height: 1.h,
          ),
          ListTile(
            leading: Image.asset(
              ImagesAssets.product,
              cacheHeight: 105,
              cacheWidth: 105,
              // fit: BoxFit.fill,
            ),
            title: Text(
              '81'.tr,
              style: TextStyle(
                fontSize: 14.sp,
              ),
            ),
            onTap: () {
              Get.toNamed(Routes.ALLExpensesCategories);
            },
          ),
        ],
      ),
    );
  }
}
