// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/supplier_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/core/functions/handle.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/views/home/suppliers/suppliers.dart';
import 'package:stock_app/widgets/custom_button.dart';
import 'package:stock_app/widgets/custom_text.dart';
import 'package:stock_app/widgets/custom_textFormField.dart';

class AddSupplier extends StatelessWidget {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  Color color = Colors.white;
  final c = Get.find<SupplierController>();

  AddSupplier({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: IconButton(
                        onPressed: () {
                          openDialogExit(Routes.ALLSuppliers);
                          //  Get.back();
                        },
                        icon: const Icon(
                          Icons.arrow_back_ios,
                          color: Colors.red,
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    Text(
                      '158'.tr,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 18.sp,
                        // fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: submit(),
                ),
              ],
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.only(right: 4.w, left: 4.w, bottom: 2.h),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      SizedBox(
                        height: 2.h,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: CustomTextFormField(
                              title: '',
                              hintText: '17'.tr,
                              validatorFn: (value) {
                                if (value!.isEmpty) {
                                  return '134'.tr;
                                }
                                return null;
                              },
                              onSavedFn: (value) {
                                c.name = value!;
                              },
                            ),
                          ),
                          const Icon(
                            Icons.person_add,
                            size: 40,
                          )
                        ],
                      ),
                      SizedBox(
                        height: 1.5.h,
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: CustomTextFormField(
                              keyboardType: TextInputType.streetAddress,
                              title: '',
                              hintText: '119'.tr,
                              validatorFn: (value) {
                                if (value!.isEmpty) {
                                  return '120'.tr;
                                }
                                return null;
                              },
                              onSavedFn: (value) {
                                c.address = value!;
                              },
                            ),
                          ),
                          const Icon(
                            Icons.maps_home_work_outlined,
                            size: 40,
                          )
                        ],
                      ),
                      SizedBox(
                        height: 1.5.h,
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: CustomTextFormField(
                              keyboardType: TextInputType.emailAddress,
                              title: '',
                              hintText: '18'.tr,
                              validatorFn: (value) {
                                if (value!.isEmpty) {
                                  return '121'.tr;
                                }
                                return null;
                              },
                              onSavedFn: (value) {
                                c.email = value!;
                              },
                            ),
                          ),
                          const Icon(
                            Icons.email_outlined,
                            size: 40,
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 1.5.h,
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: CustomTextFormField(
                              keyboardType: TextInputType.number,
                              title: '',
                              hintText: '122'.tr,
                              validatorFn: (value) {
                                if (value!.isEmpty) {
                                  return '123'.tr;
                                }
                                return null;
                              },
                              onSavedFn: (value) {
                                c.phone = value!;
                              },
                            ),
                          ),
                          const Icon(
                            Icons.phone,
                            size: 40,
                          )
                        ],
                      ),
                      SizedBox(
                        height: 1.5.h,
                      ),
                      CustomTextFormField(
                        keyboardType: TextInputType.text,
                        title: '',
                        hintText: '124'.tr,
                        validatorFn: (value) {
                          if (value!.isEmpty) {
                            return '125'.tr;
                          }
                          return null;
                        },
                        onSavedFn: (value) {
                          c.textId = value!;
                        },
                      ),
                      SizedBox(
                        height: 1.5.h,
                      ),
                      CustomTextFormField(
                        // keyboardType: TextInputType.number,
                        title: '',
                        hintText: '126'.tr,
                        validatorFn: (value) {
                          if (value!.isEmpty) {
                            return '126'.tr;
                          }
                          return null;
                        },
                        onSavedFn: (value) {
                          c.bankDetails = value!;
                        },
                      ),
                      SizedBox(
                        height: 1.5.h,
                      ),
                      CustomTextFormField(
                        // keyboardType: TextInputType.number,
                        title: '',
                        hintText: '130'.tr,
                        validatorFn: (value) {
                          if (value!.isEmpty) {
                            return '131'.tr;
                          }
                          return null;
                        },
                        onSavedFn: (value) {
                          c.notes = value!;
                        },
                      ),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  CustomButton submit() {
    return CustomButton(
      'submit'.toUpperCase(),
      () async {
        if (_formKey.currentState!.validate()) {
          _formKey.currentState!.save();
          await c.addSupplierToFireStore();
          Get.dialog(
            AlertDialog(
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.check_circle_outline_outlined,
                      color: appColor,
                      size: 100,
                    ),
                    CustomText(
                      text: '159'.tr,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                      color: primaryColor,
                      alignment: Alignment.center,
                    ),
                    const SizedBox(
                      height: 40,
                    ),
                    CustomButton(
                      '73'.tr,
                      () {
                        // Get.back();
                        Get.offNamed(Routes.ALLSuppliers);
                      },
                    ),
                  ],
                ),
              ),
            ),
            barrierDismissible: false,
          );

          //  Get.back();
        }
      },
    );
  }
}
