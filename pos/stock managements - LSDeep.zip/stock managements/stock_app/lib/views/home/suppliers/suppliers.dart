import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/supplier_controller.dart';
import 'package:stock_app/core/constants/app_images.dart';
import 'package:stock_app/models/supplier_model.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/views/home/suppliers/supplier_details.dart';
import 'package:stock_app/widgets/custom_text.dart';

class ListSuppliers extends StatelessWidget {
  final String? srt;
  const ListSuppliers(this.srt, {super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: IconButton(
                      onPressed: () {
                        Get.toNamed(Routes.MAINHOME);
                      },
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Colors.red,
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  Text(
                    '45'.tr,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18.sp,
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(right: 5),
                child: dropDownList(),
              ),
            ],
          ),
          const SizedBox(
            height: 5,
          ),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 14),
            //  height: 50.h,
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(45),
            ),
            child: TextFormField(
              decoration: const InputDecoration(
                border: InputBorder.none,
                prefixIcon: Icon(
                  Icons.search,
                  color: Colors.black,
                ),
              ),
              onChanged: (value) {
                Get.find<SupplierController>().filterSuppliers(value);
              },
            ),
          ),
          SizedBox(
            height: 3.h,
          ),
          ListViewSuppliers(
            x: srt!,
          ),
        ],
      ),
      // ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          //  Get.to(() => AddSupplier());
          Get.toNamed(Routes.AddSupplier);
        },
        tooltip: 'Add Supplier',
        elevation: 5,
        backgroundColor: Colors.purple[900],
        child: const Icon(Icons.add),
      ),
    );
  }

  dropDownList() {
    return PopupMenuButton<String>(
      onSelected: (value) {
        Get.find<SupplierController>().handleClicklistSuppliers(value);
        // c.phone = customerModel.phone;
        // c.email = customerModel.email;
      }, //
      itemBuilder: (BuildContext context) {
        return {
          'Export To Excel',
          'Print To Pdf',
        }.map((String choice) {
          return PopupMenuItem<String>(
            value: choice,
            child: Text(
              choice,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 16,
              ),
            ),
          );
        }).toList();
      },
    );
  }
}

class ListViewSuppliers extends StatelessWidget {
  final controller = Get.find<SupplierController>();
  final String x;

  ListViewSuppliers({super.key, required this.x});
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: controller.getSuppliersFromFireStore(),
        builder: (context, snapshot) {
          return Obx(
            () => Expanded(
              child: Padding(
                padding: EdgeInsets.only(right: 4.w, left: 4.w, bottom: 2.h),
                // height: 320.h,
                child: ListView.separated(
                  separatorBuilder: (context, index) {
                    return const Divider();
                  },
                  itemCount: controller.filterListSuppliers.length,
                  itemBuilder: (context, index) {
                    SupplierModel supplierModel =
                        controller.filterListSuppliers[index];
                    return Dismissible(
                      key: Key(supplierModel.supplierId),
                      background: Container(
                        color: Colors.red,
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 33),
                        child: const Icon(
                          Icons.delete_forever,
                          color: Colors.white,
                          size: 40,
                        ),
                      ),
                      onDismissed: (direction) {
                        if (direction == DismissDirection.endToStart) {
                          controller.deleteSuppliersToFireStore(
                              supplierModel.supplierId);
                        }
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          GestureDetector(
                            onTap: () {
                              if (x == 'get') {
                                Get.back(result: supplierModel.name);
                              } else {
                                Get.to(
                                  SupplierDetails(supplierModel),
                                );
                              }
                            },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(30),
                                    color: Colors.white,
                                  ),
                                  // height: 30.h,

                                  child: Image.asset(
                                    width: 15.w,
                                    cacheHeight: 96,
                                    cacheWidth: 87,
                                    ImagesAssets.profile,
                                    fit: BoxFit.contain,
                                  ),
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                CustomText(
                                  text: '${supplierModel.name} ',
                                  fontSize: 10.sp,
                                ),
                              ],
                            ),
                          ),
                          PopupMenuButton<String>(
                            onSelected: (value) {
                              controller.handleClick(value);
                              controller.phone = supplierModel.phone;
                              controller.email = supplierModel.email;
                            }, //
                            itemBuilder: (BuildContext context) {
                              return {
                                'Phone Call',
                                'Send SMS',
                                'Send Email',
                                'Whats Up'
                              }.map((String choice) {
                                return PopupMenuItem<String>(
                                  value: choice,
                                  child: Text(
                                    choice,
                                    style: const TextStyle(
                                      color: Colors.black,
                                      fontSize: 16,
                                    ),
                                  ),
                                );
                              }).toList();
                            },
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
          );
        });
  }
}
