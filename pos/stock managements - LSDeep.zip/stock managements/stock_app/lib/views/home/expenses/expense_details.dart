// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/expense_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/models/expense_model.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/views/home/categories/expenses_categries.dart';
import 'package:stock_app/widgets/custom_button.dart';
import 'package:stock_app/widgets/custom_text.dart';
import 'package:stock_app/widgets/custom_textFormField.dart';

class ExpenseDetails extends StatelessWidget {
  final ExpenseModel _expenseModel;
  ExpenseDetails(this._expenseModel, {super.key});

  final _formKey = GlobalKey<FormState>();

  Color color = Colors.white;

  final c = Get.find<ExpenseController>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              // height: 90.h,
              child: Padding(
                padding: EdgeInsets.only(left: 4.w, top: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    IconButton(
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      onPressed: () {
                        Get.back();
                      },
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Colors.red,
                      ),
                    ),
                    Row(
                      children: [
                        CustomText(
                          text: '156'.tr,
                          fontSize: 13.sp,
                          alignment: Alignment.centerLeft,
                        ),
                        SizedBox(
                          width: 10.w,
                        ),
                        submit(),
                        dropDownList(),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.only(right: 4.w, left: 4.w, bottom: 2.h),
                child: Form(
                  key: _formKey,
                  child: Column(children: [
                    SizedBox(
                      height: 3.h,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: GestureDetector(
                            onTap: () async {
                              c.dateTimePickerWidget(context);
                            },
                            child: Obx(
                              () => Container(
                                alignment: Alignment.center,
                                width: 100,
                                height: 100,
                                child: Text(c.selectedDateTime.value),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10.w,
                        ),
                        Expanded(
                          child: CustomTextFormField(
                            initialValue: _expenseModel.amount,
                            keyboardType: TextInputType.number,
                            title: '',
                            hintText: '90'.tr,
                            validatorFn: (value) {
                              if (value!.isEmpty) {
                                return '140'.tr;
                              }
                              return null;
                            },
                            onSavedFn: (value) {
                              // c.amount = value!;
                              _expenseModel.amount = value!;
                            },
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 5.h,
                    ),
                    GestureDetector(
                      onTap: () async {
                        _expenseModel.category =
                            await Get.to(() => const ListExpensesCategories());
                      },
                      child: Obx(
                        () => Container(
                          alignment: Alignment.center,
                          width: MediaQuery.of(context).size.width * .4,
                          height: 5.h,
                          color: Colors.blue[50],
                          child: Text(
                            c.slectedExpenseType.value,
                            // c.selectedItem.value,
                            style: const TextStyle(
                              fontSize: 18,
                            ),
                          ),
                        ),
                      ),
                    ),

                    SizedBox(
                      height: 1.h,
                    ),
                    CustomTextFormField(
                      initialValue: _expenseModel.name,
                      title: '',
                      hintText: '17'.tr,
                      validatorFn: (value) {
                        if (value!.isEmpty) {
                          return '134'.tr;
                        }
                        return null;
                      },
                      onSavedFn: (value) {
                        _expenseModel.name = value!;
                      },
                    ),
                    // ),
                    SizedBox(
                      height: 1.h,
                    ),

                    CustomTextFormField(
                      initialValue: _expenseModel.store,
                      title: '',
                      hintText: '152'.tr,
                      validatorFn: (value) {
                        if (value!.isEmpty) {
                          return '153'.tr;
                        }
                        return null;
                      },
                      onSavedFn: (value) {
                        _expenseModel.store = value!;
                      },
                    ),
                  ]),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  CustomButton submit() {
    return CustomButton(
      'update'.toUpperCase(),
      () async {
        if (_formKey.currentState!.validate()) {
          _formKey.currentState!.save();
          //  c.expenseId = widget._expenseModel.expenseId;
          await c.updateExpensesToFireStore(_expenseModel);

          Get.dialog(
            AlertDialog(
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.check_circle_outline_outlined,
                      color: appColor,
                      size: 100,
                    ),
                    CustomText(
                      text: '157'.tr,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                      color: primaryColor,
                      alignment: Alignment.center,
                    ),
                    const SizedBox(
                      height: 40,
                    ),
                    CustomButton(
                      '73'.tr,
                      () {
                        Get.offNamed(Routes.ALLExpenses);
                        // Get.delete();
                      },
                    ),
                  ],
                ),
              ),
            ),
            barrierDismissible: false,
          );

          //  Get.back();
        }
      },
    );
  }

  dropDownList() {
    return PopupMenuButton<String>(
      onSelected: (value) {
        c.handleClickExpenseDetails(value);
        // c.phone = customerModel.phone;
        // c.email = customerModel.email;
      }, //
      itemBuilder: (BuildContext context) {
        return {
          'Export To Excel',
          'Print To Pdf',
        }.map((String choice) {
          return PopupMenuItem<String>(
            value: choice,
            child: Text(
              choice,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 16,
              ),
            ),
          );
        }).toList();
      },
    );
  }
}
