// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/expense_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/core/functions/handle.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/views/home/categories/expenses_categries.dart';
import 'package:stock_app/widgets/custom_button.dart';
import 'package:stock_app/widgets/custom_text.dart';
import 'package:stock_app/widgets/custom_textFormField.dart';

class AddExpense extends StatelessWidget {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  Color color = Colors.white;
  final c = Get.find<ExpenseController>();

  AddExpense({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: IconButton(
                        onPressed: () {
                          openDialogExit(Routes.ALLExpenses);
                          // Get.back();
                        },
                        icon: const Icon(
                          Icons.arrow_back_ios,
                          color: Colors.red,
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    Text(
                      '151'.tr,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 18.sp,
                        // fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: submit(),
                ),
              ],
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.only(right: 4.w, left: 4.w, bottom: 2.h),
                child: Form(
                  key: _formKey,
                  child: Column(children: [
                    SizedBox(
                      height: 4.h,
                    ),
                    Row(
                      children: [
                        Expanded(
                          child: GestureDetector(
                            onTap: () {
                              c.dateTimePickerWidget(context);
                            },
                            child: Obx(
                              () => Container(
                                alignment: Alignment.center,
                                width: 100,
                                height: 100,
                                child: Text(c.selectedDateTime.value),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 10.w,
                        ),
                        Expanded(
                          child: CustomTextFormField(
                            keyboardType: TextInputType.number,
                            title: '',
                            hintText: '90'.tr,
                            validatorFn: (value) {
                              if (value!.isEmpty) {
                                return '140'.tr;
                              }
                              return null;
                            },
                            onSavedFn: (value) {
                              c.amount = value!;
                            },
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 5.h,
                    ),

                    GestureDetector(
                      onTap: () async {
                        c.slectedExpenseType.value =
                            await Get.to(() => const ListExpensesCategories());
                      },
                      child: Obx(
                        () => Container(
                          alignment: Alignment.center,
                          width: MediaQuery.of(context).size.width * .4,
                          height: 5.h,
                          color: Colors.blue[50],
                          child: Text(
                            c.slectedExpenseType.value,
                            style: TextStyle(
                              fontSize: 12.sp,
                            ),
                          ),
                        ),
                      ),
                    ),

                    SizedBox(
                      height: 2.h,
                    ),
                    CustomTextFormField(
                      title: '',
                      hintText: '17'.tr,
                      validatorFn: (value) {
                        if (value!.isEmpty) {
                          return '134'.tr;
                        }
                        return null;
                      },
                      onSavedFn: (value) {
                        c.name = value!;
                      },
                    ),
                    // ),
                    SizedBox(
                      height: 2.h,
                    ),

                    CustomTextFormField(
                      // keyboardType: TextInputType.number,
                      title: '',
                      hintText: '152'.tr,
                      validatorFn: (value) {
                        if (value!.isEmpty) {
                          return '153'.tr;
                        }
                        return null;
                      },
                      onSavedFn: (value) {
                        c.store = value!;
                      },
                    ),
                  ]),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  CustomButton submit() {
    return CustomButton(
      'submit'.toUpperCase(),
      () async {
        if (c.slectedExpenseType.value == 'select Type Expenses' ||
            c.selectedDateTime.value == 'Pick Date') {
          Get.snackbar('70'.tr, '154'.tr, snackPosition: SnackPosition.TOP);
        } else {
          if (_formKey.currentState!.validate()) {
            _formKey.currentState!.save();

            await c.addExpenseToFireStore();

            Get.dialog(
              AlertDialog(
                content: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.check_circle_outline_outlined,
                        color: appColor,
                        size: 100,
                      ),
                      CustomText(
                        text: '155'.tr,
                        fontSize: 12.sp,
                        fontWeight: FontWeight.bold,
                        color: primaryColor,
                        alignment: Alignment.center,
                      ),
                      const SizedBox(
                        height: 40,
                      ),
                      CustomButton(
                        '73'.tr,
                        () {
                          Get.offNamed(Routes.ALLExpenses);
                        },
                      ),
                    ],
                  ),
                ),
              ),
              barrierDismissible: false,
            );

            //  Get.back();
          }
        }
      },
    );
  }
}
