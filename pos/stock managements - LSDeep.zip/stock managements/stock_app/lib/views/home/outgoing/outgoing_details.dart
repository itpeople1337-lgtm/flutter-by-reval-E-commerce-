// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/outgoing_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/models/in_out_model.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/widgets/custom_button.dart';
import 'package:stock_app/widgets/custom_text.dart';
import 'package:stock_app/widgets/custom_textFormField.dart';

class OutgoingDetails extends StatelessWidget {
  final InOutModel _inOutModel;
  OutgoingDetails(this._inOutModel, {super.key});
  final _formKey = GlobalKey<FormState>();
  final c = Get.find<OutgoingController>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              // height: 90.h,
              child: Padding(
                padding: EdgeInsets.only(left: 4.w, top: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    IconButton(
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      onPressed: () {
                        Get.back();
                      },
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Colors.red,
                      ),
                    ),
                    Row(
                      children: [
                        CustomText(
                          text: '117'.tr,
                          fontSize: 14.sp,
                          alignment: Alignment.centerLeft,
                        ),
                        SizedBox(
                          width: 5.w,
                        ),
                        submit(),
                        dropDownList(),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.only(right: 4.w, left: 4.w, bottom: 2.h),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      SizedBox(
                        height: 6.h,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          SizedBox(
                            width: 40.w,
                            child: CustomTextFormField(
                              initialValue: _inOutModel.docNo,
                              keyboardType: TextInputType.number,
                              title: '',
                              hintText: '112'.tr,
                              validatorFn: (value) {
                                if (value!.isEmpty) {
                                  return '113'.tr;
                                }
                                return null;
                              },
                              onSavedFn: (value) {
                                _inOutModel.docNo = value!;
                              },
                            ),
                          ),
                          SizedBox(
                            width: 10.w,
                          ),
                          GestureDetector(
                            onTap: () {
                              c.dateTimePickerWidget(context);
                            },
                            child: Obx(
                              () => Container(
                                alignment: Alignment.center,
                                width: 40.w,
                                height: 100,
                                child: Text(
                                  c.selectedDateTime.value,
                                  style: TextStyle(
                                    fontSize: 14.sp,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 5.h,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            alignment: Alignment.center,
                            width: MediaQuery.of(context).size.width * .4,
                            height: 5.h,
                            color: Colors.blue[50],
                            child: Text(
                              _inOutModel.clientName,
                              // c.selectedItem.value,
                              style: TextStyle(
                                fontSize: 14.sp,
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 10.w,
                          ),
                          Container(
                            alignment: Alignment.center,
                            width: MediaQuery.of(context).size.width * .4,
                            height: 5.h,
                            color: Colors.blue[50],
                            child: Text(
                              _inOutModel.docType,
                              // c.selectedItem.value,
                              style: TextStyle(
                                fontSize: 14.sp,
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 4.h,
                      ),
                      CustomTextFormField(
                        initialValue: _inOutModel.details,
                        title: '',
                        hintText: '49'.tr,
                        maxline: 3,
                        obscureText: true,
                        validatorFn: (value) {
                          if (value!.isEmpty) {
                            return '63'.tr;
                          }
                          return null;
                        },
                        onSavedFn: (value) {
                          _inOutModel.details = value!;
                        },
                      ),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  dropDownList() {
    return PopupMenuButton<String>(
      onSelected: (value) async {
        c.handleClickoutgoingDetails(value);
        // c.phone = customerModel.phone;
        // c.email = customerModel.email;
      }, //
      itemBuilder: (BuildContext context) {
        return {
          'Export To Excel',
          'Print To Pdf',
        }.map((String choice) {
          return PopupMenuItem<String>(
            value: choice,
            child: Text(
              choice,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 16,
              ),
            ),
          );
        }).toList();
      },
    );
  }

  CustomButton submit() {
    return CustomButton(
      'submit'.toUpperCase(),
      () async {
        if (_formKey.currentState!.validate()) {
          _formKey.currentState!.save();

          await c.updateOutgoingInFireStore(_inOutModel);

          Get.dialog(
            AlertDialog(
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.check_circle_outline_outlined,
                      color: appColor,
                      size: 100,
                    ),
                    CustomText(
                      text: '72'.tr,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                      color: primaryColor,
                      alignment: Alignment.center,
                    ),
                    const SizedBox(
                      height: 40,
                    ),
                    CustomButton(
                      '73'.tr,
                      () {
                        Get.offNamed(Routes.Outgoing);
                      },
                    ),
                  ],
                ),
              ),
            ),
            barrierDismissible: false,
          );

          //  Get.back();
        }
      },
    );
  }
}
