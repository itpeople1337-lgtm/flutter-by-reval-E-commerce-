import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/outgoing_controller.dart';
import 'package:stock_app/core/constants/app_images.dart';
import 'package:stock_app/models/in_out_model.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/views/home/outgoing/add_outgoing.dart';
import 'package:stock_app/views/home/outgoing/outgoing_details.dart';

import 'package:stock_app/widgets/custom_text.dart';

// ignore: must_be_immutable
class Outgoing extends StatelessWidget {
  const Outgoing({super.key});
  // var c = Get.find<OutgoingController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: IconButton(
                      onPressed: () {
                        Get.offNamed(Routes.MAINHOME);
                      },
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Colors.red,
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  Text(
                    '42'.tr,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18.sp,
                      // fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(right: 10),
                child: dropDownList(),
              ),
            ],
          ),
          const SizedBox(
            height: 5,
          ),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 14),
            //height: 50.h,
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(45),
            ),
            child: TextFormField(
              decoration: const InputDecoration(
                border: InputBorder.none,
                prefixIcon: Icon(
                  Icons.search,
                  color: Colors.black,
                ),
              ),
              onChanged: (value) {
                Get.find<OutgoingController>().filterOutgoing(value);
              },
            ),
          ),
          SizedBox(
            height: 2.h,
          ),
          ListViewOutDocs(),
        ],
      ),
      // ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          //  Get.toNamed(Routes.AddInOutProduct, arguments: 'New Outgoing');
          Get.to(
            () => AddOutgoing(),
            transition: Transition.downToUp,
            duration: const Duration(milliseconds: 400),
          );
          // c.clearData();
        },
        tooltip: 'Add Doc',
        elevation: 5,
        backgroundColor: Colors.purple[900],
        child: const Icon(Icons.add),
      ),
    );
  }

  dropDownList() {
    return PopupMenuButton<String>(
      padding: const EdgeInsets.only(left: 50),
      onSelected: (value) {
        Get.find<OutgoingController>().handleClicklistOutgoing(value);
      }, //
      itemBuilder: (BuildContext context) {
        return {
          'Export To Excel',
          'Print To Pdf',
        }.map((String choice) {
          return PopupMenuItem<String>(
            value: choice,
            child: Text(
              choice,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 16,
              ),
            ),
          );
        }).toList();
      },
    );
  }
}

class ListViewOutDocs extends StatelessWidget {
  final controller = Get.find<OutgoingController>();

  ListViewOutDocs({super.key});
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: controller.getOutgoingFromFireStore(),
      builder: (context, snapshot) => Obx(
        () => Expanded(
          flex: 1,
          child: Padding(
            padding: EdgeInsets.only(right: 4.w, left: 4.w, bottom: 2.h),
            // height: 320.h,
            child: ListView.separated(
              separatorBuilder: (context, index) {
                return const Divider();
              },
              padding: const EdgeInsets.symmetric(horizontal: 10),
              itemCount: controller.filterOutgoingProducts.length,
              itemBuilder: (context, index) {
                InOutModel inOutModel =
                    controller.filterOutgoingProducts[index];
                return Dismissible(
                  key: Key(inOutModel.docId),
                  background: Container(
                    color: Colors.red,
                    alignment: Alignment.centerRight,
                    padding: EdgeInsets.only(right: 33.w),
                    child: const Icon(
                      Icons.delete_forever,
                      color: Colors.white,
                      size: 40,
                    ),
                  ),
                  onDismissed: (direction) {
                    if (direction == DismissDirection.endToStart) {
                      controller.deleteOutgoingFromFireStore(inOutModel.docId);
                    }
                  },
                  child: GestureDetector(
                    onTap: () {
                      Get.to(
                        OutgoingDetails(inOutModel),
                      );
                      controller.selectedDateTime.value =
                          inOutModel.date.toString();
                      controller.outgoingDetails = inOutModel;
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          children: [
                            Stack(
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(4),
                                    color: Colors.white,
                                  ),
                                  // height: 30.h,

                                  child: Image.asset(
                                    width: 15.w,
                                    ImagesAssets.outgoing,
                                    fit: BoxFit.contain,
                                    cacheHeight: 95,
                                    cacheWidth: 95,
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              children: [
                                CustomText(
                                  text: '${inOutModel.docNo} ',
                                  fontSize: 10.sp,
                                ),
                                Container(
                                  width: 2,
                                  height: 16,
                                  color: Colors.black,
                                ),
                                CustomText(
                                  text: '  ${inOutModel.clientName}',
                                  fontSize: 10.sp,
                                ),
                              ],
                            ),
                          ],
                        ),
                        Column(
                          children: [
                            CustomText(
                              text: "\$${inOutModel.price}",
                              fontSize: 10.sp,
                              color: Colors.black,
                              // fontWeight: FontWeight.bold,
                            ),
                            CustomText(
                              text: "${inOutModel.quantity} Qt ",
                              fontSize: 10.sp,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
