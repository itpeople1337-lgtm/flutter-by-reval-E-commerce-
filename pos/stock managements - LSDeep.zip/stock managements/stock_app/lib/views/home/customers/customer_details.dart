// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/customer_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/models/customer_model.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/widgets/custom_button.dart';
import 'package:stock_app/widgets/custom_text.dart';
import 'package:stock_app/widgets/custom_textFormField.dart';

class CustomerDetails extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();
  Color color = Colors.white;
  final c = Get.find<CustomerController>();
  final CustomerModel customerModel;

  CustomerDetails(this.customerModel, {super.key});

  @override
  Widget build(BuildContext context) {
    c.customerDetails = customerModel;
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              // height: 90.h,
              child: Padding(
                padding: EdgeInsets.only(left: 2.w, top: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    IconButton(
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      onPressed: () {
                        Get.back();
                      },
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Colors.red,
                      ),
                    ),
                    Row(
                      children: [
                        CustomText(
                          text: '133'.tr,
                          fontSize: 13.sp,
                          alignment: Alignment.centerLeft,
                        ),
                        SizedBox(
                          width: 7.w,
                        ),
                        submit(),
                        dropDownList(),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.only(right: 4.w, left: 4.w, bottom: 2.h),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      SizedBox(
                        height: 2.h,
                      ),
                      CustomTextFormField(
                        initialValue: customerModel.name,
                        title: '',
                        hintText: '17'.tr,
                        validatorFn: (value) {
                          if (value!.isEmpty) {
                            return '134'.tr;
                          }
                          return null;
                        },
                        onSavedFn: (value) {
                          customerModel.name = value!;
                        },
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      CustomTextFormField(
                        initialValue: customerModel.address,
                        title: '',
                        hintText: '119'.tr,
                        validatorFn: (value) {
                          if (value!.isEmpty) {
                            return '120'.tr;
                          }
                          return null;
                        },
                        onSavedFn: (value) {
                          customerModel.address = value!;
                        },
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      CustomTextFormField(
                        initialValue: customerModel.email,
                        title: '',
                        hintText: '18'.tr,
                        validatorFn: (value) {
                          if (value!.isEmpty) {
                            return '121'.tr;
                          }
                          return null;
                        },
                        onSavedFn: (value) {
                          customerModel.email = value!;
                        },
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      CustomTextFormField(
                        initialValue: customerModel.phone,
                        title: '',
                        hintText: '122'.tr,
                        validatorFn: (value) {
                          if (value!.isEmpty) {
                            return '123'.tr;
                          }
                          return null;
                        },
                        onSavedFn: (value) {
                          customerModel.phone = value!;
                        },
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      CustomTextFormField(
                        initialValue: customerModel.textId,
                        title: '',
                        hintText: '124'.tr,
                        validatorFn: (value) {
                          if (value!.isEmpty) {
                            return '125'.tr;
                          }
                          return null;
                        },
                        onSavedFn: (value) {
                          customerModel.textId = value!;
                        },
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      CustomTextFormField(
                        initialValue: customerModel.bankDetails,
                        title: '',
                        hintText: '126'.tr,
                        validatorFn: (value) {
                          if (value!.isEmpty) {
                            return '127'.tr;
                          }
                          return null;
                        },
                        onSavedFn: (value) {
                          customerModel.bankDetails = value!;
                        },
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      CustomTextFormField(
                        initialValue: customerModel.notes,
                        title: '',
                        hintText: '130'.tr,
                        validatorFn: (value) {
                          if (value!.isEmpty) {
                            return '131'.tr;
                          }
                          return null;
                        },
                        onSavedFn: (value) {
                          customerModel.notes = value!;
                        },
                      ),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  dropDownList() {
    return PopupMenuButton<String>(
      onSelected: (value) async {
        c.handleClickcustomerDetails(value);
        // c.phone = customerModel.phone;
        // c.email = customerModel.email;
      }, //
      itemBuilder: (BuildContext context) {
        return {
          'Export To Excel',
          'Print To Pdf',
        }.map((String choice) {
          return PopupMenuItem<String>(
            value: choice,
            child: Text(
              choice,
              style: TextStyle(
                color: Colors.black,
                fontSize: 12.sp,
              ),
            ),
          );
        }).toList();
      },
    );
  }

  CustomButton submit() {
    return CustomButton(
      'update'.toUpperCase(),
      () async {
        if (_formKey.currentState!.validate()) {
          _formKey.currentState!.save();

          await c.updateCustomerToFireStore(customerModel);

          Get.dialog(
            AlertDialog(
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.check_circle_outline_outlined,
                      color: appColor,
                      size: 200,
                    ),
                    CustomText(
                      text: '135'.tr,
                      fontSize: 18.sp,
                      fontWeight: FontWeight.bold,
                      color: primaryColor,
                      alignment: Alignment.center,
                    ),
                    const SizedBox(
                      height: 40,
                    ),
                    CustomButton(
                      '73'.tr,
                      () {
                        Get.back();
                        Get.toNamed(Routes.ALLCustomer);
                      },
                    ),
                  ],
                ),
              ),
            ),
            barrierDismissible: false,
          );
        }
      },
    );
  }
}
