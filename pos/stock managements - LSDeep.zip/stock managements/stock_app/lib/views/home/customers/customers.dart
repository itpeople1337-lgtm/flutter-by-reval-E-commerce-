import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/customer_controller.dart';
import 'package:stock_app/core/constants/app_images.dart';
import 'package:stock_app/models/customer_model.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/views/home/customers/customer_details.dart';
import 'package:stock_app/widgets/custom_text.dart';

class ListCustomers extends StatelessWidget {
  final String srt;
  const ListCustomers(this.srt, {super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: IconButton(
                      onPressed: () {
                        Get.toNamed(Routes.MAINHOME);
                      },
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Colors.red,
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  Text(
                    '44'.tr,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18.sp,
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(right: 5),
                child: dropDownList(),
              ),
            ],
          ),
          const SizedBox(
            height: 5,
          ),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(45),
            ),
            child: TextFormField(
              decoration: const InputDecoration(
                border: InputBorder.none,
                prefixIcon: Icon(
                  Icons.search,
                  color: Colors.black,
                ),
              ),
              onChanged: (value) {
                Get.find<CustomerController>().filterCustomers(value);
              },
            ),
          ),
          SizedBox(
            height: 3.h,
          ),
          ListViewCustomers(x: srt),
        ],
      ),
      // ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Get.to(() => AddCustomer());
          Get.toNamed(Routes.AddCustomer);
        },
        tooltip: 'Add Customer',
        elevation: 5,
        backgroundColor: Colors.purple[900],
        child: const Icon(Icons.add),
      ),
    );
  }

  dropDownList() {
    return PopupMenuButton<String>(
      onSelected: (value) {
        Get.find<CustomerController>().handleClicklistCustomers(value);
        // c.phone = customerModel.phone;
        // c.email = customerModel.email;
      }, //
      itemBuilder: (BuildContext context) {
        return {
          'Export To Excel',
          'Print To Pdf',
        }.map((String choice) {
          return PopupMenuItem<String>(
            value: choice,
            child: Text(
              choice,
              style: TextStyle(
                color: Colors.black,
                fontSize: 12.sp,
              ),
            ),
          );
        }).toList();
      },
    );
  }
}

class ListViewCustomers extends StatelessWidget {
  final controller = Get.find<CustomerController>();
  final String x;
  ListViewCustomers({super.key, required this.x});
  @override
  Widget build(BuildContext context) {
    // controller.getCustomersFromFireStore();
    return FutureBuilder(
      future: controller.getCustomersFromFireStore(),
      builder: (context, snapshot) => Obx(
        () => Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: 3.w, left: 4.w, bottom: 2.w),
            // height: 320.h,
            child: ListView.separated(
              separatorBuilder: (context, index) {
                return const Divider();
              },
              itemCount: controller.filterListCustomers.length,
              itemBuilder: (context, index) {
                CustomerModel customerModel =
                    controller.filterListCustomers[index];
                return Dismissible(
                  key: Key(customerModel.customerId),
                  background: Container(
                    color: Colors.red,
                    alignment: Alignment.centerRight,
                    padding: EdgeInsets.only(right: 33.w),
                    child: const Icon(
                      Icons.delete_forever,
                      color: Colors.white,
                      size: 40,
                    ),
                  ),
                  onDismissed: (direction) {
                    Key(customerModel.customerId);
                    if (direction == DismissDirection.endToStart) {
                      controller
                          .deleteCustomerToFireStore(customerModel.customerId);
                    }
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      GestureDetector(
                        onTap: () {
                          if (x == 'get') {
                            Get.back(result: customerModel.name);
                          } else {
                            Get.to(
                              CustomerDetails(customerModel),
                            );
                          }
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                color: Colors.white,
                              ),
                              // height: 30.h,
                              width: 15.w,
                              child: Image.asset(
                                cacheHeight: 96,
                                cacheWidth: 87,
                                ImagesAssets.profile,
                                fit: BoxFit.contain,
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            CustomText(
                              text: '${customerModel.name} ',
                              fontSize: 10.sp,
                            ),
                          ],
                        ),
                      ),
                      PopupMenuButton<String>(
                        onSelected: (value) {
                          controller.handleClick(value);
                          controller.phone = customerModel.phone;
                          controller.email = customerModel.email;
                        }, //
                        itemBuilder: (BuildContext context) {
                          return {
                            'Phone Call',
                            'Send SMS',
                            'Send Email',
                            'Whats Up'
                          }.map((String choice) {
                            return PopupMenuItem<String>(
                              value: choice,
                              child: Text(
                                choice,
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 12.sp,
                                ),
                              ),
                            );
                          }).toList();
                        },
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
