import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:get/get.dart';
import 'package:stock_app/controllers/note_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/views/home/drawer/notes/ui/pages/add_note_page.dart';
import 'package:stock_app/views/home/drawer/notes/ui/styles/text_styles.dart';
import 'package:stock_app/views/home/drawer/notes/ui/widgets/note_tile.dart';

class NotePage extends StatelessWidget {
  final _notesController = Get.put(NoteController());

  final _tileCounts = [
    [2, 2],
    [2, 2],
    [4, 2],
    [2, 3],
    [2, 2],
    [2, 3],
    [2, 2],
  ];
  final _tileTypes = [
    TileType.Square,
    TileType.Square,
    TileType.HorRect,
    TileType.VerRect,
    TileType.Square,
    TileType.VerRect,
    TileType.Square,
  ];

  NotePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: Padding(
        padding: const EdgeInsets.all(12.0),
        child: FloatingActionButton(
          backgroundColor: const Color(0xFF3B3B3B),
          onPressed: () {
            Get.to(
              const AddNotePage(
                note: null,
              ),
              transition: Transition.downToUp,
            );
          },
          child: const Icon(Icons.add),
        ),
      ),
      // backgroundColor: appColor,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: IconButton(
                    onPressed: () {
                      Get.back();
                    },
                    icon: const Icon(
                      Icons.arrow_back_ios,
                      color: Colors.red,
                    ),
                  ),
                ),
                const SizedBox(
                  width: 20,
                ),
                Text(
                  '234'.tr,
                  style: const TextStyle(
                    color: appColor,
                    fontSize: 22,
                    // fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 30,
            ),
            _body(),
          ],
        ),
      ),
    );
  }

  _body() {
    return Expanded(
        child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Obx(() {
        if (_notesController.noteList.isNotEmpty) {
          return StaggeredGrid.count(
              crossAxisCount: 4,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
              axisDirection: AxisDirection.down,
              children: [
                for (int i = 0; i < _notesController.noteList.length; i++)
                  StaggeredGridTile.count(
                      crossAxisCellCount: _tileCounts[i % 7][0],
                      mainAxisCellCount: _tileCounts[i % 7][1],
                      child: NoteTile(
                        index: i,
                        note: _notesController.noteList[i],
                        tileType: _tileTypes[i % 7],
                      ))
              ]);
        } else {
          return Center(
            child: Text("235".tr, style: titleTextStyle),
          );
        }
      }),
    ));
  }
}
