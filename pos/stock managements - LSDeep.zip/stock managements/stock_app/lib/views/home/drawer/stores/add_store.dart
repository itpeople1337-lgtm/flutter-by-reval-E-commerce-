// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/customer_controller.dart';
import 'package:stock_app/controllers/store_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/widgets/custom_button.dart';
import 'package:stock_app/widgets/custom_text.dart';
import 'package:stock_app/widgets/custom_textFormField.dart';

class AddStore extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();
  Color color = Colors.white;
  final c = Get.find<StoreController>();

  AddStore({super.key});
  //final c = Get.delete<ProductController>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CustomerController>(
      //init: ProductController(),
      builder: (_) => Scaffold(
        appBar: AppBar(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Text('236'.tr),
              ),
              submit(),
            ],
          ),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30),
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      SizedBox(
                        height: 6.h,
                      ),
                      CustomTextFormField(
                        title: '',
                        hintText: '17'.tr,
                        validatorFn: (value) {
                          if (value!.isEmpty) {
                            return '134'.tr;
                          }
                          return null;
                        },
                        onSavedFn: (value) {
                          c.name = value!;
                        },
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  CustomButton submit() {
    return CustomButton(
      'submit'.toUpperCase(),
      () async {
        if (_formKey.currentState!.validate()) {
          _formKey.currentState!.save();

          await c.addStoreToFireStore();

          Get.dialog(
            AlertDialog(
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.check_circle_outline_outlined,
                      color: appColor,
                      size: 100,
                    ),
                    CustomText(
                      text: '237'.tr,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                      color: primaryColor,
                      alignment: Alignment.center,
                    ),
                    const SizedBox(
                      height: 40,
                    ),
                    CustomButton(
                      '73'.tr,
                      () {
                        // Get.back();
                        // Get.to(() => const ListStores());
                        Get.offNamed(Routes.Stores);
                      },
                    ),
                  ],
                ),
              ),
            ),
            barrierDismissible: false,
          );

          //  Get.back();
        }
      },
    );
  }
}
