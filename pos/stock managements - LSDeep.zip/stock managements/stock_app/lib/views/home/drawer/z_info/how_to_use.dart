import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/widgets/custom_text.dart';

class HowToUse extends StatelessWidget {
  const HowToUse({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          // crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(
              height: 10,
            ),
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: IconButton(
                    onPressed: () {
                      Get.back();
                    },
                    icon: const Icon(
                      Icons.arrow_back_ios,
                      color: Colors.red,
                    ),
                  ),
                ),
                const SizedBox(
                  width: 20,
                ),
                Text(
                  '194'.tr,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 18.sp,
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 3.h,
            ),
            SizedBox(
              width: MediaQuery.of(context).size.width * .9,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '240'.tr,
                    style: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 12.0),
                  CustomText(
                    text: '241'.tr,
                    height: 1.5,
                    maxLines: 3,
                    fontSize: 11.sp,
                  ),
                  const SizedBox(height: 12.0),
                  Text(
                    '195'.tr,
                    style: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 12.0),
                  CustomText(
                    text: '196'.tr,
                    height: 1.5,
                    maxLines: 3,
                    fontSize: 11.sp,
                  ),
                  const SizedBox(height: 5.0),
                  CustomText(
                    text: '197'.tr,
                    height: 1.5,
                    fontSize: 11.sp,
                  ),
                  const SizedBox(height: 5.0),
                  CustomText(
                    text: '198'.tr,
                    height: 1.5,
                    fontSize: 11.sp,
                  ),
                  const SizedBox(height: 3.0),
                  CustomText(
                    text: '199'.tr,
                    height: 1.5,
                    fontSize: 11.sp,
                  ),
                  const SizedBox(height: 3.0),
                  CustomText(
                    text: '200'.tr,
                    height: 1.5,
                    fontSize: 11.sp,
                  ),
                  const SizedBox(height: 5.0),
                  CustomText(
                    text: '201'.tr,
                    height: 1.5,
                    maxLines: 3,
                    fontSize: 11.sp,
                  ),
                  const SizedBox(height: 5.0),
                  CustomText(
                    text: '202'.tr,
                    height: 1.5,
                    maxLines: 4,
                    fontSize: 11.sp,
                  ),
                  const SizedBox(height: 5.0),
                  CustomText(
                    text: '203'.tr,
                    height: 1.5,
                    fontSize: 11.sp,
                  ),
                  const SizedBox(height: 5.0),
                  CustomText(
                    text: '204'.tr,
                    height: 1.5,
                    maxLines: 4,
                    fontSize: 11.sp,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
