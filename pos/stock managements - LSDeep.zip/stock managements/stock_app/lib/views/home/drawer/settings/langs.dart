import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/localization_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/widgets/custom_text.dart';

class Language extends GetView<LocalController> {
  const Language({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(
            height: 20,
          ),
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: IconButton(
                  onPressed: () {
                    Get.back();
                  },
                  icon: const Icon(
                    Icons.arrow_back_ios,
                    color: Colors.red,
                  ),
                ),
              ),
              const SizedBox(
                width: 20,
              ),
              Text(
                '188'.tr,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 18.sp,
                  // fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          SizedBox(
            height: 10.h,
          ),

          Container(
            alignment: Alignment.center,
            // width: 300,
            margin: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                Row(
                  //////////////////////// en//////////
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      fontSize: 14.sp,
                      text: 'English',
                      color: appColor,
                    ),
                    Obx(
                      () => CupertinoSwitch(
                        value: controller.switchValueen.value,
                        onChanged: (value) {
                          controller.switchValueen.value = value;
                          controller.changeLange('en');
                        },
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 5.h,
                ),
                //////////////////////// French ////////////
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      fontSize: 14.sp,
                      text: 'French',
                      color: appColor,
                    ),
                    Obx(
                      () => CupertinoSwitch(
                        value: controller.switchValuFr.value,
                        onChanged: (value) {
                          controller.switchValuFr.value = value;
                          controller.changeLange('fr');
                        },
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 5.h,
                ),
                //////////////////////// Spanish ////////////
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      fontSize: 14.sp,
                      text: 'Spanish',
                      color: appColor,
                    ),
                    Obx(
                      () => CupertinoSwitch(
                        value: controller.switchValueSp.value,
                        onChanged: (value) {
                          controller.switchValueSp.value = value;
                          controller.changeLange('es');
                        },
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 5.h,
                ),
                //////////////////////// Portuguese ////////////
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      fontSize: 14.sp,
                      text: 'Portuguese',
                      color: appColor,
                    ),
                    Obx(
                      () => CupertinoSwitch(
                        value: controller.switchValuePt.value,
                        onChanged: (value) {
                          controller.switchValuePt.value = value;
                          controller.changeLange('pt');
                        },
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 5.h,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomText(
                      fontSize: 14.sp,
                      text: 'عربي',
                      color: appColor,
                    ),
                    Obx(
                      () => CupertinoSwitch(
                        value: controller.switchValuear.value,
                        onChanged: (value) {
                          controller.switchValuear.value = value;
                          controller.changeLange('ar');
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // CustomLanguageButton(
          //   textButton: 'ar',
          //   onPressed: () {
          //     controller.changeLange('ar');
          //     Get.toNamed(Routes.OnBoarding);
          //   },
          // ),
          // CustomLanguageButton(
          //   textButton: 'en',
          //   onPressed: () {
          //     controller.changeLange('en');
          //     Get.toNamed(Routes.OnBoarding);
          //   },
          // ),
        ],
      ),
    );
  }
}

class CustomLanguageButton extends StatelessWidget {
  final String textButton;
  final Function()? onPressed;
  const CustomLanguageButton({
    Key? key,
    required this.textButton,
    required this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 100,
      ),
      width: double.infinity,
      child: MaterialButton(
        color: appColor,
        onPressed: onPressed,
        textColor: Colors.white,
        child: Text(
          textButton,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
