import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/store_controller.dart';
import 'package:stock_app/core/constants/app_images.dart';
import 'package:stock_app/models/store_model.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/views/home/drawer/stores/add_store.dart';
import 'package:stock_app/widgets/custom_text.dart';

class ListStores extends StatelessWidget {
  const ListStores({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   title: const Text('Stores'),
      // ),
      body: Column(
        children: [
          const SizedBox(
            height: 20,
          ),
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: IconButton(
                  onPressed: () {
                    // Get.back();
                    Get.offNamed(Routes.MAINHOME);
                  },
                  icon: const Icon(
                    Icons.arrow_back_ios,
                    color: Colors.red,
                  ),
                ),
              ),
              const SizedBox(
                width: 20,
              ),
              Text(
                'List Stores',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 18.sp,
                  // fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 30,
          ),
          ListViewStores(),
        ],
      ),
      // ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Get.to(() => AddStore());
        },
        tooltip: 'Add Store',
        elevation: 5,
        backgroundColor: Colors.purple[900],
        child: const Icon(Icons.add),
      ),
    );
  }
}

class ListViewStores extends StatelessWidget {
  final controller = Get.find<StoreController>();
  ListViewStores({super.key});
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: controller.getStoresFromFireStore(),
        builder: (context, snapshot) {
          return Obx(
            () => Expanded(
              child: Padding(
                padding: EdgeInsets.only(right: 4.w, left: 4.w, bottom: 2.h),
                // height: 320.h,
                child: ListView.separated(
                  separatorBuilder: (context, index) {
                    return const Divider();
                  },
                  itemCount: controller.listStores.length,
                  itemBuilder: (context, index) {
                    StoreModel storeModel = controller.listStores[index];
                    return Dismissible(
                      key: Key(storeModel.storeId),
                      background: Container(
                        color: Colors.red,
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 33),
                        child: const Icon(
                          Icons.delete_forever,
                          color: Colors.white,
                          size: 40,
                        ),
                      ),
                      onDismissed: (direction) {
                        if (direction == DismissDirection.endToStart) {
                          controller.deleteStoreToFireStore(storeModel.storeId);
                        }
                      },
                      child: GestureDetector(
                        onTap: () {
                          Get.back(result: storeModel.name);
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                color: Colors.white,
                              ),
                              // height: 30.h,

                              child: Image.asset(
                                width: 15.w,
                                cacheHeight: 105,
                                cacheWidth: 105,
                                ImagesAssets.product,
                                fit: BoxFit.contain,
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            CustomText(
                              text: '${storeModel.name} ',
                              fontSize: 10.sp,
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          );
        });
  }
}
