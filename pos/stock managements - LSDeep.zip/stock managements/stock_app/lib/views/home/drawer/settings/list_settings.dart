import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/views/home/drawer/settings/about.dart';
import 'package:stock_app/views/home/drawer/settings/co_info.dart';
import 'package:stock_app/views/home/drawer/settings/langs.dart';
import 'package:stock_app/views/home/drawer/settings/select_theme.dart';
import 'package:stock_app/widgets/custom_text.dart';

class ListSettings extends StatelessWidget {
  const ListSettings({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(
            height: 20,
          ),
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: IconButton(
                  onPressed: () {
                    // Get.back();
                    Get.offNamed(Routes.MAINHOME);
                  },
                  icon: const Icon(
                    Icons.arrow_back_ios,
                    color: Colors.red,
                  ),
                ),
              ),
              const SizedBox(
                width: 20,
              ),
              Text(
                '189'.tr,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 18.sp,
                  // fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          SizedBox(
            height: 5.h,
          ),
          CustomListTileSettings(
            iconName: '4',
            title: '190'.tr,
            onTapFn: () {
              Get.to(
                () => const Language(),
                transition: Transition.leftToRight,
                duration: const Duration(milliseconds: 400),
              );
            },
          ),
          CustomListTileSettings(
            iconName: '3',
            title: '191'.tr,
            onTapFn: () {
              Get.to(
                () => const ListThemes(),
                transition: Transition.leftToRight,
                duration: const Duration(milliseconds: 400),
              );
            },
          ),
          CustomListTileSettings(
            iconName: '1',
            title: '192'.tr,
            onTapFn: () {
              Get.to(
                () => AddCompanyInfo(),
                transition: Transition.leftToRight,
                duration: const Duration(milliseconds: 400),
              );
            },
          ),
          CustomListTileSettings(
            iconName: '6',
            title: '193'.tr,
            onTapFn: () {
              Get.to(
                () => const AboutApp(),
                transition: Transition.leftToRight,
                duration: const Duration(milliseconds: 400),
              );
            },
          ),
        ],
      ),
    );
  }
}

class CustomListTileSettings extends StatelessWidget {
  final String iconName;
  final String title;
  final VoidCallback onTapFn;

  const CustomListTileSettings({
    super.key,
    required this.iconName,
    required this.title,
    required this.onTapFn,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        ListTile(
          onTap: onTapFn,
          leading: Image.asset(
            'assets/images/icons/menu_icons/$iconName.png',
            height: 10.w,
            width: 10.w,
            color: Colors.black,
          ),
          title: CustomText(
            text: title,
            fontSize: 12.sp,
            color: appColor,
          ),
          trailing: title == 'Log Out'
              ? null
              : const Icon(
                  Icons.navigate_next,
                  color: appColor, // Colors.black,
                ),
        ),
        SizedBox(
          height: 2.h,
        ),
      ],
    );
  }
}
