// ignore_for_file: prefer_final_fields

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/companyInfo_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/core/constants/app_images.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/widgets/custom_button.dart';
import 'package:stock_app/widgets/custom_text.dart';
import 'package:stock_app/widgets/custom_textFormField.dart';

class AddCompanyInfo extends StatelessWidget {
  var _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  AddCompanyInfo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 14),
            child: SizedBox(
              // height: 50,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  IconButton(
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: () {
                      Get.back();
                    },
                    icon: const Icon(
                      Icons.arrow_back_ios,
                      color: Colors.red,
                    ),
                  ),
                  CustomText(
                    text: '178'.tr,
                    fontSize: 14.sp,
                    alignment: Alignment.bottomCenter,
                  ),
                  Container(
                    width: 24,
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: GetBuilder<CompanyInfoController>(
              init: Get.find<
                  CompanyInfoController>(), //Get.put(CompanyInfoController()),
              builder: (controller) => SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.only(right: 4.w, left: 4.w, bottom: 2.h),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          children: [
                            SizedBox(
                              height: 40.w,
                              width: 40.w,
                              child: IconButton(
                                icon: controller.imageFile == null
                                    ? Image.asset(ImagesAssets.logo)
                                    : Image.file(
                                        controller.imageFile!,
                                        fit: BoxFit.fill,
                                        //  width: double.infinity,
                                      ),
                                iconSize: 50,
                                onPressed: () {
                                  Get.dialog(
                                    AlertDialog(
                                      title: CustomText(
                                        text: '64'.tr,
                                        fontSize: 20,
                                        color: Colors.blue,
                                      ),
                                      content: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          const Divider(
                                            height: 1,
                                          ),
                                          ListTile(
                                            onTap: () async {
                                              try {
                                                await controller.cameraImage();
                                                Get.back();
                                              } catch (error) {
                                                Get.back();
                                              }
                                            },
                                            title: CustomText(
                                              text: '65'.tr,
                                            ),
                                            leading: const Icon(
                                              Icons.camera,
                                              color: Colors.blue,
                                            ),
                                          ),
                                          const Divider(
                                            height: 1,
                                          ),
                                          ListTile(
                                            onTap: () async {
                                              try {
                                                await controller.galleryImage();
                                                Get.back();
                                              } catch (error) {
                                                Get.back();
                                              }
                                            },
                                            title: CustomText(
                                              text: '66'.tr,
                                            ),
                                            leading: const Icon(
                                              Icons.account_box,
                                              color: Colors.blue,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                            SizedBox(
                              height: 3.h,
                            ),
                            CustomTextFormField(
                              title: '',
                              hintText: '179'.tr,
                              validatorFn: (value) {
                                if (value!.isEmpty || value.length < 4) {
                                  return '180'.tr;
                                }
                                return null;
                              },
                              onSavedFn: (value) {
                                controller.companyName = value!;
                              },
                            ),
                            SizedBox(
                              height: 3.h,
                            ),
                            CustomTextFormField(
                              title: '',
                              hintText: '181'.tr,
                              keyboardType: TextInputType.emailAddress,
                              validatorFn: (value) {
                                if (value!.isEmpty) {
                                  return '182'.tr;
                                }
                                return null;
                              },
                              onSavedFn: (value) {
                                controller.companyEmail = value!;
                              },
                            ),
                            SizedBox(
                              height: 3.h,
                            ),
                            CustomTextFormField(
                              title: '',
                              hintText: '183'.tr,
                              validatorFn: (value) {
                                if (value!.isEmpty) {
                                  return '184'.tr;
                                }
                                return null;
                              },
                              onSavedFn: (value) {
                                controller.companyAddress = value!;
                              },
                            ),
                            SizedBox(
                              height: 3.h,
                            ),
                            CustomTextFormField(
                              title: '',
                              hintText: '185'.tr,
                              obscureText: true,
                              validatorFn: (value) {
                                if (value!.isEmpty || value.length < 4) {
                                  return '186'.tr;
                                }
                                return null;
                              },
                              onSavedFn: (value) {
                                controller.companySign = value!;
                              },
                            ),
                            const SizedBox(
                              height: 80,
                            ),
                            _isLoading
                                ? const CircularProgressIndicator()
                                : CustomButton(
                                    'SUBMIT',
                                    () async {
                                      if (_formKey.currentState!.validate()) {
                                        _formKey.currentState!.save();
                                        await controller
                                            .addCompanyToFireStore();

                                        Get.dialog(
                                          AlertDialog(
                                            content: SingleChildScrollView(
                                              child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  const Icon(
                                                    Icons
                                                        .check_circle_outline_outlined,
                                                    color: appColor,
                                                    size: 200,
                                                  ),
                                                  CustomText(
                                                    text: '187'.tr,
                                                    fontSize: 18.sp,
                                                    fontWeight: FontWeight.bold,
                                                    color: primaryColor,
                                                    alignment: Alignment.center,
                                                  ),
                                                  const SizedBox(
                                                    height: 40,
                                                  ),
                                                  CustomButton(
                                                    '73',
                                                    () {
                                                      // Get.back();
                                                      Get.offNamed(
                                                          Routes.SETTINGS);
                                                    },
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          barrierDismissible: false,
                                        );
                                      }
                                    },
                                  ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
