// ignore_for_file: unnecessary_null_comparison

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stock_app/controllers/companyInfo_controller.dart';
import 'package:stock_app/core/constants/app_images.dart';
import 'package:stock_app/widgets/custom_button.dart';

class CompanyInfo extends StatelessWidget {
  CompanyInfo({super.key});
  var controller = Get.find<CompanyInfoController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 5),
                    child: IconButton(
                      onPressed: () {
                        Get.back();
                      },
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Colors.red,
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  Text(
                    '205'.tr,
                    style: const TextStyle(
                      color: Colors.black,
                      fontSize: 22,
                      // fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(right: 14),
                child: CustomButton(
                  'Delete',
                  () => controller
                      .deleteCompanyfromFireStore(controller.data.id!),
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 30,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '195'.tr,
                  style: const TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 8.0),
                Text(
                  '206'.tr,
                  style: const TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                Text(
                  '207'.tr,
                  style: const TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                Text(
                  '208'.tr,
                  style: const TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 16.0),
                Text(
                  '209'.tr,
                  style: const TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
                GetBuilder<CompanyInfoController>(
                  // init: Get.put(CompanyInfoController()),
                  builder: (_) => Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 8.0),
                      buildCompanyInfo(
                          '179'.tr, controller.data.companyName, Colors.blue),
                      buildCompanyInfo('183'.tr, controller.data.companyAddress,
                          Colors.green),
                      buildCompanyInfo(
                          '181'.tr, controller.data.companyEmail, Colors.red),
                      buildCompanyInfo(
                          '210'.tr, controller.data.companySign, Colors.purple),
                      buildCompanyInfo('211'.tr, '', Colors.orange),
                      const SizedBox(height: 8.0),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            alignment: Alignment.center,
            width: 100,
            height: 100,
            child: controller.data.image == null
                ? Image.asset(ImagesAssets.logo)
                : Image.network(
                    controller.data.image,
                    fit: BoxFit.fill,
                    //  width: double.infinity,
                  ),
          ),
        ],
      ),
    );
  }

  Widget buildCompanyInfo(String label, String value, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: RichText(
        text: TextSpan(
          text: '$label: ',
          style: TextStyle(
            fontSize: 16.0,
            color: color,
            fontWeight: FontWeight.bold,
          ),
          children: [
            TextSpan(
              text: value,
              style: const TextStyle(
                fontSize: 16.0,
                color: Colors.black,
                fontWeight: FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
