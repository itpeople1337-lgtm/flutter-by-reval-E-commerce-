import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stock_app/controllers/outgoing_controller.dart';
import 'package:stock_app/controllers/report_controller.dart';
import 'package:stock_app/models/report_model.dart';

class SalesByItem extends StatelessWidget {
  SalesByItem({super.key});
  //var c = Get.put(ReportsController());
  final controller = Get.put(OutgoingController());
  List<Widget> _buildCells(List<String> listV) {
    return listV
        .map(
          (value) => Container(
            alignment: Alignment.center,
            width: 120.0,
            height: 60.0,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.black),
            ),
            padding: const EdgeInsets.all(8.0),
            child: Text(
              value,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
          ),
        )
        .toList();
  }

  List<Widget> _buildHeaderRow() {
    return [
      //'Name',
      '74'.tr,
      '92'.tr
    ]
        .map(
          (title) => Container(
            alignment: Alignment.center,
            width: 120.0,
            height: 60.0,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.black),
              color: Colors.grey[300], // Background color for the header row
            ),
            padding: const EdgeInsets.all(8.0),
            child: Text(
              title,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
          ),
        )
        .toList();
  }

  List<Widget> _buildRows(List<Sales> salesItemL) {
    return [
      Row(
        children: _buildHeaderRow(),
      ),
      ...salesItemL.map(
        (salesItem) => Row(
          children: _buildCells([
            // debtsC.customerID,
            salesItem.type.toString(),
            salesItem.totalSales.toString(),
          ]),
        ),
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    controller.updateIDs('ID');
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('104'.tr),
            dropDownList(),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Obx(
          () => Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: _buildCells(controller.listOfIDs),
              ),
              Flexible(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: _buildRows(controller.salesItemsList),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  dropDownList() {
    return PopupMenuButton<String>(
      padding: const EdgeInsets.only(left: 50),
      onSelected: (value) {
        Get.find<ReportsController>().handleClickprofitsAndLossesReport(value);
      },
      itemBuilder: (BuildContext context) {
        return {
          'Export To Excel',
          'Print To Pdf',
        }.map((String choice) {
          return PopupMenuItem<String>(
            value: choice,
            child: Text(
              choice,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 16,
              ),
            ),
          );
        }).toList();
      },
    );
  }
}
