import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stock_app/controllers/report_controller.dart';
import 'package:stock_app/models/report_model.dart';

class ProfitsandLossesReport extends StatelessWidget {
  ProfitsandLossesReport({super.key});
  var c = Get.put(ReportsController());

  List<Widget> _buildCells(List<String> listV) {
    return listV
        .map(
          (value) => Container(
            alignment: Alignment.center,
            width: 120.0,
            height: 60.0,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.black),
            ),
            padding: const EdgeInsets.all(8.0),
            child: Text(
              value,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
          ),
        )
        .toList();
  }

  List<Widget> _buildHeaderRow() {
    // c.calculateProfitLossMonth();

    return [
      //'Date',
      '92'.tr,
      '93'.tr,
      '46'.tr,
      '94'.tr,
    ]
        .map(
          (title) => Container(
            alignment: Alignment.center,
            width: 120.0,
            height: 60.0,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.black),
              color: Colors.grey[300], // Background color for the header row
            ),
            padding: const EdgeInsets.all(8.0),
            child: Text(
              title,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
          ),
        )
        .toList();
  }

  List<Widget> _buildRows(List<ProfitLoss> profits) {
    return [
      Row(
        children: _buildHeaderRow(),
      ),
      ...profits.map(
        (profit) => Row(
          children: _buildCells([
            // profit.month.toString(),
            profit.totalSales.toString(),
            profit.totalPurchases.toString(),
            profit.totalExpenses.toString(),
            profit.profit < 0 ? '${profit.profit}  L' : '${profit.profit}  P',
          ]),
        ),
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('95'.tr),
            dropDownList(),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Obx(
          () => Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: _buildCells(c.listDatesMonth), //c.list
              ),
              Flexible(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: _buildRows(c.profitLossList),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  dropDownList() {
    return PopupMenuButton<String>(
      padding: const EdgeInsets.only(left: 50),
      onSelected: (value) {
        c.handleClickprofitsAndLossesReport(value);
      }, //
      itemBuilder: (BuildContext context) {
        return {
          'Export To Excel',
          'Print To Pdf',
        }.map((String choice) {
          return PopupMenuItem<String>(
            value: choice,
            child: Text(
              choice,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 16,
              ),
            ),
          );
        }).toList();
      },
    );
  }
}
