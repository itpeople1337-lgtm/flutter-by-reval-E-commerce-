import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stock_app/controllers/report_controller.dart';
import 'package:stock_app/models/report_model.dart';

class TransactionsReport extends StatelessWidget {
  TransactionsReport({super.key});
  var c = Get.put(ReportsController());

  List<Widget> _buildCells(List<String> listV) {
    return listV
        .map(
          (value) => Container(
            alignment: Alignment.center,
            width: 120.0,
            height: 60.0,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.black),
            ),
            padding: const EdgeInsets.all(8.0),
            child: Text(
              value,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
          ),
        )
        .toList();
  }

  List<Widget> _buildHeaderRow() {
    return [
      //'Name',
      // 'Date',
      '110'.tr,
      '90'.tr,
      '62'.tr,
    ]
        .map(
          (title) => Container(
            alignment: Alignment.center,
            width: 120.0,
            height: 60.0,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.black),
              color: Colors.grey[300], // Background color for the header row
            ),
            padding: const EdgeInsets.all(8.0),
            child: Text(
              title,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
          ),
        )
        .toList();
  }

  List<Widget> _buildRows(List<TransactionsModel> transs) {
    return [
      Row(
        children: _buildHeaderRow(),
      ),
      ...transs.map(
        (trans) => Row(
          children: _buildCells([
            // trans.date.toString(),
            trans.type,
            trans.amount.toString(),
            trans.description,
          ]),
        ),
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    c.getTransactions('Transactions');
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('109'.tr),
            dropDownList(),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Obx(
          () => Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: _buildCells(c.listTransDate),
              ),
              Flexible(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: _buildRows(c.transactionsList),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  dropDownList() {
    return PopupMenuButton<String>(
      padding: const EdgeInsets.only(left: 50),
      onSelected: (value) {
        c.handleClickTransactionsReport(value);
      }, //
      itemBuilder: (BuildContext context) {
        return {
          'Export To Excel',
          'Print To Pdf',
        }.map((String choice) {
          return PopupMenuItem<String>(
            value: choice,
            child: Text(
              choice,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 16,
              ),
            ),
          );
        }).toList();
      },
    );
  }
}
