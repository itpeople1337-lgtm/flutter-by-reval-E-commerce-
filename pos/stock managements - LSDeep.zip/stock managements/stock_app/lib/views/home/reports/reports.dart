import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stock_app/core/constants/app_images.dart';
import 'package:stock_app/views/home/reports/debts_customer.dart';
import 'package:stock_app/views/home/reports/debts_supplier.dart';
import 'package:stock_app/views/home/reports/expenses_report.dart';
import 'package:stock_app/views/home/reports/profits&losses.dart';
import 'package:stock_app/views/home/reports/salesby_customer.dart';
import 'package:stock_app/views/home/reports/salesby_date.dart';
import 'package:stock_app/views/home/reports/salesby_item.dart';
import 'package:stock_app/views/home/reports/salesby_month.dart';
import 'package:stock_app/views/home/reports/stock_movement.dart';
import 'package:stock_app/views/home/reports/transactions.dart';

class ListReports extends StatelessWidget {
  const ListReports({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          const SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: IconButton(
                  onPressed: () {
                    Get.back();
                    //  Get.toNamed(Routes.HOME);
                  },
                  icon: const Icon(
                    Icons.arrow_back_ios,
                    color: Colors.red,
                  ),
                ),
              ),
              const SizedBox(
                width: 20,
              ),
              Text(
                '99'.tr,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 22,
                  // fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 20,
          ),
          CustomListTile(
            img: ImagesAssets.bestProduct,
            title: '46'.tr,
            onTap: () {
              Get.to(
                ExpensesReport(),
                transition: Transition.leftToRight,
                duration: const Duration(milliseconds: 400),
              );
            },
          ),
          CustomListTile(
            img: ImagesAssets.product,
            title: '95'.tr,
            onTap: () {
              Get.to(
                ProfitsandLossesReport(),
                transition: Transition.rightToLeft,
                duration: const Duration(milliseconds: 400),
              );
            },
          ),
          CustomListTile(
            img: ImagesAssets.bestProduct,
            title: '100'.tr,
            onTap: () {
              Get.to(
                TransactionsReport(),
                transition: Transition.leftToRight,
                duration: const Duration(milliseconds: 400),
              );
            },
          ),
          CustomListTile(
            img: ImagesAssets.product,
            title: '101'.tr,
            onTap: () {
              Get.to(
                StockMovement(),
                transition: Transition.leftToRight,
                duration: const Duration(milliseconds: 400),
              );
            },
          ),
          CustomListTile(
            img: ImagesAssets.bestProduct,
            title: '86'.tr,
            onTap: () {
              Get.to(
                DebtsByCustomer(),
                transition: Transition.leftToRight,
                duration: const Duration(milliseconds: 400),
              );
            },
          ),
          CustomListTile(
            img: ImagesAssets.product,
            title: '87'.tr,
            onTap: () {
              Get.to(
                DebtsBySupplier(),
                transition: Transition.leftToRight,
                duration: const Duration(milliseconds: 400),
              );
            },
          ),
          CustomListTile(
            img: ImagesAssets.bestProduct,
            title: '102'.tr,
            onTap: () {
              Get.to(
                SalesByCustomer(),
                transition: Transition.leftToRight,
                duration: const Duration(milliseconds: 400),
              );
            },
          ),
          CustomListTile(
            img: ImagesAssets.product,
            title: '103'.tr,
            onTap: () {
              Get.to(
                SalesByDate(),
                transition: Transition.leftToRight,
                duration: const Duration(milliseconds: 400),
              );
            },
          ),
          CustomListTile(
            img: ImagesAssets.bestProduct,
            title: '104'.tr,
            onTap: () {
              Get.to(
                SalesByItem(),
                transition: Transition.leftToRight,
                duration: const Duration(milliseconds: 400),
              );
            },
          ),
          CustomListTile(
            img: ImagesAssets.product,
            title: '105'.tr,
            onTap: () {
              Get.to(
                SalesByMonth(),
                transition: Transition.leftToRight,
                duration: const Duration(milliseconds: 400),
              );
            },
          ),
        ],
      ),
    );
  }
}

class CustomListTile extends StatelessWidget {
  final String img;
  final String title;
  final Function()? onTap;

  const CustomListTile({
    super.key,
    required this.img,
    required this.title,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Image.asset(
        img,
        cacheHeight: 105,
        cacheWidth: 105,
      ),
      title: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
        ),
      ),
      onTap: onTap,
    );
  }
}
