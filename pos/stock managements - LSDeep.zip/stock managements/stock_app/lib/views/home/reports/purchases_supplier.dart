import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stock_app/controllers/report_controller.dart';
import 'package:stock_app/models/report_model.dart';

class PurchasesSupplier extends StatelessWidget {
  PurchasesSupplier({super.key});
  var c = Get.put(ReportsController());
  List<Widget> _buildCells(List<String> listV) {
    return listV
        .map(
          (value) => Container(
            alignment: Alignment.center,
            width: 120.0,
            height: 60.0,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.black),
            ),
            padding: const EdgeInsets.all(8.0),
            child: Text(
              value,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
          ),
        )
        .toList();
  }

  List<Widget> _buildHeaderRow() {
    c.getPurchasesSupplier('PurchasesSupplier');
    return [
      //'Name',
      '96'.tr,
      '93'.tr,
    ]
        .map(
          (title) => Container(
            alignment: Alignment.center,
            width: 120.0,
            height: 60.0,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.black),
              color: Colors.grey[300], // Background color for the header row
            ),
            padding: const EdgeInsets.all(8.0),
            child: Text(
              title,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
          ),
        )
        .toList();
  }

  List<Widget> _buildRows(List<PurchasesSupplierModel> purchareses) {
    return [
      Row(
        children: _buildHeaderRow(),
      ),
      ...purchareses.map(
        (purcharese) => Row(
          children: _buildCells([
            purcharese.name,
            purcharese.totalPurchases.toString(),
          ]),
        ),
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('97'.tr),
      ),
      body: SingleChildScrollView(
        child: Obx(
          () => Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: _buildCells(c.list),
              ),
              Flexible(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: _buildRows(c.purchasesSupplierList),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
