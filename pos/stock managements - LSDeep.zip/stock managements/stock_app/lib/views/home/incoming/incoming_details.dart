// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/incoming_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/models/in_out_model.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/widgets/custom_button.dart';
import 'package:stock_app/widgets/custom_text.dart';
import 'package:stock_app/widgets/custom_textFormField.dart';

class IncomingDetails extends StatelessWidget {
  final InOutModel inOutModel;

  IncomingDetails({required this.inOutModel, super.key});
  final _formKey = GlobalKey<FormState>();
  final c = Get.find<IncomingController>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              child: Padding(
                padding: EdgeInsets.only(left: 4.w, top: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    IconButton(
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      onPressed: () {
                        Get.back();
                      },
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Colors.red,
                      ),
                    ),
                    Row(
                      children: [
                        CustomText(
                          text: '116'.tr,
                          fontSize: 14.sp,
                          alignment: Alignment.centerLeft,
                        ),
                        SizedBox(
                          width: 5.w,
                        ),
                        submit(),
                        dropDownList(),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.only(right: 4.w, left: 4.w, bottom: 2.h),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      SizedBox(
                        height: 4.h,
                      ),
                      CustomTextFormField(
                        initialValue: inOutModel.docNo,
                        keyboardType: TextInputType.number,
                        title: '',
                        hintText: '112'.tr,
                        validatorFn: (value) {
                          if (value!.isEmpty) {
                            return '113'.tr;
                          }
                          return null;
                        },
                        onSavedFn: (value) {
                          inOutModel.docNo = value!;
                        },
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: GestureDetector(
                              onTap: () {
                                c.dateTimePickerWidget(context);
                              },
                              child: Obx(
                                () => Container(
                                  alignment: Alignment.center,
                                  width: 100,
                                  height: 100,
                                  child: Text(
                                    c.selectedDateTime.value,
                                    style: const TextStyle(
                                      fontSize: 18,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 10.w,
                          ),
                          Expanded(
                            child: CustomTextFormField(
                              initialValue: inOutModel.quantity.toString(),
                              keyboardType: TextInputType.number,
                              title: '',
                              hintText: '53'.tr,
                              validatorFn: (value) {
                                if (value!.isEmpty) {
                                  return '54'.tr;
                                }
                                return null;
                              },
                              onSavedFn: (value) {
                                inOutModel.quantity = double.parse(value!);
                              },
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 4.h,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            alignment: Alignment.center,
                            width: MediaQuery.of(context).size.width * .4,
                            height: 5.h,
                            color: Colors.blue[50],
                            child: Text(
                              inOutModel.clientName,
                              // c.selectedItem.value,
                              style: TextStyle(
                                fontSize: 12.sp,
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 10.w,
                          ),
                          Container(
                            alignment: Alignment.center,
                            width: MediaQuery.of(context).size.width * .4,
                            height: 5.h,
                            color: Colors.blue[50],
                            child: Text(
                              inOutModel.docType,
                              style: TextStyle(
                                fontSize: 12.sp,
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 3.h,
                      ),
                      CustomTextFormField(
                        initialValue: inOutModel.details,
                        title: '',
                        hintText: '49'.tr,
                        obscureText: true,
                        validatorFn: (value) {
                          if (value!.isEmpty) {
                            return '63'.tr;
                          }
                          return null;
                        },
                        onSavedFn: (value) {
                          inOutModel.details = value!;
                        },
                      ),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  dropDownList() {
    return PopupMenuButton<String>(
      onSelected: (value) async {
        c.handleClickincomingDetails(value);
        // c.phone = customerModel.phone;
        // c.email = customerModel.email;
      }, //
      itemBuilder: (BuildContext context) {
        return {
          'Export To Excel',
          'Print To Pdf',
        }.map((String choice) {
          return PopupMenuItem<String>(
            value: choice,
            child: Text(
              choice,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 16,
              ),
            ),
          );
        }).toList();
      },
    );
  }

  CustomButton submit() {
    return CustomButton(
      'submit'.toUpperCase(),
      () async {
        if (_formKey.currentState!.validate()) {
          _formKey.currentState!.save();

          await c.updateIncomingInFireStore(inOutModel);

          Get.dialog(
            AlertDialog(
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.check_circle_outline_outlined,
                      color: appColor,
                      size: 100,
                    ),
                    CustomText(
                      text: '72'.tr,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                      color: primaryColor,
                      alignment: Alignment.center,
                    ),
                    const SizedBox(
                      height: 40,
                    ),
                    CustomButton(
                      '73'.tr,
                      () {
                        Get.offNamed(Routes.Incoming);
                      },
                    ),
                  ],
                ),
              ),
            ),
            barrierDismissible: false,
          );

          //  Get.back();
        }
      },
    );
  }
}

// class ListGoods extends StatelessWidget {
//   final controller = Get.find<InOutProductController>();

//   ListGoods({
//     super.key,
//   });
//   @override
//   Widget build(BuildContext context) {
//     // controller.getSelectedProducts();
//     return Obx(
//       () => Padding(
//         padding: EdgeInsets.only(right: 5.w, left: 10.w, bottom: 24.h),
//         // height: 320.h,
//         child: ListView.separated(
//           separatorBuilder: (context, index) {
//             return const Divider();
//           },
//           itemCount: controller.selectedProducts.length,
//           itemBuilder: (context, index) {
//             ProductModel productModel = controller.selectedProducts[index];
//             return Dismissible(
//               key: Key(productModel.productId),
//               background: Container(
//                 color: Colors.red,
//                 alignment: Alignment.centerRight,
//                 padding: EdgeInsets.only(right: 33.w),
//                 child: const Icon(
//                   Icons.delete_forever,
//                   color: Colors.white,
//                   size: 40,
//                 ),
//               ),
//               onDismissed: (direction) {
//                 if (direction == DismissDirection.endToStart) {
//                   controller.selectedProducts.remove(productModel);
//                   // controller.deleteProductFromFireStore(
//                   //     productModel.productId);
//                 }
//               },
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Row(
//                     children: [
//                       Container(
//                         decoration: BoxDecoration(
//                           borderRadius: BorderRadius.circular(30),
//                           color: Colors.white,
//                         ),
//                         // height: 30.h,
//                         width: 50.w,
//                         child: Image.asset(
//                           'assets/images/icons/expense.png',
//                           fit: BoxFit.contain,
//                         ),
//                       ),
//                       const SizedBox(
//                         width: 10,
//                       ),
//                       CustomText(
//                         text: '${productModel.name} ',
//                         fontSize: 16,
//                       ),
//                     ],
//                   ),
//                   CustomText(
//                     text: '${productModel.quantity} ',
//                     fontSize: 16,
//                   ),
//                 ],
//               ),
//             );
//           },
//         ),
//       ),
//     );
//   }
// }
