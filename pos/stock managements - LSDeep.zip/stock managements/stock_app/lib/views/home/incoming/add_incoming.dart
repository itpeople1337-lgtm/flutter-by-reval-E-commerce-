// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/incoming_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/core/constants/app_images.dart';
import 'package:stock_app/core/functions/handle.dart';
import 'package:stock_app/models/product_model.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/widgets/custom_button.dart';
import 'package:stock_app/widgets/custom_text.dart';
import 'package:stock_app/widgets/custom_textFormField.dart';
// import 'package:get_storage/get_storage.dart';

class AddIncoming extends StatelessWidget {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final c = Get.find<IncomingController>();

  // final String? title;
  AddIncoming({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    // c.title = title!;
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                const SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          onPressed: () {
                            //  Get.back();
                            openDialogExit(Routes.Incoming);
                            //  c.clearData();
                          },
                          icon: const Icon(
                            Icons.arrow_back_ios,
                            color: Colors.red,
                          ),
                        ),
                        const SizedBox(
                          width: 20,
                        ),
                        Text(
                          '111'.tr,
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 18.sp,
                            // fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    submit(),
                  ],
                ),
                CustomTextFormField(
                  keyboardType: TextInputType.number,
                  title: '',
                  hintText: '112'.tr,
                  validatorFn: (value) {
                    if (value!.isEmpty) {
                      return '113'.tr;
                    }
                    return null;
                  },
                  onSavedFn: (value) {
                    c.docNo = value!;
                  },
                ),
                SizedBox(
                  height: 6.h,
                ),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          c.dateTimePickerWidget(context);
                        },
                        child: Obx(
                          () => Container(
                            alignment: Alignment.center,
                            width: 30.w,
                            height: 5.h,
                            child: Text(
                              c.selectedDateTime.value,
                              style: TextStyle(
                                fontSize: 12.sp,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10.w,
                    ),
                    GestureDetector(
                      onTap: () async {
                        c.addClientName();
                        // c.saveSelectedProductIds(
                        //     [c.product?.productId ?? '']);
                      },
                      child: Obx(
                        () => Container(
                          alignment: Alignment.center,
                          width: MediaQuery.of(context).size.width * .4,
                          height: 5.h,
                          color: Colors.blue[50],
                          child: Text(
                            c.selectClientName.value,
                            //  c.selectedcustomerType.value,
                            style: TextStyle(
                              fontSize: 12.sp,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 5.h,
                ),
                Container(
                  alignment: Alignment.centerLeft,
                  padding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                  color: Colors.blue[50],
                  child: Obx(
                    () => Text(
                      c.details2.value,
                      textAlign: TextAlign.start,
                      style: const TextStyle(
                        fontSize: 18,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 2.h,
                ),
                CustomTextFormField(
                  // initialValue: c.details2.value,
                  title: '',
                  hintText: '49'.tr,
                  validatorFn: (value) {
                    if (value!.isEmpty) {
                      return '63'.tr;
                    }
                    return null;
                  },
                  onSavedFn: (value) {
                    c.details = value!;
                  },
                ),
                SizedBox(
                  height: 5.h,
                ),
                SizedBox(
                  height: 30.h,
                  child: ListGoods(),
                ),
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          c.getProduct();
        },
        tooltip: 'Add Goods',
        elevation: 5,
        backgroundColor: Colors.purple[900],
        child: const Icon(Icons.add),
      ),
    );
  }

  CustomButton submit() {
    return CustomButton(
      'submit'.toUpperCase(),
      () async {
        if (c.details2.value == 'Details: ' ||
            c.selectClientName.value == 'Pick Client' ||
            c.selectedDateTime.value == 'Pick Date') {
          Get.snackbar('70'.tr, '114'.tr, snackPosition: SnackPosition.TOP);
        } else {
          if (_formKey.currentState!.validate() & c.lproducts.isNotEmpty) {
            _formKey.currentState!.save();
            await c.addIncomingToFireStore();

            Get.dialog(
              AlertDialog(
                content: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.check_circle_outline_outlined,
                        color: appColor,
                        size: 100,
                      ),
                      CustomText(
                        text: '72'.tr,
                        fontSize: 12.sp,
                        fontWeight: FontWeight.bold,
                        color: primaryColor,
                        alignment: Alignment.center,
                      ),
                      const SizedBox(
                        height: 40,
                      ),
                      CustomButton(
                        '73'.tr,
                        () {
                          Get.offNamed(Routes.Incoming);
                        },
                      ),
                    ],
                  ),
                ),
              ),
              barrierDismissible: false,
            );
          }
        }
      },
    );
  }
}

class ListGoods extends StatelessWidget {
  final controller = Get.find<IncomingController>();
  // final storage = GetStorage();
  ListGoods({
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    return Obx(
      () => controller.lproducts.isEmpty
          ? Image.asset(
              ImagesAssets.addProduct,
              width: 100,
              height: 100,
            )
          : Padding(
              padding: EdgeInsets.only(right: 3.w, left: 3.w, bottom: 2.h),

              // height: 320.h,
              child: ListView.separated(
                separatorBuilder: (context, index) {
                  return const Divider();
                },
                itemCount: controller.lproducts.length,
                itemBuilder: (context, index) {
                  ProductModel productModel = controller.lproducts[index];
                  return Dismissible(
                    key: Key(productModel.productId),
                    background: Container(
                      color: Colors.red,
                      alignment: Alignment.centerRight,
                      padding: EdgeInsets.only(right: 33),
                      child: const Icon(
                        Icons.delete_forever,
                        color: Colors.white,
                        size: 40,
                      ),
                    ),
                    onDismissed: (direction) {
                      if (direction == DismissDirection.endToStart) {
                        controller.lproducts.remove(productModel);
                        controller.clearData();
                      }
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                color: Colors.white,
                              ),
                              // height: 30.h,

                              child: Image.asset(
                                width: 15.w,
                                ImagesAssets.inout,
                                fit: BoxFit.contain,
                                cacheHeight: 95,
                                cacheWidth: 95,
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            CustomText(
                              text: '${productModel.name} ',
                              fontSize: 10.sp,
                            ),
                          ],
                        ),
                        CustomText(
                          text: '\$${productModel.sellingprice} ',
                          fontSize: 10.sp,
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
    );
  }
}
