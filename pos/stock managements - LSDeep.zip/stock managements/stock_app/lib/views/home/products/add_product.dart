import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/product_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/core/constants/app_images.dart';
import 'package:stock_app/core/functions/handle.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/widgets/custom_button.dart';
import 'package:stock_app/widgets/custom_text.dart';
import 'package:stock_app/widgets/custom_textFormField.dart';
import 'package:stock_app/widgets/read_barcode.dart';

// ignore: must_be_immutable
class AddProduct extends StatelessWidget {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  Color color = Colors.white;
  final c = Get.find<ProductController>();

  AddProduct({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProductController>(
      builder: (_) => Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: IconButton(
                          onPressed: () {
                            openDialogExit(Routes.ALLPRODUCTS);
                            // Get.back();
                          },
                          icon: const Icon(
                            Icons.arrow_back_ios,
                            color: Colors.red,
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 20,
                      ),
                      Text(
                        '50'.tr,
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 16.sp,
                          // fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.only(right: 10),
                    child: submitProduct(),
                  ),
                ],
              ),
              // const SizedBox(
              //   height: 30,
              // ),
              Expanded(
                child: SingleChildScrollView(
                  padding: EdgeInsets.only(right: 4.w, left: 4.w, bottom: 3.h),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        SizedBox(
                          height: 2.h,
                        ),
                        Row(
                          children: [
                            Expanded(
                              child: CustomTextFormField(
                                title: '',
                                hintText: '51'.tr,
                                validatorFn: (value) {
                                  if (value!.isEmpty) {
                                    return '52'.tr;
                                  }
                                  return null;
                                },
                                onSavedFn: (value) {
                                  c.name = value!;
                                },
                              ),
                            ),
                            SizedBox(
                              width: 10.w,
                            ),
                            Expanded(
                              child: CustomTextFormField(
                                keyboardType: TextInputType.number,
                                title: '',
                                hintText: '53'.tr,
                                validatorFn: (value) {
                                  if (value!.isEmpty) {
                                    return '54'.tr;
                                  }
                                  return null;
                                },
                                onSavedFn: (value) {
                                  c.quantity = value!;
                                },
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 2.h,
                        ),
                        Row(
                          children: [
                            Expanded(
                              child: CustomTextFormField(
                                keyboardType: TextInputType.number,
                                title: '',
                                hintText: '55'.tr,
                                validatorFn: (value) {
                                  if (value!.isEmpty) {
                                    return '56'.tr;
                                  }
                                  return null;
                                },
                                onSavedFn: (value) {
                                  c.purchaseprice = value!;
                                },
                              ),
                            ),
                            SizedBox(
                              width: 10.w,
                            ),
                            Expanded(
                              child: CustomTextFormField(
                                keyboardType: TextInputType.number,
                                title: '',
                                hintText: '57'.tr,
                                validatorFn: (value) {
                                  if (value!.isEmpty) {
                                    return '58'.tr;
                                  }
                                  return null;
                                },
                                onSavedFn: (value) {
                                  c.sellingprice = value!;
                                },
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 4.h,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            GestureDetector(
                              onTap: () async {
                                c.selectStore();
                              },
                              child: Obx(
                                () => Container(
                                  alignment: Alignment.center,
                                  width: MediaQuery.of(context).size.width * .4,
                                  height: 5.h,
                                  color: Colors.blue[50],
                                  child: Text(
                                    c.selectStoreName.value,
                                    //  c.selectedcustomerType.value,
                                    style: TextStyle(
                                      fontSize: 14.sp,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10.w,
                            ),
                            GestureDetector(
                              onTap: () async {
                                c.selectCategory();
                              },
                              child: Obx(
                                () => Container(
                                  alignment: Alignment.center,
                                  width: MediaQuery.of(context).size.width * .4,
                                  height: 5.h,
                                  color: Colors.blue[50],
                                  child: Text(
                                    c.selectCategoryName.value,
                                    //  c.selectedcustomerType.value,
                                    style: TextStyle(
                                      fontSize: 14.sp,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 1.h,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: GestureDetector(
                                onTap: () {
                                  //c.selectDate(context);
                                  c.dateTimePickerWidget(context);
                                },
                                child: Container(
                                  alignment: Alignment.centerLeft,
                                  width: 100,
                                  height: 100,
                                  child: Obx(
                                    () => Text(
                                      c.selectedDateTime.value,
                                      style: TextStyle(fontSize: 14.sp),
                                    ),
                                  ),
                                  // Text(c.selectedDateTime.toString()),
                                ),
                              ),
                            ),
                            GestureDetector(
                              onTap: () {
                                c.pickColor();
                              },
                              child: Container(
                                alignment: Alignment.center,
                                width: 20.w,
                                height: 20.w,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: c.selectedColor,
                                ),
                                child: Text(
                                  '59'.tr,
                                  textAlign: TextAlign.center,
                                  //style: TextStyle(fontSize: 18),
                                ),
                              ),
                            ),
                          ],
                        ),
                        // Obx(
                        //   () =>
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 50.w,
                              child: Expanded(
                                child: Obx(
                                  () => CustomTextFormField(
                                    keyboardType: TextInputType.number,
                                    initialValue: c.getValuebarcode.value,
                                    title: '',
                                    hintText: '60'.tr,
                                    validatorFn: (value) {
                                      if (value!.isEmpty) {
                                        return '61'.tr;
                                      }
                                      return null;
                                    },
                                    onSavedFn: (value) {
                                      c.getValuebarcode.value = value!;
                                    },
                                  ),
                                ),
                              ),
                            ),
                            GestureDetector(
                              onTap: () async {
                                await Get.to(const QRCodeScannerApp());
                              },
                              child: Container(
                                alignment: Alignment.centerRight,
                                width: 20.w,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    const Text(
                                      'Scan QR',
                                      textAlign: TextAlign.center,
                                    ),
                                    Image.asset(ImagesAssets.qr),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 1.h,
                        ),
                        CustomTextFormField(
                          title: '',
                          hintText: '62'.tr,
                          validatorFn: (value) {
                            if (value!.isEmpty) {
                              return '63'.tr;
                            }
                            return null;
                          },
                          onSavedFn: (value) {
                            c.details = value!;
                          },
                        ),
                        SizedBox(
                          height: 3.h,
                        ),
                        SizedBox(
                          height: 40.w,
                          width: 40.w,
                          child: IconButton(
                            icon: c.imageFile == null
                                ? Image.asset(ImagesAssets.addProduct)
                                : Image.file(
                                    c.imageFile!,
                                    fit: BoxFit.fill,
                                    //  width: double.infinity,
                                  ),
                            iconSize: 30,
                            onPressed: () {
                              Get.dialog(
                                AlertDialog(
                                  title: CustomText(
                                    text: '64'.tr,
                                    fontSize: 10.sp,
                                    color: Colors.blue,
                                  ),
                                  content: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const Divider(
                                        height: 1,
                                      ),
                                      ListTile(
                                        onTap: () async {
                                          try {
                                            await c.cameraImage();
                                            Get.back();
                                          } catch (error) {
                                            Get.back();
                                          }
                                        },
                                        title: CustomText(
                                          text: '65'.tr,
                                          fontSize: 10.sp,
                                        ),
                                        leading: const Icon(
                                          Icons.camera,
                                          color: Colors.blue,
                                        ),
                                      ),
                                      const Divider(
                                        height: 1,
                                      ),
                                      ListTile(
                                        onTap: () async {
                                          try {
                                            await c.galleryImage();
                                            Get.back();
                                          } catch (error) {
                                            Get.back();
                                          }
                                        },
                                        title: CustomText(
                                          text: '66'.tr,
                                          fontSize: 10.sp,
                                        ),
                                        leading: const Icon(
                                          Icons.account_box,
                                          color: Colors.blue,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  CustomButton submitProduct() {
    return CustomButton(
      'submit'.toUpperCase(),
      () async {
        if (c.imageFile == null ||
            c.selectCategoryName.value == '67'.tr ||
            c.selectStoreName.value == '68'.tr ||
            c.selectedDateTime.value == '69'.tr) {
          Get.snackbar('70'.tr, '71'.tr, snackPosition: SnackPosition.TOP);
        } else {
          if (_formKey.currentState!.validate()) {
            _formKey.currentState!.save();
            await c.addProductToFireStore();

            Get.dialog(
              AlertDialog(
                content: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.check_circle_outline_outlined,
                        color: appColor,
                        size: 100,
                      ),
                      CustomText(
                        text: 'Product Submitted',
                        fontSize: 12.sp,
                        fontWeight: FontWeight.bold,
                        color: primaryColor,
                        alignment: Alignment.center,
                      ),
                      const SizedBox(
                        height: 40,
                      ),
                      CustomButton(
                        '73'.tr,
                        () {
                          Get.back();
                          Get.toNamed(Routes.ALLPRODUCTS);
                        },
                      ),
                    ],
                  ),
                ),
              ),
              barrierDismissible: false,
            );
          }
        }
      },
    );
  }
}
