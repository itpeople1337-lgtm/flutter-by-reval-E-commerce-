import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/product_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/core/constants/app_images.dart';
import 'package:stock_app/models/product_model.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/views/home/products/product_detalis.dart';
import 'package:stock_app/widgets/custom_text.dart';

class ListProducts extends StatelessWidget {
  final String srt;
  const ListProducts(this.srt, {super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 10),
                    child: IconButton(
                      onPressed: () {
                        Get.offNamed(Routes.MAINHOME);
                      },
                      icon: const Icon(
                        Icons.arrow_back_ios,
                        color: Colors.red,
                      ),
                    ),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  Text(
                    '38'.tr,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 16.sp,
                      // fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(right: 14),
                child: dropDownList(),
              ),
            ],
          ),
          const SizedBox(
            height: 5,
          ),
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(45),
            ),
            child: TextFormField(
              decoration: const InputDecoration(
                border: InputBorder.none,
                prefixIcon: Icon(
                  Icons.search,
                  color: Colors.black,
                ),
              ),
              onChanged: (value) {
                Get.find<ProductController>().filterProducts(value);
              },
            ),
          ),
          SizedBox(
            height: 1.5.h,
          ),
          ListViewProducts(x: srt),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          //Get.to(() => AddProduct());
          Get.toNamed(Routes.AddProduct);
          Get.find<ProductController>().clearData();
        },
        tooltip: '50'.tr,
        elevation: 5,
        backgroundColor: Colors.purple[900],
        child: const Icon(Icons.add),
      ),
    );
  }

  dropDownList() {
    return PopupMenuButton<String>(
      padding: const EdgeInsets.only(left: 50),
      onSelected: (value) {
        Get.find<ProductController>().handleClicklistProducts(value);
        // c.phone = customerModel.phone;
        // c.email = customerModel.email;
      }, //
      itemBuilder: (BuildContext context) {
        return {
          'Export To Excel',
          'Print To Pdf',
        }.map((String choice) {
          return PopupMenuItem<String>(
            value: choice,
            child: Text(
              choice,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 16,
              ),
            ),
          );
        }).toList();
      },
    );
  }
}

class ListViewProducts extends StatelessWidget {
  final controller = Get.find<ProductController>();
  final String x;
  ListViewProducts({super.key, required this.x});
  @override
  Widget build(BuildContext context) {
    //  controller.getProductsFromFireStore();
    return FutureBuilder(
      future: controller.getProductsFromFireStore(),
      builder: (context, snapshot) => Obx(
        () => Expanded(
          child: Padding(
            padding: EdgeInsets.only(right: 2.w, left: 2.w, bottom: 3.h),
            child: GridView.builder(
              // padding: const EdgeInsets.all(0),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 5,
                crossAxisSpacing: 5,
                mainAxisExtent: 21.5.h,
              ),
              itemCount: controller.filteredProducts.length,
              itemBuilder: (context, index) {
                ProductModel product = controller.filteredProducts[index];
                return Dismissible(
                  key: Key(product.productId),
                  background: Container(
                    color: Colors.red,
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.only(right: 33),
                    child: const Icon(
                      Icons.delete_forever,
                      color: Colors.white,
                      size: 40,
                    ),
                  ),
                  onDismissed: (direction) {
                    if (direction == DismissDirection.endToStart) {
                      controller.deleteProductFromFireStore(product.productId);
                    }
                  },
                  child: GestureDetector(
                    onTap: () {
                      if (x == 'get') {
                        Get.back(result: product);
                      } else {
                        Get.to(() => ProductDetails(product));
                      }
                    },
                    child: Card(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            margin: EdgeInsets.only(bottom: 10),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(4),
                            ),
                            // height: 6.h,
                            // width: 5.w,
                            child: product.image != null
                                ? CachedNetworkImage(
                                    height: 30.w,
                                    width: 30.w,
                                    fit: BoxFit.fill,
                                    imageUrl: product.image,
                                    progressIndicatorBuilder: (
                                      context,
                                      url,
                                      downloadProgress,
                                    ) =>
                                        CircularProgressIndicator(
                                            value: downloadProgress.progress),
                                    errorWidget: (context, url, error) =>
                                        const Icon(Icons.error),
                                  )
                                : Image.asset(
                                    ImagesAssets.bestProduct,
                                    height: 80,
                                    // width: ,
                                  ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: CustomText(
                              text: product.name,
                              fontSize: 9.sp,
                            ),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(left: 10),
                                child: CustomText(
                                  text: '\$${product.sellingprice}',
                                  fontSize: 9.sp,
                                  color: primaryColor,
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(right: 10),
                                child: CustomText(
                                  text: product.quantity,
                                  fontSize: 9.sp,
                                  color: appColor,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),

                  //),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
