// ignore_for_file: must_be_immutable

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/product_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/core/constants/app_images.dart';
import 'package:stock_app/models/product_model.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/widgets/custom_button.dart';
import 'package:stock_app/widgets/custom_text.dart';
import 'package:stock_app/widgets/custom_textFormField.dart';

class ProductDetails extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();
  final c = Get.find<ProductController>();
  final ProductModel productModel;
  ProductDetails(this.productModel, {super.key});

  @override
  Widget build(BuildContext context) {
    c.productDetails = productModel;
    String valueString =
        productModel.color.split('(0x')[1].split(')')[0]; // kind of hacky..
    int value = int.parse(valueString, radix: 16);
    Color resultColor = Color(value);

    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              child: Padding(
                padding: EdgeInsets.only(left: 3.w, top: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          // padding: EdgeInsets.zero,
                          // constraints: const BoxConstraints(),
                          onPressed: () {
                            Get.back();
                          },
                          icon: const Icon(
                            Icons.arrow_back_ios,
                            color: Colors.red,
                          ),
                        ),
                        CustomText(
                          text: '74'.tr,
                          fontSize: 14.sp,
                          //  fontWeight: FontWeight.bold,
                          // alignment: Alignment.centerLeft,
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        submitProduct(),
                        dropDownList(),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.only(right: 6.w, left: 6.w, bottom: 2.h),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      SizedBox(
                        height: 3.h,
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: CustomTextFormField(
                              initialValue: productModel.name,
                              title: '',
                              hintText: '51'.tr,
                              validatorFn: (value) {
                                if (value!.isEmpty) {
                                  return '52'.tr;
                                }
                                return null;
                              },
                              onSavedFn: (value) async {
                                productModel.name = value!;
                              },
                            ),
                          ),
                          SizedBox(
                            width: 10.w,
                          ),
                          Expanded(
                            child: CustomTextFormField(
                              initialValue: productModel.quantity,
                              keyboardType: TextInputType.number,
                              title: '',
                              hintText: '53'.tr,
                              validatorFn: (value) {
                                if (value!.isEmpty) {
                                  return '54'.tr;
                                }
                                return null;
                              },
                              onSavedFn: (value) {
                                productModel.quantity = value!;
                              },
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: CustomTextFormField(
                              initialValue: productModel.sellingprice,
                              keyboardType: TextInputType.number,
                              title: '',
                              hintText: '\$ 57'.tr,
                              validatorFn: (value) {
                                if (value!.isEmpty) {
                                  return '58'.tr;
                                }
                                return null;
                              },
                              onSavedFn: (value) {
                                productModel.sellingprice = value!;
                              },
                            ),
                          ),
                          SizedBox(
                            width: 10.w,
                          ),
                          Expanded(
                            child: CustomTextFormField(
                              initialValue: productModel.purchaseprice,
                              keyboardType: TextInputType.number,
                              title: '',
                              hintText: '55'.tr,
                              validatorFn: (value) {
                                if (value!.isEmpty) {
                                  return '56'.tr;
                                }
                                return null;
                              },
                              onSavedFn: (value) {
                                productModel.purchaseprice = value!;
                              },
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 3.h,
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: GestureDetector(
                              onTap: () {
                                //c.selectDate(context);
                                c.dateTimePickerWidget(context);
                              },
                              child: Container(
                                alignment: Alignment.centerLeft,
                                width: 100,
                                height: 100,
                                child: Obx(
                                  () => Text(
                                    c.selectedDateTime.value,
                                    style: TextStyle(fontSize: 12.sp),
                                  ),
                                ),
                                // Text(c.selectedDateTime.toString()),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 10.w,
                          ),
                          GestureDetector(
                            onTap: () {
                              c.pickColor();
                            },
                            child: Container(
                              margin: const EdgeInsets.only(right: 20),
                              alignment: Alignment.center,
                              width: 17.w,
                              height: 17.w,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: resultColor,
                              ),
                              child: Text(
                                '59'.tr,
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 4.h,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            alignment: Alignment.center,
                            width: MediaQuery.of(context).size.width * .4,
                            height: 5.h,
                            color: Colors.blue[50],
                            child: Text(
                              productModel.storeName,
                              // c.selectedItem.value,
                              style: TextStyle(
                                fontSize: 12.sp,
                              ),
                            ),
                          ),
                          Container(
                            alignment: Alignment.center,
                            width: MediaQuery.of(context).size.width * .4,
                            height: 5.h,
                            color: Colors.blue[50],
                            child: Text(
                              productModel.category,
                              // c.selectedItem.value,
                              style: TextStyle(
                                fontSize: 12.sp,
                              ),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            flex: 2,
                            child: CustomTextFormField(
                              initialValue: productModel.details,
                              title: '',
                              hintText: '49'.tr,
                              validatorFn: (value) {
                                if (value!.isEmpty) {
                                  return '63'.tr;
                                }
                                return null;
                              },
                              onSavedFn: (value) {
                                productModel.details = value!;
                              },
                            ),
                          ),
                          SizedBox(
                            width: 10.w,
                          ),
                          Expanded(
                            flex: 1,
                            child: CustomTextFormField(
                              initialValue: productModel.barcode,
                              keyboardType: TextInputType.number,
                              title: '',
                              hintText: '60'.tr,
                              validatorFn: (value) {
                                if (value!.isEmpty) {
                                  return '61'.tr;
                                }
                                return null;
                              },
                              onSavedFn: (value) {
                                productModel.barcode = value!;
                              },
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 7.h,
                      ),
                      SizedBox(
                        height: 200,
                        width: 300,
                        child: IconButton(
                          icon: productModel.image == null
                              ? Image.asset(ImagesAssets.product)
                              : CachedNetworkImage(
                                  imageUrl: productModel.image,
                                  progressIndicatorBuilder: (
                                    context,
                                    url,
                                    downloadProgress,
                                  ) =>
                                      CircularProgressIndicator(
                                          value: downloadProgress.progress),
                                  errorWidget: (context, url, error) =>
                                      const Icon(Icons.error),
                                ),
                          iconSize: 50,
                          onPressed: () {
                            Get.dialog(
                              AlertDialog(
                                title: CustomText(
                                  text: '64'.tr,
                                  fontSize: 12.sp,
                                  color: Colors.blue,
                                ),
                                content: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Divider(
                                      height: 1,
                                    ),
                                    ListTile(
                                      onTap: () async {
                                        try {
                                          await c.cameraImage();
                                          Get.back();
                                        } catch (error) {
                                          Get.back();
                                        }
                                      },
                                      title: CustomText(
                                        text: '65'.tr,
                                      ),
                                      leading: const Icon(
                                        Icons.camera,
                                        color: Colors.blue,
                                      ),
                                    ),
                                    const Divider(
                                      height: 1,
                                    ),
                                    ListTile(
                                      onTap: () async {
                                        try {
                                          await c.galleryImage();
                                          Get.back();
                                        } catch (error) {
                                          Get.back();
                                        }
                                      },
                                      title: CustomText(
                                        text: '66'.tr,
                                      ),
                                      leading: const Icon(
                                        Icons.account_box,
                                        color: Colors.blue,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  CustomButton submitProduct() {
    return CustomButton(
      'update'.toUpperCase(),
      () async {
        if (_formKey.currentState!.validate()) {
          _formKey.currentState!.save();

          c.productId = productModel.productId;
          await c.updateProductToFireStore(productModel);

          Get.dialog(
            AlertDialog(
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.check_circle_outline_outlined,
                      color: appColor,
                      size: 100,
                    ),
                    CustomText(
                      text: '75'.tr,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.bold,
                      color: primaryColor,
                      alignment: Alignment.center,
                    ),
                    const SizedBox(
                      height: 40,
                    ),
                    CustomButton(
                      '73'.tr,
                      () {
                        Get.offNamed(Routes.ALLPRODUCTS);
                      },
                    ),
                  ],
                ),
              ),
            ),
            barrierDismissible: false,
          );
        }
      },
    );
  }

  dropDownList() {
    return PopupMenuButton<String>(
      iconSize: 3.h,
      onSelected: (value) async {
        c.handleClickproductDetails(value);
        // c.phone = customerModel.phone;
        // c.email = customerModel.email;
      }, //
      itemBuilder: (BuildContext context) {
        return {
          'Export To Excel',
          'Print To Pdf',
        }.map((String choice) {
          return PopupMenuItem<String>(
            value: choice,
            child: Text(
              choice,
              style: TextStyle(
                color: Colors.black,
                fontSize: 12.sp,
              ),
            ),
          );
        }).toList();
      },
    );
  }
}
