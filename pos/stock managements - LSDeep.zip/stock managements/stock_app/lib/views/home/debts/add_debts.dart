// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/debts_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/core/functions/handle.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/views/home/debts/debtsby_customer.dart';
import 'package:stock_app/views/home/debts/debtsby_supplier.dart';
import 'package:stock_app/widgets/custom_button.dart';
import 'package:stock_app/widgets/custom_text.dart';
import 'package:stock_app/widgets/custom_textFormField.dart';

class AddDebts extends StatelessWidget {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final c = Get.find<DebtsController>();

  final String? title;
  AddDebts({super.key, this.title});
  @override
  Widget build(BuildContext context) {
    c.title.value = title!;
    return Scaffold(
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.only(left: 10, right: 10, top: 10),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          onPressed: () {
                            if (title == 'New Debts Customer') {
                              openDialogExit(Routes.DebtsCustomer);
                            } else if (title == 'New Debts Supplier') {
                              openDialogExit(Routes.DebtsSuppliers);
                            }

                            // Get.back();
                          },
                          icon: const Icon(
                            Icons.arrow_back_ios,
                            color: Colors.red,
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Text(
                          title!,
                          //'136'.tr,
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 16.sp,
                            // fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    submit(),
                  ],
                ),
                Row(
                  children: [
                    GestureDetector(
                      onTap: () async {
                        c.addClientName();
                      },
                      child: Obx(
                        () => Container(
                          alignment: Alignment.center,
                          width: MediaQuery.of(context).size.width * .4,
                          height: 5.h,
                          color: Colors.blue[50],
                          child: Text(
                            c.selectClientName.value,
                            //  c.selectedcustomerType.value,
                            style: TextStyle(
                              fontSize: 14.sp,
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10.w,
                    ),
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          c.dateTimePickerWidget(context);
                        },
                        child: Obx(
                          () => Container(
                            alignment: Alignment.center,
                            width: 100,
                            height: 100,
                            child: Text(
                              c.selectedDateTime.value,
                              style: const TextStyle(
                                fontSize: 18,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                CustomTextFormField(
                  keyboardType: TextInputType.number,
                  title: '',
                  hintText: '137'.tr,
                  validatorFn: (value) {
                    if (value!.isEmpty) {
                      return '138'.tr;
                    }
                    return null;
                  },
                  onSavedFn: (value) {
                    c.totalDebt = value!;
                  },
                ),
                SizedBox(
                  height: 2.h,
                ),
                CustomTextFormField(
                  keyboardType: TextInputType.number,
                  title: '',
                  hintText: '139'.tr,
                  validatorFn: (value) {
                    if (value!.isEmpty) {
                      return '140'.tr;
                    }
                    return null;
                  },
                  onSavedFn: (value) {
                    c.amountReceived = value!;
                  },
                ),
                SizedBox(
                  height: 2.h,
                ),
                CustomTextFormField(
                  keyboardType: TextInputType.number,
                  title: '',
                  hintText: '141'.tr,
                  validatorFn: (value) {
                    if (value!.isEmpty) {
                      return '142'.tr;
                    }
                    return null;
                  },
                  onSavedFn: (value) {
                    c.remainingDebt = value!;
                  },
                ),
                SizedBox(
                  height: 2.h,
                ),
                CustomTextFormField(
                  title: '',
                  hintText: '130'.tr,
                  validatorFn: (value) {
                    if (value!.isEmpty) {
                      return '131'.tr;
                    }
                    return null;
                  },
                  onSavedFn: (value) {
                    c.notes = value!;
                  },
                ),
                SizedBox(
                  height: 2.h,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  CustomButton submit() {
    return CustomButton(
      'submit'.toUpperCase(),
      () async {
        if (c.selectClientName.value == 'Pick Client' ||
            c.selectedDateTime.value == 'Pick Date') {
          Get.snackbar('70'.tr, '143'.tr, snackPosition: SnackPosition.TOP);
        } else {
          if (_formKey.currentState!.validate()) {
            _formKey.currentState!.save();
            await c.addDebtsToFireStore();

            Get.dialog(
              AlertDialog(
                content: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.check_circle_outline_outlined,
                        color: appColor,
                        size: 100,
                      ),
                      CustomText(
                        text: '146'.tr,
                        fontSize: 14.sp,
                        fontWeight: FontWeight.bold,
                        color: primaryColor,
                        alignment: Alignment.center,
                      ),
                      const SizedBox(
                        height: 40,
                      ),
                      CustomButton(
                        '73'.tr,
                        () {
                          if (title == 'New Debts Customer') {
                            Get.back();
                            Get.to(const ListDebtsCustomers(''));
                            //  Get.toNamed(Routes.lis);
                          } else if (title == 'New Debts Supplier') {
                            Get.back();
                            Get.to(const ListDebtsSuppliers(''));
                            // Get.toNamed(Routes.Outgoing);
                          } else {
                            Get.back();
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ),
              barrierDismissible: false,
            );

            //  Get.back();
          }
        }
      },
    );
  }
}
