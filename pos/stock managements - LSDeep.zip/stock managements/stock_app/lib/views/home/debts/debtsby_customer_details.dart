// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/debts_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/models/debts_model.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/widgets/custom_button.dart';
import 'package:stock_app/widgets/custom_text.dart';
import 'package:stock_app/widgets/custom_textFormField.dart';

class DebtCustomerDetails extends StatelessWidget {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final c = Get.find<DebtsController>();

  final DebtsModel debtsModel;

  DebtCustomerDetails({required this.debtsModel, super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('144'.tr),
            submit(),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: [
                SizedBox(
                  height: 2.h,
                ),
                Row(
                  children: [
                    GestureDetector(
                      onTap: () async {
                        c.addClientName();
                      },
                      child: Obx(
                        () => Container(
                          alignment: Alignment.center,
                          width: MediaQuery.of(context).size.width * .4,
                          height: 5.h,
                          color: Colors.blue[50],
                          child: Text(
                            c.selectClientName.value,
                            style: const TextStyle(
                              fontSize: 18,
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 15.w,
                    ),
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          c.dateTimePickerWidget(context);
                        },
                        child: Obx(
                          () => Container(
                            alignment: Alignment.center,
                            width: 100,
                            height: 100,
                            child: Text(
                              c.selectedDateTime.value,
                              //c.selectdate.toString(),
                              style: TextStyle(
                                fontSize: 14.sp,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                CustomTextFormField(
                  initialValue: debtsModel.totalDebt,
                  keyboardType: TextInputType.number,
                  title: '',
                  hintText: '137'.tr,
                  validatorFn: (value) {
                    if (value!.isEmpty) {
                      return '138'.tr;
                    }
                    return null;
                  },
                  onSavedFn: (value) {
                    debtsModel.totalDebt = value!;
                  },
                ),
                SizedBox(
                  height: 2.h,
                ),
                CustomTextFormField(
                  initialValue: debtsModel.amountReceived,
                  keyboardType: TextInputType.number,
                  title: '',
                  hintText: '139'.tr,
                  validatorFn: (value) {
                    if (value!.isEmpty) {
                      return '138'.tr;
                    }
                    return null;
                  },
                  onSavedFn: (value) {
                    debtsModel.amountReceived = value!;
                  },
                ),
                SizedBox(
                  height: 2.h,
                ),
                CustomTextFormField(
                  initialValue: debtsModel.remainingDebt,
                  keyboardType: TextInputType.number,
                  title: '',
                  hintText: '141'.tr,
                  validatorFn: (value) {
                    if (value!.isEmpty) {
                      return '140'.tr;
                    }
                    return null;
                  },
                  onSavedFn: (value) {
                    debtsModel.remainingDebt = value!;
                  },
                ),
                SizedBox(
                  height: 2.h,
                ),
                CustomTextFormField(
                  initialValue: debtsModel.notes,
                  title: '',
                  hintText: '130'.tr,
                  validatorFn: (value) {
                    if (value!.isEmpty) {
                      return '131'.tr;
                    }
                    return null;
                  },
                  onSavedFn: (value) {
                    debtsModel.notes = value!;
                  },
                ),
                SizedBox(
                  height: 2.h,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  CustomButton submit() {
    return CustomButton(
      'update'.toUpperCase(),
      () async {
        if (_formKey.currentState!.validate()) {
          _formKey.currentState!.save();
          await c.updateDebtsToFireStore(debtsModel);

          Get.dialog(
            AlertDialog(
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.check_circle_outline_outlined,
                      color: appColor,
                      size: 100,
                    ),
                    CustomText(
                      text: '146'.tr,
                      fontSize: 14.sp,
                      fontWeight: FontWeight.bold,
                      color: primaryColor,
                      alignment: Alignment.center,
                    ),
                    const SizedBox(
                      height: 40,
                    ),
                    CustomButton(
                      '73'.tr,
                      () {
                        // Get.back();
                        // Get.to(const ListDebtsCustomers(''));
                        // Get.off(const ListDebtsCustomers(''));
                        Get.offNamed(Routes.DebtsCustomer);
                      },
                    ),
                  ],
                ),
              ),
            ),
            barrierDismissible: false,
          );
        }
      },
    );
  }
}
