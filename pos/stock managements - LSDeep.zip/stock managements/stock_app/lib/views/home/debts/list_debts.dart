import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stock_app/core/constants/app_images.dart';
import 'package:stock_app/routes.dart';

class ListDebts extends StatelessWidget {
  const ListDebts({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          const SizedBox(
            height: 20,
          ),
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: IconButton(
                  onPressed: () {
                    //Get.back();
                    Get.offNamed(Routes.MAINHOME);
                  },
                  icon: const Icon(
                    Icons.arrow_back_ios,
                    color: Colors.red,
                  ),
                ),
              ),
              const SizedBox(
                width: 20,
              ),
              Text(
                '148'.tr,
                style: const TextStyle(
                  color: Colors.black,
                  fontSize: 22,
                  // fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 20,
          ),
          ListTile(
            leading: Image.asset(
              ImagesAssets.product,
              cacheHeight: 105,
              cacheWidth: 105,
            ),
            title: Text(
              '149'.tr,
              style: const TextStyle(
                fontSize: 18,
              ),
            ),
            onTap: () {
              Get.toNamed(Routes.DebtsCustomer);
              //  Get.to(const ListDebtsCustomers(''));
            },
          ),
          ListTile(
            leading: Image.asset(
              ImagesAssets.bestProduct,
              cacheHeight: 105,
              cacheWidth: 105,
            ),
            title: Text(
              '150'.tr,
              style: const TextStyle(
                fontSize: 18,
              ),
            ),
            onTap: () {
              Get.toNamed(Routes.DebtsSuppliers);
              // Get.to(const ListDebtsSuppliers(''));
            },
          ),
        ],
      ),
    );
  }
}
