// ignore_for_file: prefer_final_fields

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/auth_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/views/auth/login_view.dart';

// ignore: must_be_immutable
class RegisterView extends GetWidget<AuthController> {
  RegisterView({super.key});

  GlobalKey<FormState> _key = GlobalKey();
  AutovalidateMode _validate = AutovalidateMode.disabled;
  TextEditingController _passwordController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: Colors.transparent,
        iconTheme: const IconThemeData(color: Colors.black),
      ),
      body: controller.loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : SingleChildScrollView(
              child: Container(
                margin:
                    const EdgeInsets.only(left: 16.0, right: 16, bottom: 16),
                child: Form(
                  key: _key,
                  autovalidateMode: _validate,
                  child: Column(
                    children: <Widget>[
                      Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            '16'.tr,
                            style: const TextStyle(
                                color: appColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 20.0),
                          )),
                      SizedBox(
                        height: 10.h,
                      ),
                      ConstrainedBox(
                          constraints:
                              const BoxConstraints(minWidth: double.infinity),
                          child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 8),
                              child: TextFormField(
                                  validator: validateName,
                                  onSaved: (val) => controller.name = val,
                                  textInputAction: TextInputAction.next,
                                  decoration: InputDecoration(
                                      contentPadding:
                                          const EdgeInsets.symmetric(
                                              vertical: 8, horizontal: 16),
                                      fillColor: Colors.white,
                                      hintText: '17'.tr,
                                      focusedBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(15.0),
                                          borderSide: const BorderSide(
                                              color: appColor, width: 2.0)),
                                      border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(15.0),
                                      ))))),
                      ConstrainedBox(
                          constraints:
                              const BoxConstraints(minWidth: double.infinity),
                          child: Padding(
                              padding: const EdgeInsets.only(
                                  top: 16.0, right: 8.0, left: 8.0),
                              child: TextFormField(
                                  keyboardType: TextInputType.emailAddress,
                                  textInputAction: TextInputAction.next,
                                  validator: validateEmail,
                                  onSaved: (val) => controller.email = val,
                                  decoration: InputDecoration(
                                      contentPadding:
                                          const EdgeInsets.symmetric(
                                              vertical: 8, horizontal: 16),
                                      fillColor: Colors.white,
                                      hintText: '18'.tr,
                                      focusedBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(15.0),
                                          borderSide: const BorderSide(
                                              color: appColor, width: 2.0)),
                                      border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(15.0),
                                      ))))),
                      ConstrainedBox(
                          constraints:
                              const BoxConstraints(minWidth: double.infinity),
                          child: Padding(
                            padding: const EdgeInsets.only(
                                top: 16.0, right: 8.0, left: 8.0),
                            child: TextFormField(
                                obscureText: true,
                                textInputAction: TextInputAction.next,
                                controller: _passwordController,
                                validator: validatePassword,
                                onSaved: (val) => controller.password = val,
                                // style: const TextStyle(height: 0.8, fontSize: 18.0),
                                cursorColor: appColor,
                                decoration: InputDecoration(
                                    contentPadding: const EdgeInsets.symmetric(
                                        vertical: 8, horizontal: 16),
                                    fillColor: Colors.white,
                                    hintText: '19'.tr,
                                    focusedBorder: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(15.0),
                                        borderSide: const BorderSide(
                                            color: appColor, width: 2.0)),
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15.0),
                                    ))),
                          )),
                      ConstrainedBox(
                        constraints:
                            const BoxConstraints(minWidth: double.infinity),
                        child: Padding(
                          padding: const EdgeInsets.only(
                              top: 16.0, right: 8.0, left: 8.0),
                          child: TextFormField(
                              textInputAction: TextInputAction.done,
                              // onFieldSubmitted: (_) => _signUp(),
                              obscureText: true,
                              validator: (val) => validateConfirmPassword(
                                  _passwordController.text, val),
                              onSaved: (val) =>
                                  controller.confirmPassword = val,
                              //style: const TextStyle(height: 0.8, fontSize: 18.0),
                              cursorColor: appColor,
                              decoration: InputDecoration(
                                  contentPadding: const EdgeInsets.symmetric(
                                      vertical: 8, horizontal: 16),
                                  fillColor: Colors.white,
                                  hintText: '20'.tr,
                                  focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(15.0),
                                      borderSide: const BorderSide(
                                          color: appColor, width: 2.0)),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(15.0),
                                  ))),
                        ),
                      ),
                      const SizedBox(
                        height: 100,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 60),
                        child: ConstrainedBox(
                          constraints:
                              const BoxConstraints(minWidth: double.infinity),
                          child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: appColor,
                                padding:
                                    const EdgeInsets.only(top: 12, bottom: 12),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15.0),
                                  side: const BorderSide(
                                    color: appColor,
                                  ),
                                ),
                              ),
                              child: Text(
                                '21'.tr,
                                style: const TextStyle(
                                  //  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                              onPressed: () {
                                if (_key.currentState!.validate()) {
                                  _key.currentState!.save();
                                  controller.loading
                                      ? const Center(
                                          child: CircularProgressIndicator(),
                                        )
                                      : controller.signUpWithEmailAndPassword();
                                }
                              }),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
}

class RegisterForm extends StatelessWidget {
  const RegisterForm({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
