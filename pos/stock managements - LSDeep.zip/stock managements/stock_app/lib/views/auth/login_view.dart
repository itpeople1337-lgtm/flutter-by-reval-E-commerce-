// ignore_for_file: prefer_final_fields, constant_identifier_names

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/auth_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/views/auth/register_view.dart';
import 'package:stock_app/widgets/custom_text.dart';

// const FACEBOOK_BUTTON_COLOR = 0xFF415893;

class LoginView extends GetWidget<AuthController> {
  GlobalKey<FormState> _key = GlobalKey();
  AutovalidateMode _validate = AutovalidateMode.disabled;

  LoginView({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        iconTheme: const IconThemeData(color: Colors.black),
        elevation: 0.0,
      ),
      body: controller.loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : Form(
              key: _key,
              autovalidateMode: _validate,
              child: ListView(
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.only(right: 16.0, left: 16.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        CustomText(
                          text: '22'.tr,
                          fontSize: 14.sp,
                          fontWeight: FontWeight.bold,
                        ),
                        GestureDetector(
                          onTap: () {
                            Get.to(
                              RegisterView(),
                              transition: Transition.leftToRight,
                              duration: const Duration(milliseconds: 400),
                            );
                            //  Get.to(RegisterView());SignUpScreen
                          },
                          child: CustomText(
                            text: '21'.tr,
                            fontSize: 14.sp,
                            color: appColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 6.h,
                  ),
                  ConstrainedBox(
                    constraints:
                        const BoxConstraints(minWidth: double.infinity),
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 6.w),
                      child: TextFormField(
                          textAlignVertical: TextAlignVertical.center,
                          textInputAction: TextInputAction.next,
                          validator: validateEmail,
                          onSaved: (val) => controller.email = val,
                          onFieldSubmitted: (_) =>
                              FocusScope.of(context).nextFocus(),
                          //  style: const TextStyle(fontSize: 18.0),
                          keyboardType: TextInputType.emailAddress,
                          cursorColor: appColor, // appColor,
                          decoration: InputDecoration(
                              contentPadding:
                                  const EdgeInsets.only(left: 16, right: 16),
                              fillColor: Colors.white,
                              hintText: '18'.tr,
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15.0),
                                  borderSide: const BorderSide(
                                      color: appColor, width: 2.0)),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15.0),
                              ))),
                    ),
                  ),
                  SizedBox(
                    height: 2.h,
                  ),
                  ConstrainedBox(
                    constraints:
                        const BoxConstraints(minWidth: double.infinity),
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 6.w),
                      child: TextFormField(
                        textAlignVertical: TextAlignVertical.center,
                        validator: validatePassword,
                        onSaved: (val) => controller.password = val,
                        onFieldSubmitted: (password) async {
                          //  await login();
                        },
                        obscureText: true,
                        textInputAction: TextInputAction.done,
                        // style: const TextStyle(fontSize: 18.0),
                        cursorColor: appColor,
                        decoration: InputDecoration(
                          contentPadding:
                              const EdgeInsets.only(left: 16, right: 16),
                          fillColor: Colors.white,
                          hintText: '19'.tr,
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15.0),
                              borderSide: const BorderSide(
                                  color: appColor, width: 2.0)),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15.0),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 60,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 70),
                    child: ConstrainedBox(
                      constraints:
                          const BoxConstraints(minWidth: double.infinity),
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: appColor,
                          padding: const EdgeInsets.only(top: 12, bottom: 12),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25.0),
                              side: const BorderSide(color: appColor)),
                        ),
                        child: Text(
                          '23'.tr,
                          style: const TextStyle(
                            // fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        onPressed: () {
                          if (_key.currentState!.validate()) {
                            _key.currentState!.save();

                            controller.signInWithEmailAndPassword();
                          }
                          //   login(),
                        },
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  CustomText(
                    text: '24'.tr,
                    fontSize: 18,
                    alignment: Alignment.center,
                  ),
                  SizedBox(
                    height: 16.h,
                  ),
                  // Note: sign in with Facebook is configured but i don't prefer it for this app
                  CustomButtonSocial(
                    title: '25'.tr,
                    image: '26'.tr,
                    onPressedFn: () {
                      // controller.signInWithFacebookAccount();
                    },
                  ),
                  SizedBox(
                    height: 2.h,
                  ),
                  CustomButtonSocial(
                    title: '27'.tr,
                    image: 'google',
                    onPressedFn: () {
                      controller.signInWithGoogleAccount();
                    },
                  ),
                ],
              ),
            ),
    );
  }
}

String? validateName(String? value) {
  String pattern = r'(^[a-zA-Z ]*$)';
  RegExp regExp = RegExp(pattern);
  if (value!.isEmpty) {
    return "29".tr;
  } else if (!regExp.hasMatch(value ?? '')) {
    return "30".tr;
  }
  return null;
}

String? validateMobile(String? value) {
  String pattern = r'(^\+?[0-9]*$)';
  RegExp regExp = RegExp(pattern);
  if (value!.isEmpty) {
    return "31".tr;
  } else if (!regExp.hasMatch(value ?? '')) {
    return "32".tr;
  }
  return null;
}

String? validatePassword(String? value) {
  if ((value?.length ?? 0) < 6) {
    return '33'.tr;
  } else {
    return null;
  }
}

String? validateEmail(String? value) {
  String pattern =
      r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
  RegExp regex = RegExp(pattern);
  if (!regex.hasMatch(value ?? '')) {
    return '34'.tr;
  } else {
    return null;
  }
}

String? validateConfirmPassword(String? password, String? confirmPassword) {
  if (password != confirmPassword) {
    return '35'.tr;
  } else if (confirmPassword!.isEmpty) {
    return '36'.tr;
  } else {
    return null;
  }
}

class CustomButtonSocial extends StatelessWidget {
  final VoidCallback onPressedFn;
  final String image;
  final String title;

  const CustomButtonSocial({
    super.key,
    required this.onPressedFn,
    required this.image,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 3.w),
      child: OutlinedButton(
        onPressed: onPressedFn,
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 1.h, horizontal: 3.w),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Image.asset(
                'assets/images/icons/$image.png',
                fit: BoxFit.cover,
                height: 3.5.h,
                width: 3.5.h,
              ),
              CustomText(
                text: title,
                fontSize: 10.sp,
              ),
              Container(width: 5.h),
            ],
          ),
        ),
      ),
    );
  }
}
