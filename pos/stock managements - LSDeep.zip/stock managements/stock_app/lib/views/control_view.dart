import 'package:ant_icons/ant_icons.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/auth_controller.dart';
import 'package:stock_app/controllers/control_controller.dart';
import 'package:stock_app/controllers/network_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/views/onboarding/onboarding.dart';
import 'package:stock_app/widgets/custom_text.dart';

class ControlView extends StatelessWidget {
  const ControlView({super.key});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return Get.find<AuthController>().user == null
          ? const OnBoarding() //LoginView()
          : Get.find<NetworkController>().connectionStatus.value == 1 ||
                  Get.find<NetworkController>().connectionStatus.value == 2
              ? GetBuilder<ControlController>(
                  init: ControlController(),
                  builder: (controller) => Scaffold(
                    //extendBody: true,
                    body: controller.currentScreen,
                    bottomNavigationBar: const CustomBottomNavigationBar(),
                  ),
                )
              : const NoInternetConnection();
    });
  }
}

class CustomBottomNavigationBar extends StatelessWidget {
  const CustomBottomNavigationBar({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ControlController>(
      //height: 84.h,
      builder: (controller) => Container(
        color: controller.bg,
        child: ClipRRect(
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(20.0),
            topRight: Radius.circular(20.0),
          ),
          child: BottomNavigationBar(
            showSelectedLabels: false,
            showUnselectedLabels: false,
            elevation: 10,
            backgroundColor: baseColor,
            currentIndex: controller.navigatorIndex,
            onTap: (index) {
              controller.changeCurrentScreen(index);
            },
            items: [
              BottomNavigationBarItem(
                backgroundColor: baseColor,
                label: '',
                icon: const Icon(
                  Icons.analytics_outlined,
                  color: secondColor,
                ),
                activeIcon: CustomText(
                  text: '224'.tr,
                  color: Colors.white,
                  fontSize: 10.sp,
                  alignment: Alignment.center,
                ),
              ),
              BottomNavigationBarItem(
                // backgroundColor: primaryColor2,
                backgroundColor: baseColor,
                label: '',
                icon: const Icon(
                  AntIcons.home,
                  color: secondColor,
                ),
                activeIcon: CustomText(
                  text: '223'.tr,
                  color: Colors.white,
                  fontSize: 10.sp,
                  alignment: Alignment.center,
                ),
              ),
              BottomNavigationBarItem(
                backgroundColor: baseColor,
                label: '',
                icon: const Icon(
                  AntIcons.user_add_outline,
                  color: secondColor,
                ),
                activeIcon: CustomText(
                  text: '222'.tr,
                  color: Colors.white,
                  fontSize: 10.sp,
                  alignment: Alignment.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class NoInternetConnection extends StatelessWidget {
  const NoInternetConnection({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(),
            SizedBox(
              height: 30.h,
            ),
            CustomText(
              text: '221'.tr,
              fontSize: 14,
              alignment: Alignment.center,
            ),
          ],
        ),
      ),
    );
  }
}
