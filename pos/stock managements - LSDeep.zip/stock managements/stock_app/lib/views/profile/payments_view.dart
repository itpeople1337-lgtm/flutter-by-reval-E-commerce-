import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/views/profile/card.dart';
import 'package:stock_app/views/profile/paypal.dart';
import 'package:stock_app/widgets/custom_text.dart';

class PaymentsView extends StatelessWidget {
  const PaymentsView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(
            height: 13.h,
            child: Padding(
              padding: EdgeInsets.only(bottom: 2.h, left: 4.w, right: 4.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  IconButton(
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: () {
                      Get.back();
                    },
                    icon: const Icon(
                      Icons.arrow_back_ios,
                      color: Colors.black,
                    ),
                  ),
                  CustomText(
                    text: 'Payments',
                    fontSize: 16.sp,
                    alignment: Alignment.bottomCenter,
                  ),
                  Container(
                    width: 24,
                  ),
                ],
              ),
            ),
          ),
          SizedBox(
            height: 2.h,
          ),
          GestureDetector(
            onTap: () {
              Get.to(const Paypal(
                title: 'Pay by Paypal ',
              ));
            },
            child: Container(
              color: secondColor,
              height: 22.h,
              width: 80.w,
              child: const Center(
                  child: Text(
                'Paypal',
                style: TextStyle(
                  fontSize: 30,
                  color: Colors.white,
                ),
              )),
              // child: const Paypal(),
            ),
          ),
          SizedBox(
            height: 2.h,
          ),
          GestureDetector(
            onTap: () {
              Get.to(
                const CreditCardView(),
              );
            },
            child: Container(
              color: secondColor,
              height: 22.h,
              width: 80.w,
              child: const Center(
                  child: Text(
                'Credit Card',
                style: TextStyle(
                  fontSize: 30,
                  color: Colors.white,
                ),
              )),
            ),
          ),
        ],
      ),
    );
  }
}
