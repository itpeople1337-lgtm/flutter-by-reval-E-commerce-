import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/auth_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/core/constants/app_images.dart';
import 'package:stock_app/views/profile/edit_profile_view.dart';
import 'package:stock_app/views/profile/notifications.dart';
import 'package:stock_app/views/profile/payments_view.dart';
import 'package:stock_app/widgets/custom_text.dart';

class ProfileView extends StatelessWidget {
  const ProfileView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appColor,
      body: GetBuilder<AuthController>(
        init: AuthController(),
        builder: (controller) => controller.loading == true
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.only(
                    top: 3.h,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 16),
                            child: CircleAvatar(
                                radius: 8.h,
                                backgroundImage: const AssetImage(
                                    'assets/images/profile_pic.png'),
                                foregroundImage: controller.currentUser!.pic ==
                                        null
                                    ? const NetworkImage(
                                        'https://pixlok.com/wp-content/uploads/2021/02/profile-Icon-SVG.jpg')
                                    : NetworkImage(
                                        controller.currentUser!.pic!)),
                          ),
                          SizedBox(
                            height: 3.h,
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CustomText(
                                alignment: Alignment.center,
                                // text: 'name',
                                text: controller.currentUser!.name!,
                                fontSize: 16.sp,
                                color: primaryColor,
                              ),
                              SizedBox(
                                height: 2.h,
                              ),
                              CustomText(
                                alignment: Alignment.center,
                                //text: 'email',
                                text: controller.currentUser!.email!,
                                fontSize: 12.sp,
                                color: Colors.white,
                              ),
                            ],
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 6.h,
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 30),
                        padding: const EdgeInsets.only(top: 20, bottom: 20),
                        decoration: const BoxDecoration(
                            // color: Colors.indigo,

                            ),
                        child: Column(
                          children: [
                            CustomListTile(
                              iconName: '1',
                              title: '162'.tr,
                              onTapFn: () {
                                Get.to(
                                  () => const EditProfileView(),
                                  transition: Transition.leftToRight,
                                  duration: const Duration(milliseconds: 400),
                                );
                              },
                            ),
                            CustomListTile(
                              iconName: '4',
                              title: '163'.tr,
                              onTapFn: () {
                                Get.to(
                                  () => const PaymentsView(),
                                  transition: Transition.leftToRight,
                                  duration: const Duration(milliseconds: 400),
                                );
                              },
                            ),
                            CustomListTile(
                              iconName: '5',
                              title: '239'.tr,
                              onTapFn: () {
                                Get.to(
                                  () => const NotificationsA(),
                                  transition: Transition.leftToRight,
                                  duration: const Duration(milliseconds: 400),
                                );
                              },
                            ),
                            CustomListTile(
                              iconName: '6',
                              title: '164'.tr,
                              onTapFn: () {
                                Get.find<AuthController>().signOut();
                              },
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}

class CustomListTile extends StatelessWidget {
  final String iconName;
  final String title;
  final VoidCallback onTapFn;

  const CustomListTile({
    super.key,
    required this.iconName,
    required this.title,
    required this.onTapFn,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListTile(
          onTap: onTapFn,
          leading: Image.asset(
            '${ImagesAssets.rootIcons}/menu_icons/$iconName.png',
            height: 6.h,
            width: 6.h,
            color: Colors.white,
          ),
          title: CustomText(
            text: title,
            fontSize: 11.sp,
            color: primaryColor,
          ),
          trailing: title == 'Log Out'
              ? null
              : const Icon(
                  Icons.navigate_next,
                  color: Colors.white,
                ),
        ),
        SizedBox(
          height: 3.h,
        ),
      ],
    );
  }
}
