import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/controllers/auth_controller.dart';
import 'package:stock_app/core/constants/app_images.dart';
import 'package:stock_app/widgets/custom_button.dart';
import 'package:stock_app/widgets/custom_text.dart';
import 'package:stock_app/widgets/custom_textFormField.dart';

class EditProfileView extends StatefulWidget {
  const EditProfileView({super.key});

  @override
  _EditProfileViewState createState() => _EditProfileViewState();
}

class _EditProfileViewState extends State<EditProfileView> {
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    String loginMethod =
        FirebaseAuth.instance.currentUser!.providerData[0].providerId;

    return Scaffold(
      // backgroundColor: appColor,
      body: Column(
        children: [
          SizedBox(
            height: 13.h,
            child: Padding(
              padding: EdgeInsets.only(bottom: 2.h, left: 4.w, right: 4.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  IconButton(
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    onPressed: () {
                      Get.back();
                    },
                    icon: const Icon(
                      Icons.arrow_back_ios,
                      color: Colors.black,
                    ),
                  ),
                  CustomText(
                    text: 'Edit Profile',
                    fontSize: 16.sp,
                    alignment: Alignment.bottomCenter,
                  ),
                  Container(
                    width: 24,
                  ),
                ],
              ),
            ),
          ),
          GetBuilder<AuthController>(
            init: AuthController(),
            builder: (controller) => Expanded(
              child: SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.only(right: 4.w, left: 4.w, bottom: 2.h),
                  child: Card(
                    child: Padding(
                      padding: EdgeInsets.all(16),
                      child: loginMethod == 'google.com' ||
                              loginMethod == 'facebook.com'
                          ? Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset(
                                  loginMethod == 'google.com'
                                      ? ImagesAssets.google
                                      : ImagesAssets.facebook,
                                  fit: BoxFit.cover,
                                  height: 6.h,
                                  width: 6.h,
                                ),
                                SizedBox(
                                  height: 3.h,
                                ),
                                CustomText(
                                  text: loginMethod == 'google.com'
                                      ? 'You\'re logged in using Google account!'
                                      : 'You\'re logged in using Facebook account!',
                                  fontSize: 10.sp,
                                  alignment: Alignment.center,
                                ),
                              ],
                            )
                          : Form(
                              key: _formKey,
                              child: Column(
                                children: [
                                  Row(
                                    children: [
                                      CircleAvatar(
                                        radius: 6.h,
                                        backgroundImage: const AssetImage(
                                          ImagesAssets.profile,
                                        ),
                                        foregroundImage: controller.imageFile !=
                                                null
                                            ? FileImage(controller.imageFile!)
                                            : null,
                                      ),
                                      SizedBox(
                                        width: 10.w,
                                      ),
                                      ElevatedButton(
                                        onPressed: () {
                                          Get.dialog(
                                            AlertDialog(
                                              title: CustomText(
                                                text: 'Choose option',
                                                fontSize: 12.sp,
                                                color: Colors.blue,
                                              ),
                                              content: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  const Divider(
                                                    height: 1,
                                                  ),
                                                  ListTile(
                                                    onTap: () async {
                                                      try {
                                                        await controller
                                                            .cameraImage();
                                                        Get.back();
                                                      } catch (error) {
                                                        Get.back();
                                                      }
                                                    },
                                                    title: const CustomText(
                                                      text: 'Camera',
                                                    ),
                                                    leading: const Icon(
                                                      Icons.camera,
                                                      color: Colors.blue,
                                                    ),
                                                  ),
                                                  const Divider(
                                                    height: 1,
                                                  ),
                                                  ListTile(
                                                    onTap: () async {
                                                      try {
                                                        await controller
                                                            .galleryImage();
                                                        Get.back();
                                                      } catch (error) {
                                                        Get.back();
                                                      }
                                                    },
                                                    title: const CustomText(
                                                      text: 'Gallery',
                                                    ),
                                                    leading: const Icon(
                                                      Icons.account_box,
                                                      color: Colors.blue,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          );
                                        },
                                        child: const Text('Select Image'),
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 10.h,
                                  ),
                                  CustomTextFormField(
                                    title: 'Name',
                                    // hintText: 'name',
                                    hintText: Get.find<AuthController>()
                                        .currentUser!
                                        .name!,
                                    initialValue: Get.find<AuthController>()
                                        .currentUser!
                                        .name!,
                                    validatorFn: (value) {
                                      if (value!.isEmpty || value.length < 4) {
                                        return 'Please enter valid name.';
                                      }
                                      return null;
                                    },
                                    onSavedFn: (value) {
                                      Get.find<AuthController>().name = value;
                                    },
                                  ),
                                  SizedBox(
                                    height: 10.h,
                                  ),
                                  Column(
                                    children: [
                                      CustomTextFormField(
                                        title: 'Email',
                                        // hintText: 'email',
                                        hintText: Get.find<AuthController>()
                                            .currentUser!
                                            .email!,
                                        initialValue: Get.find<AuthController>()
                                            .currentUser!
                                            .email!,
                                        keyboardType:
                                            TextInputType.emailAddress,
                                        validatorFn: (value) {
                                          if (value!.isEmpty) {
                                            return 'Please enter valid email address.';
                                          }
                                          return null;
                                        },
                                        onSavedFn: (value) {
                                          // Get.find<AuthController>().email =
                                          //     value;
                                        },
                                      ),
                                      SizedBox(
                                        height: 10.h,
                                      ),
                                      CustomTextFormField(
                                        title: 'Password',
                                        hintText: 'Password',
                                        obscureText: true,
                                        validatorFn: (value) {
                                          if (value!.isEmpty ||
                                              value.length < 6) {
                                            return 'Please enter valid password with at least 6 characters.';
                                          }
                                          return null;
                                        },
                                        onSavedFn: (value) {
                                          Get.find<AuthController>().password =
                                              value;
                                        },
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 5.h,
                                  ),
                                  _isLoading
                                      ? const CircularProgressIndicator()
                                      : CustomButton(
                                          'SUBMIT',
                                          () async {
                                            if (_formKey.currentState!
                                                .validate()) {
                                              setState(() {
                                                _isLoading = true;
                                              });
                                              try {
                                                await controller
                                                    .uploadImageToFirebase();
                                                Get.find<AuthController>()
                                                    .picUrl = controller.picUrl;
                                              } catch (e) {
                                                Get.find<AuthController>()
                                                        .picUrl =
                                                    Get.find<AuthController>()
                                                        .currentUser!
                                                        .pic;
                                              }
                                              _formKey.currentState!.save();
                                              await Get.find<AuthController>()
                                                  .updateCurrentUser();
                                              setState(() {
                                                _isLoading = false;
                                              });
                                            }
                                          },
                                        ),
                                ],
                              ),
                            ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
