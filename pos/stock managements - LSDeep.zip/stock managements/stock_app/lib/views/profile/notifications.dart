import 'package:flutter/material.dart';

class NotificationsA extends StatelessWidget {
  const NotificationsA({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
      ),
    );
  }
}
