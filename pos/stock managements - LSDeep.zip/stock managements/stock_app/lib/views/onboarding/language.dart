// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:stock_app/controllers/localization_controller.dart';
// import 'package:stock_app/core/constants/app_colors.dart';
// import 'package:stock_app/routes.dart';

// class Language extends GetView<LocalController> {
//   const Language({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Text(
//               '1'.tr,
//               style: const TextStyle(fontSize: 20),
//             ),
//             const SizedBox(
//               height: 50,
//             ),
//             CustomLanguageButton(
//               textButton: 'ar',
//               onPressed: () {
//                 controller.changeLange('ar');
//                 Get.toNamed(Routes.OnBoarding);
//               },
//             ),
//             CustomLanguageButton(
//               textButton: 'en',
//               onPressed: () {
//                 controller.changeLange('en');
//                 Get.toNamed(Routes.OnBoarding);
//               },
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

// class CustomLanguageButton extends StatelessWidget {
//   final String textButton;
//   final Function()? onPressed;
//   const CustomLanguageButton({
//     Key? key,
//     required this.textButton,
//     required this.onPressed,
//   }) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: const EdgeInsets.symmetric(
//         horizontal: 100,
//       ),
//       width: double.infinity,
//       child: MaterialButton(
//         color: appColor,
//         onPressed: onPressed,
//         textColor: Colors.white,
//         child: Text(
//           textButton,
//           style: const TextStyle(
//             fontWeight: FontWeight.bold,
//           ),
//         ),
//       ),
//     );
//   }
// }
