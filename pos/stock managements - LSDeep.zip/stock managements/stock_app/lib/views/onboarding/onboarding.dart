import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stock_app/controllers/onboarding_controller.dart';
import 'package:stock_app/widgets/onboarding/custom_button.dart';
import 'package:stock_app/widgets/onboarding/custom_controller_dots.dart';
import 'package:stock_app/widgets/onboarding/custom_pageview.dart';

class OnBoarding extends StatelessWidget {
  const OnBoarding({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(OnBoardingControllerImp());
    return const Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              flex: 5,
              child: CustomPageViewOnBoardind(),
            ),
            SizedBox(
              height: 30,
            ),
            Expanded(
              // flex: 0,
              child: Column(
                children: [
                  CustomControllerDotsOnBoarding(),
                  SizedBox(
                    height: 30,
                  ),
                  CustomButtonOnBoarding()
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
