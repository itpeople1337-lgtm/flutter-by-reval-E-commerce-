// import 'package:flutter/material.dart';

// const primaryColor = Color.fromRGBO(0, 197, 105, 1);
// const primaryColor0 = Color.fromRGBO(11, 8, 79, 1);
// const primaryColor2 = Color.fromARGB(255, 91, 58, 224);
// const primaryColor3 = Color.fromARGB(255, 245, 190, 10);

// const Color baseColor = Color(0xFF161155);
// const Color base2Color = Color(0xFF46197E);
// const Color secondColor = Color(0xFF8043F7);




// ///
// ///
