// import 'dart:io';

// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stock_app/controllers/companyInfo_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/views/home/drawer/settings/list_settings.dart';
import 'package:stock_app/views/home/drawer/z_info/Your_companyInfo.dart';
import 'package:stock_app/views/home/drawer/z_info/how_to_use.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:url_launcher/url_launcher.dart' as UrlLauncher;

class MyDrawer extends StatelessWidget {
  MyDrawer({
    super.key,
  });
  // var controller = Get.put(CompanyInfoController());
  var controller = Get.find<CompanyInfoController>();
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: controller.getCompanyInfo(),
      builder: (context, snapshot) => Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            GetBuilder<CompanyInfoController>(
              builder: (controller) => UserAccountsDrawerHeader(
                accountName: Text(controller.data.companyName),
                accountEmail: Text(controller.data.companyEmail),
                currentAccountPicture: CircleAvatar(
                  backgroundColor: Colors.orange,
                  child: controller.data.companyName != null
                      ? Text(
                          controller.data.companyName[0].toUpperCase(),
                          style: const TextStyle(fontSize: 40.0),
                        )
                      : Text(
                          "212".tr,
                          style: const TextStyle(fontSize: 40.0),
                        ),
                ),
              ),
            ),
            ListTile(
              leading: const Icon(
                Icons.home,
                color: appColor,
              ),
              title: Text("213".tr),
              onTap: () {
                Get.back();
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.update,
                color: appColor,
              ),
              title: Text('214'.tr),
              onTap: () {
                Get.toNamed(Routes.Stores);
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.call,
                color: appColor,
              ),
              title: Text("215".tr),
              onTap: () {
                UrlLauncher.launch('tel:+');
              },
            ),
            ListTile(
              leading: Image.asset(
                'assets/images/icons/whats.png',
                width: 25,
              ),
              title: Text('216'.tr),
              onTap: () {
                _sendWhatsUp();
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.note_alt_sharp,
                color: appColor,
              ),
              title: Text('242'.tr),
              onTap: () {
                // Get.toNamed(Routes.Stocks);
                Get.toNamed(Routes.NOTES);
              },
            ),
            const Divider(
              color: Colors.black45,
            ),
            ListTile(
              leading: const Icon(
                Icons.settings,
                color: appColor,
              ),
              title: Text("218".tr),
              onTap: () {
                Get.to(
                  const ListSettings(),
                  transition: Transition.leftToRight,
                  duration: const Duration(milliseconds: 400),
                );
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.contacts,
                color: appColor,
              ),
              title: Text("192".tr),
              onTap: () {
                Get.to(
                  CompanyInfo(),
                  transition: Transition.leftToRight,
                  duration: const Duration(milliseconds: 400),
                );
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.account_tree_outlined,
                color: appColor,
              ),
              title: Text('219'.tr),
              onTap: () {
                Get.to(
                  const HowToUse(),
                  transition: Transition.leftToRight,
                  duration: const Duration(milliseconds: 400),
                );
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.notifications_outlined,
                color: appColor,
              ),
              title: Text('220'.tr),
              onTap: () {
                launch('mailto: say201025@gmail.com');
              },
            ),
          ],
        ),
      ),
    );
  }

  _sendWhatsUp() {
    final Uri url = Uri(
      scheme: 'https',
      host: 'wa.me',
      path: '+12356789',
    );
    // UrlLauncher.launch(url);
    launchUrl(url);
  }
}
