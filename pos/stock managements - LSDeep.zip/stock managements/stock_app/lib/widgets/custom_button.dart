import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';
import 'package:stock_app/core/constants/app_colors.dart';

import 'custom_text.dart';

class CustomButton extends StatelessWidget {
  // IconData icon;
  final String? text;
  final VoidCallback? onPressedFn;

  const CustomButton(
      //   this.icon,
      this.text,
      this.onPressedFn,
      {super.key});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: appColor,
        elevation: 10,
        padding: EdgeInsets.symmetric(vertical: 1.w, horizontal: 3.w),
      ),
      onPressed: onPressedFn,
      child: CustomText(
        text: text!,
        // fontSize: 5.sp,
        fontSize: 8.sp,
        color: Colors.white,
        alignment: Alignment.center,
      ),
    );
  }
}
