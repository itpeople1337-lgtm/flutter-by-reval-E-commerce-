import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:stock_app/controllers/onboarding_controller.dart';

class CustomPageViewOnBoardind extends GetView<OnBoardingControllerImp> {
  const CustomPageViewOnBoardind({super.key});

  @override
  Widget build(BuildContext context) {
    return PageView.builder(
      controller: controller.pageController,
      onPageChanged: (value) {
        controller.onPageChange(value);
      },
      itemCount: onBoardingList.length,
      itemBuilder: (context, i) => Column(
        // mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SvgPicture.asset(onBoardingList[i].image!,
              // width: 270,
              height: 400,

              // colorFilter: ColorFilter.mode(Colors.red, BlendMode.srcIn),
              semanticsLabel: 'A red up arrow'),
          const SizedBox(
            height: 50,
          ),
          Text(
            onBoardingList[i].title!,
            style: const TextStyle(
              fontSize: 25,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(
            height: 20,
          ),
          Text(
            onBoardingList[i].body0!,
            textAlign: TextAlign.center,
          ),
          const SizedBox(
            height: 10,
          ),
          // Text(onBoardingList[i].body1!),
        ],
      ),
    );
  }
}
