import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stock_app/controllers/onboarding_controller.dart';

class CustomButtonOnBoarding extends GetView<OnBoardingControllerImp> {
  const CustomButtonOnBoarding({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<OnBoardingControllerImp>(
      builder: (controller) => Container(
        alignment: Alignment.bottomCenter,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            controller.currentPage == 0
                ? const Text('')
                : MaterialButton(
                    onPressed: () {
                      controller.skip();
                    },
                    child: Text('14'.tr),
                  ),
            MaterialButton(
              onPressed: () {
                controller.next();
              },
              child: Text(controller.currentPage == 5 ? '15'.tr : '13'.tr),
            )
          ],
        ),
      ),
    );
  }
}
