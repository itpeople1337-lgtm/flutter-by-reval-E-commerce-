import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stock_app/controllers/onboarding_controller.dart';
import 'package:stock_app/core/constants/app_colors.dart';

class CustomControllerDotsOnBoarding extends StatelessWidget {
  const CustomControllerDotsOnBoarding({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<OnBoardingControllerImp>(
      builder: (controller) => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ...List.generate(
            onBoardingList.length,
            (index) => AnimatedContainer(
              duration: const Duration(
                milliseconds: 500,
              ),
              width: controller.currentPage == index ? 20 : 10,
              height: 10,
              margin: const EdgeInsets.symmetric(
                horizontal: 10,
              ),
              decoration: BoxDecoration(
                color: appColor,
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
