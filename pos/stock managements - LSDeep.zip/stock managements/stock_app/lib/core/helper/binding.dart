import 'package:get/get.dart';
import 'package:stock_app/controllers/auth_controller.dart';
import 'package:stock_app/controllers/category_controller.dart';
import 'package:stock_app/controllers/companyInfo_controller.dart';
import 'package:stock_app/controllers/customer_controller.dart';
import 'package:stock_app/controllers/debts_controller.dart';
import 'package:stock_app/controllers/expense_controller.dart';
import 'package:stock_app/controllers/incoming_controller.dart';
import 'package:stock_app/controllers/network_controller.dart';
import 'package:stock_app/controllers/outgoing_controller.dart';
import 'package:stock_app/controllers/product_controller.dart';
import 'package:stock_app/controllers/report_controller.dart';
import 'package:stock_app/controllers/store_controller.dart';
import 'package:stock_app/controllers/supplier_controller.dart';

class Binding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AuthController>(() => AuthController());
    Get.lazyPut<CompanyInfoController>(() => CompanyInfoController());
    Get.put(ProductController());
    //  Get.put(DocumentController());
    Get.put(CategoryController());
    Get.put(CustomerController());
    Get.put(SupplierController());
    Get.put(StoreController());

    // Get.put(StockController());
    Get.put(OutgoingController());
    Get.put(IncomingController());
    Get.put(DebtsController());
    // Get.lazyPut(() => MyServices());
    Get.lazyPut(() => CompanyInfoController());
    Get.lazyPut(() => ExpenseController());
    Get.lazyPut(() => ReportsController());
    Get.lazyPut(() => NetworkController());
  }
}
