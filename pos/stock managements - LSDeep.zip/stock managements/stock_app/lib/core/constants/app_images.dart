class ImagesAssets {
  static const String rootIcons = 'assets/images/icons';
  static const String rootImages = 'assets/images';
  static const String rootSvg = 'assets/svg';
  static const String rootLottie = 'assets/lottie';

  // onboarding
  static const String onBoardingImage0 = '$rootSvg/0.svg';
  static const String onBoardingImage1 = '$rootSvg/1.svg';
  static const String onBoardingImage2 = '$rootSvg/2.svg';
  static const String onBoardingImage3 = '$rootSvg/3.svg';
  static const String onBoardingImage4 = '$rootSvg/4.svg';
  static const String onBoardingImage5 = '$rootSvg/5.svg';

  static const String loading = '$rootLottie/loading/0.json';
  static const String loading1 = '$rootLottie/loading/1.json';
  static const String offline = '$rootLottie/offline/1.json';
  static const String nodata = '$rootLottie/nodata/1.json';
  static const String server = '$rootLottie/server/1.json';

  /////////////////////////////////
  static const String addProduct = '$rootIcons/addd.png';
  static const String empty = '$rootIcons/empty.jpg';
  static const String bestCustomer = '$rootImages/userco.jpg';
  static const String bestProduct = '$rootIcons/product1.png';
  static const String product = '$rootIcons/product.png';
  static const String qr = '$rootIcons/qr.png';
  static const String incoming = '$rootIcons/incoming.png';
  static const String outgoing = '$rootIcons/outgoing.png';
  static const String expense = '$rootIcons/expense.png';
  static const String expense2 = '$rootIcons/expen.png';
  static const String inout = '$rootIcons/inout.png';
  static const String profile = '$rootImages/profile_pic.png';
  static const String logo = '$rootImages/school-logo.png';

  static const String card = '$rootImages/card_bg.png';
  static const String mastercard = '$rootImages/mastercard.png';
  static const String google = '$rootIcons/google.png';
  static const String facebook = '$rootIcons/facebook.png';
}
