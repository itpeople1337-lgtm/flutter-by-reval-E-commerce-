import 'package:flutter/material.dart';
import 'package:stock_app/core/constants/app_colors.dart';

ThemeData themeEnglish = ThemeData(
  fontFamily: 'Tahoma',
  textTheme: const TextTheme(
    displayLarge: TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 22,
      color: appColor,
    ),
    displayMedium: TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 26,
      color: appColor,
    ),
    bodyLarge: TextStyle(
      fontWeight: FontWeight.bold,
      // height: 2,
      fontSize: 14,
      color: appColor,
    ),
    bodyMedium: TextStyle(
      // height: 2,
      fontSize: 14,
      color: appColor,
    ),
  ),
  // colorScheme: ColorScheme.fromSwatch().copyWith(secondary: appColor),
  // primarySwatch: Colors.green,
  useMaterial3: true,
);

ThemeData themeArabic = ThemeData(
  fontFamily: 'Cairo',
  textTheme: const TextTheme(
    displayLarge: TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 22,
      color: appColor,
    ),
    displayMedium: TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 26,
      color: appColor,
    ),
    bodyLarge: TextStyle(
      fontWeight: FontWeight.bold,
      // height: 2,
      fontSize: 14,
      color: appColor,
    ),
    bodyMedium: TextStyle(
      // height: 2,
      fontSize: 14,
      color: appColor,
    ),
  ),
  useMaterial3: true,
  //primarySwatch: Colors.blue,
);

class AppColors {
  AppColors._();

  static const Color cardBgColor = Color(0xff363636);
  static const Color cardBgLightColor = Color(0xff999999);
  static const Color colorB58D67 = Color(0xffB58D67);
  static const Color colorE5D1B2 = Color(0xffE5D1B2);
  static const Color colorF9EED2 = Color(0xffF9EED2);
  static const Color colorEFEFED = Color(0xffEFEFED);
}
