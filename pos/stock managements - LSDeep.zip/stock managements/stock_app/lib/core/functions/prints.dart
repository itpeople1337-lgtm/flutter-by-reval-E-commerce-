// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:stock_app/controllers/companyInfo_controller.dart';
import 'package:stock_app/models/customer_model.dart';
import 'package:stock_app/models/debts_model.dart';
import 'package:stock_app/models/expense_model.dart';
import 'package:stock_app/models/in_out_model.dart';
import 'package:stock_app/models/product_model.dart';
import 'package:stock_app/models/supplier_model.dart';

var dateTime = DateTime.now();
var selectedDateTime = DateFormat('dd-MMM-yyyy - HH:mm').format(dateTime);
var controller = Get.find<CompanyInfoController>();
var companyLogo = controller.data.image;
var companyName = controller.data.companyName;

printListProducts(List<ProductModel> lproducts) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final h = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our school logo for the official PDF
    ),

    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'List Products',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);
  final tb = pw.Column(children: [
    pw.Table(
      children: [
        pw.TableRow(
          decoration: pw.BoxDecoration(shape: pw.BoxShape.rectangle),
          children: [
            'Name',
            'Quantity',
            'Sell price',
            'Pur price',
            'Date',
            'Category',
            'Store',
            'Color',
            // 'Barcode',
            // 'Description',
            'Photo',
          ]
              .map(
                (title) => pw.Container(
                  margin: pw.EdgeInsets.only(bottom: 30),
                  child: pw.Text(
                    title,
                    style: pw.TextStyle(
                      fontSize: 15,
                      fontWeight: pw.FontWeight.bold,
                    ),
                  ),
                ),
              )
              .toList(),
        ),
        for (var product in lproducts) ...[
          pw.TableRow(
            verticalAlignment: pw.TableCellVerticalAlignment.top,
            decoration: pw.BoxDecoration(),
            children: [
              rrr(product.name),
              rrr(product.quantity.toString()),
              rrr(product.sellingprice.toString()),
              rrr(product.purchaseprice.toString()),
              rrr(product.date.toString()),
              rrr(product.category),
              rrr(product.storeName),
              pw.Container(
                alignment: pw.Alignment.topCenter,
                margin: pw.EdgeInsets.symmetric(
                  vertical: 17,
                  horizontal: 12,
                ),
                color: getcolorToName(product.color),
              ),
              // rrr(product.barcode),
              // rrr(product.details),
              await getImage(product.image)
            ]
                .map((cell) => cell is pw.Widget
                    ? cell
                    : pw.Container(
                        alignment: pw.Alignment.bottomCenter,
                        height: 50,
                        child: cell,
                      ))
                .toList(),
          ),
        ]
      ],
    ),
    pw.SizedBox(height: 10.00),
  ]);

  widgets.add(h);
  widgets.add(tb);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );

  Printing.layoutPdf(
    onLayout: (PdfPageFormat format) async => pdfDoc.save(),
    name: 'List Products',
  );
}

printListExpenses(List<ExpenseModel> listExpenses) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final h = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our school logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'List Expenses',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final tb = pw.Column(children: [
    pw.Table(
      children: [
        pw.TableRow(
          decoration: pw.BoxDecoration(shape: pw.BoxShape.rectangle),
          children: [
            'Amount',
            'Expense Type',
            'Name',
            'Date and Time',
            'Store',
          ]
              .map(
                (title) => pw.Container(
                  margin: pw.EdgeInsets.only(bottom: 30),
                  child: pw.Text(
                    title,
                    style: pw.TextStyle(
                      fontSize: 15,
                      fontWeight: pw.FontWeight.bold,
                    ),
                  ),
                ),
              )
              .toList(),
        ),
        for (var product in listExpenses) ...[
          pw.TableRow(
            verticalAlignment: pw.TableCellVerticalAlignment.top,
            decoration: pw.BoxDecoration(),
            children: [
              rrr(product.amount),
              rrr(product.category.toString()),
              rrr(product.name.toString()),
              rrr(product.date.toString()),
              rrr(product.date.toString()),
              rrr(product.store),
            ]
                .map((cell) => cell is pw.Text
                    ? cell
                    : pw.Container(
                        alignment: pw.Alignment.bottomCenter,
                        height: 50,
                        child: cell,
                      ))
                .toList(),
          ),
        ]
      ],
    ),
    pw.SizedBox(height: 10.00),
  ]);

  widgets.add(h);
  widgets.add(tb);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdfDoc.save(),
      name: 'List Expenses');
}

printListIncoming(List<InOutModel> listIncomingProducts) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final h = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our school logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'List Incoming',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final tb = pw.Column(children: [
    pw.Table(
      children: [
        pw.TableRow(
          decoration: pw.BoxDecoration(shape: pw.BoxShape.rectangle),
          children: [
            'Document No',
            'Quantity',
            'Client Name',
            'Date and Time',
            'Description',
          ]
              .map(
                (title) => pw.Container(
                  margin: pw.EdgeInsets.only(bottom: 30),
                  child: pw.Text(
                    title,
                    style: pw.TextStyle(
                      fontSize: 15,
                      fontWeight: pw.FontWeight.bold,
                    ),
                  ),
                ),
              )
              .toList(),
        ),
        for (var product in listIncomingProducts) ...[
          pw.TableRow(
            verticalAlignment: pw.TableCellVerticalAlignment.top,
            decoration: pw.BoxDecoration(),
            children: [
              rrr(product.docNo),
              rrr(product.quantity.toString()),
              rrr(product.clientName.toString()),
              rrr(product.date.toString()),
              rrr(product.details),
            ]
                .map((cell) => cell is pw.Text
                    ? cell
                    : pw.Container(
                        alignment: pw.Alignment.bottomCenter,
                        height: 50,
                        child: cell,
                      ))
                .toList(),
          ),
        ]
      ],
    ),
    pw.SizedBox(height: 10.00),
  ]);

  widgets.add(h);
  widgets.add(tb);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
    onLayout: (PdfPageFormat format) async => pdfDoc.save(),
    name: 'List Expenses',
  );
}

printListOutgoing(List<InOutModel> listOutgoingProducts) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final h = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our school logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'List Outgoing: }',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final tb = pw.Column(children: [
    pw.Table(
      children: [
        pw.TableRow(
          decoration: pw.BoxDecoration(shape: pw.BoxShape.rectangle),
          children: [
            'Document No',
            'Quantity',
            'Client Name',
            'Date and Time',
            'Description',
          ]
              .map(
                (title) => pw.Container(
                  margin: pw.EdgeInsets.only(bottom: 30),
                  child: pw.Text(
                    title,
                    style: pw.TextStyle(
                      fontSize: 15,
                      fontWeight: pw.FontWeight.bold,
                    ),
                  ),
                ),
              )
              .toList(),
        ),
        for (var product in listOutgoingProducts) ...[
          pw.TableRow(
            verticalAlignment: pw.TableCellVerticalAlignment.top,
            decoration: pw.BoxDecoration(),
            children: [
              rrr(product.docNo),
              rrr(product.quantity.toString()),
              rrr(product.clientName.toString()),
              rrr(product.date.toString()),
              rrr(product.details),
            ]
                .map(
                  (cell) => cell is pw.Text
                      ? pw.Column(children: [
                          cell,
                          pw.SizedBox(height: 10.00),
                        ])
                      : pw.Container(
                          alignment: pw.Alignment.bottomCenter,
                          height: 50,
                          child: cell,
                        ),
                )
                .toList(),
          ),
        ]
      ],
    ),
    pw.SizedBox(height: 10.00),
  ]);

  widgets.add(h);
  widgets.add(tb);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
    onLayout: (PdfPageFormat format) async => pdfDoc.save(),
    name: 'List Outgoing',
  );
}

printListCustomers(List<CustomerModel> listCustomers) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final h = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our school logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'List Customers',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final tb = pw.Column(children: [
    pw.Table(
      children: [
        pw.TableRow(
          decoration: pw.BoxDecoration(shape: pw.BoxShape.rectangle),
          children: [
            'Name',
            'Address',
            'Email',
            'Phone',
            'Text ID',
            'Discount',
            'Bank Details',
            'Notes',
          ]
              .map(
                (title) => pw.Container(
                  margin: pw.EdgeInsets.only(bottom: 30),
                  child: pw.Text(
                    title,
                    style: pw.TextStyle(
                      fontSize: 15,
                      fontWeight: pw.FontWeight.bold,
                    ),
                  ),
                ),
              )
              .toList(),
        ),
        for (var product in listCustomers) ...[
          pw.TableRow(
            verticalAlignment: pw.TableCellVerticalAlignment.top,
            decoration: pw.BoxDecoration(),
            children: [
              rrr(product.name),
              rrr(product.address.toString()),
              rrr(product.email.toString()),
              rrr(product.phone.toString()),
              rrr(product.textId),
              rrr(product.discount),
              rrr(product.bankDetails),
              rrr(product.notes),
              // pw.Image(netImage, width: 50, height: 50),
            ]
                .map(
                  (cell) => cell is pw.Text
                      ? pw.Column(children: [
                          cell,
                          pw.SizedBox(height: 10.00),
                        ])
                      : pw.Container(
                          alignment: pw.Alignment.bottomCenter,
                          height: 50,
                          child: cell,
                        ),
                )
                .toList(),
          ),
        ]
      ],
    ),
    pw.SizedBox(height: 10.00),
  ]);

  widgets.add(h);
  widgets.add(tb);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
    onLayout: (PdfPageFormat format) async => pdfDoc.save(),
    name: 'List Customers',
  );
}

printListSuppliers(List<SupplierModel> listSuppliers) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final h = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our school logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'List Suppliers',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final tb = pw.Column(children: [
    pw.Table(
      children: [
        pw.TableRow(
          decoration: pw.BoxDecoration(shape: pw.BoxShape.rectangle),
          children: [
            'Name',
            'Address',
            'Email',
            'Phone',
            'Text ID',
            'Bank Details',
            'Notes',
          ]
              .map(
                (title) => pw.Container(
                  margin: pw.EdgeInsets.only(bottom: 30),
                  child: pw.Text(
                    title,
                    style: pw.TextStyle(
                      fontSize: 15,
                      fontWeight: pw.FontWeight.bold,
                    ),
                  ),
                ),
              )
              .toList(),
        ),
        for (var product in listSuppliers) ...[
          pw.TableRow(
            verticalAlignment: pw.TableCellVerticalAlignment.top,
            decoration: pw.BoxDecoration(),
            children: [
              rrr(product.name),
              rrr(product.address.toString()),
              rrr(product.email.toString()),
              rrr(product.phone.toString()),
              rrr(product.textId),
              rrr(product.bankDetails),
              rrr(product.notes),
            ]
                .map(
                  (cell) => cell is pw.Text
                      ? pw.Column(children: [
                          cell,
                          pw.SizedBox(height: 10.00),
                        ]) // cell])

                      : pw.Container(
                          // margin: pw.EdgeInsets.symmetric(vertical: 20),
                          alignment: pw.Alignment.bottomCenter,
                          height: 50,
                          child: cell,
                        ),
                )
                .toList(),
          ),
        ]
      ],
    ),
    pw.SizedBox(height: 10.00),
  ]);

  widgets.add(h);
  widgets.add(tb);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
    onLayout: (PdfPageFormat format) async => pdfDoc.save(),
    name: 'List Suppliers',
  );
}

printDebtsSuppliers(List<DebtsModel> listSuppliers) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final h = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our school logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      //'Jackie & Co. Company Name',
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Debts Suppliers',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final tb = pw.Column(children: [
    pw.Table(
      children: [
        pw.TableRow(
          decoration: pw.BoxDecoration(shape: pw.BoxShape.rectangle),
          children: [
            'Name',
            'Total D',
            'Received',
            'remaining',
            'date',
            'Notes',
          ]
              .map(
                (title) => pw.Container(
                  margin: pw.EdgeInsets.only(bottom: 30),
                  child: pw.Text(
                    title,
                    style: pw.TextStyle(
                      fontSize: 15,
                      fontWeight: pw.FontWeight.bold,
                    ),
                  ),
                ),
              )
              .toList(),
        ),
        for (var product in listSuppliers) ...[
          pw.TableRow(
            verticalAlignment: pw.TableCellVerticalAlignment.top,
            decoration: pw.BoxDecoration(),
            children: [
              rrr(product.clientName),
              rrr(product.totalDebt.toString()),
              rrr(product.amountReceived.toString()),
              rrr(product.remainingDebt.toString()),
              rrr(product.date),
              rrr(product.notes),
            ]
                .map(
                  (cell) => cell is pw.Text
                      ? pw.Column(children: [
                          cell,
                          pw.SizedBox(height: 10.00),
                        ])
                      : pw.Container(
                          alignment: pw.Alignment.bottomCenter,
                          height: 50,
                          child: cell,
                        ),
                )
                .toList(),
          ),
        ]
      ],
    ),
    pw.SizedBox(height: 10.00),
  ]);

  widgets.add(h);
  widgets.add(tb);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
    onLayout: (PdfPageFormat format) async => pdfDoc.save(),
    name: 'Debts Suppliers',
  );
}

printDebtsCustomers(List<DebtsModel> listSuppliers) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final h = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our school logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      //'Jackie & Co. Company Name',
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Debts Customers',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final tb = pw.Column(children: [
    pw.Table(
      children: [
        pw.TableRow(
          decoration: pw.BoxDecoration(shape: pw.BoxShape.rectangle),
          children: [
            'Name',
            'Total D',
            'Received',
            'remaining',
            'date',
            'Notes',
          ]
              .map(
                (title) => pw.Container(
                  margin: pw.EdgeInsets.only(bottom: 30),
                  child: pw.Text(
                    title,
                    style: pw.TextStyle(
                      fontSize: 15,
                      fontWeight: pw.FontWeight.bold,
                    ),
                  ),
                ),
              )
              .toList(),
        ),
        for (var product in listSuppliers) ...[
          pw.TableRow(
            verticalAlignment: pw.TableCellVerticalAlignment.top,
            decoration: pw.BoxDecoration(),
            children: [
              rrr(product.clientName),
              rrr(product.totalDebt.toString()),
              rrr(product.amountReceived.toString()),
              rrr(product.remainingDebt.toString()),
              rrr(product.date),
              rrr(product.notes),
            ]
                .map(
                  (cell) => cell is pw.Text
                      ? pw.Column(children: [
                          cell,
                          pw.SizedBox(height: 10.00),
                        ])
                      : pw.Container(
                          alignment: pw.Alignment.bottomCenter,
                          height: 50,
                          child: cell,
                        ),
                )
                .toList(),
          ),
        ]
      ],
    ),
    pw.SizedBox(height: 10.00),
  ]);

  widgets.add(h);
  widgets.add(tb);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
    onLayout: (PdfPageFormat format) async => pdfDoc.save(),
    name: 'Debts Customers',
  );
}

////////////////////////////// Details /////////////////////////////////////////
printProductDetails(ProductModel? productDetails) async {
  List<pw.Widget> widgets = [];

  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);
  // ProductModel? productDetails;
  final h = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our school logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Product Details',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final tb = pw.Table(children: [
    pw.TableRow(
      decoration: pw.BoxDecoration(shape: pw.BoxShape.rectangle),
      children: [
        'Name',
        'Quantity',
        'Sell price',
        'Pur price',
        'Date',
        'Category',
        'Store',
        'Color',
        // 'Barcode',
        // 'Description',
        'Photo',
      ]
          .map(
            (title) => pw.Container(
              margin: pw.EdgeInsets.only(bottom: 30),
              child: pw.Text(
                title,
                style: pw.TextStyle(
                  fontSize: 15,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
            ),
          )
          .toList(),
    ),
    //for (var product in listp) ...[
    pw.TableRow(
      verticalAlignment: pw.TableCellVerticalAlignment.top,
      decoration: pw.BoxDecoration(),
      children: [
        rrr(productDetails!.name),
        rrr(productDetails.quantity.toString()),
        rrr(productDetails.sellingprice.toString()),
        rrr(productDetails.purchaseprice.toString()),
        rrr(productDetails.date.toString()),
        rrr(productDetails.category),
        rrr(productDetails.storeName),
        pw.Container(
          alignment: pw.Alignment.topCenter,
          margin: pw.EdgeInsets.symmetric(
            vertical: 17,
            horizontal: 12,
          ),
          color: getcolorToName(productDetails.color),
        ),
        // rrr(productDetails.barcode),
        // rrr(productDetails.details),
        // pw.Image(netImage, width: 50, height: 50),
        await getImage(productDetails.image),
      ]
          .map((cell) => cell is pw.Text
              ? cell
              : pw.Container(
                  alignment: pw.Alignment.bottomCenter,
                  height: 50,
                  child: cell,
                ))
          .toList(),
    ),
  ]
      //  ],
      );

  widgets.add(h);
  widgets.add(tb);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );

  Printing.layoutPdf(
    onLayout: (PdfPageFormat format) async => pdfDoc.save(),
    name: 'Products Details',
  );
}

printExpenseDetails(ExpenseModel? expenseDetails) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final h = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our school logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Expense Details',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final tb = pw.Table(children: [
    pw.TableRow(
      decoration: pw.BoxDecoration(shape: pw.BoxShape.rectangle),
      children: [
        'Amount',
        'Expense Type',
        'Name',
        'Date and Time',
        'Store',
      ]
          .map(
            (title) => pw.Container(
              margin: pw.EdgeInsets.only(bottom: 30),
              child: pw.Text(
                title,
                style: pw.TextStyle(
                  fontSize: 15,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
            ),
          )
          .toList(),
    ),
    // for (var product in listExp) ...[
    pw.TableRow(
      verticalAlignment: pw.TableCellVerticalAlignment.top,
      decoration: pw.BoxDecoration(),
      children: [
        rrr(expenseDetails!.amount),
        rrr(expenseDetails.category.toString()),
        rrr(expenseDetails.name.toString()),
        rrr(expenseDetails.date.toString()),
        rrr(expenseDetails.store),
      ]
          .map((cell) => cell is pw.Text
              ? cell
              : pw.Container(
                  alignment: pw.Alignment.bottomCenter,
                  height: 50,
                  child: cell,
                ))
          .toList(),
    ),
  ]
      // ],
      );

  widgets.add(h);
  widgets.add(tb);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdfDoc.save(),
      name: 'Expense Details');
}

printIncomingDetails(InOutModel? incomingDetails) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final h = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our school logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Incoming Details',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final tb = pw.Table(children: [
    pw.TableRow(
      decoration: pw.BoxDecoration(shape: pw.BoxShape.rectangle),
      children: [
        'Document No',
        'Quantity',
        'Client Name',
        'Date and Time',
        'Description',
      ]
          .map(
            (title) => pw.Container(
              margin: pw.EdgeInsets.only(bottom: 30),
              child: pw.Text(
                title,
                style: pw.TextStyle(
                  fontSize: 15,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
            ),
          )
          .toList(),
    ),
    // for (var product in listIn) ...[
    pw.TableRow(
      verticalAlignment: pw.TableCellVerticalAlignment.top,
      decoration: pw.BoxDecoration(),
      children: [
        rrr(incomingDetails!.docNo),
        rrr(incomingDetails.quantity.toString()),
        rrr(incomingDetails.clientName.toString()),
        rrr(incomingDetails.date.toString()),
        rrr(incomingDetails.details),
      ]
          .map((cell) => cell is pw.Text
              ? cell
              : pw.Container(
                  alignment: pw.Alignment.bottomCenter,
                  height: 50,
                  child: cell,
                ))
          .toList(),
    ),
  ]
      //],
      );

  widgets.add(h);
  widgets.add(tb);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
    onLayout: (PdfPageFormat format) async => pdfDoc.save(),
    name: 'Expense Details',
  );
}

printOutgoingDetails(InOutModel? outgoingDetails) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final h = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our school logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Outgoing Details',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final tb = pw.Table(children: [
    pw.TableRow(
      decoration: pw.BoxDecoration(shape: pw.BoxShape.rectangle),
      children: [
        'Document No',
        'Quantity',
        'Client Name',
        'Date and Time',
        'Description',
      ]
          .map(
            (title) => pw.Container(
              margin: pw.EdgeInsets.only(bottom: 30),
              child: pw.Text(
                title,
                style: pw.TextStyle(
                  fontSize: 15,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
            ),
          )
          .toList(),
    ),
    // for (var product in listout) ...[
    pw.TableRow(
      verticalAlignment: pw.TableCellVerticalAlignment.top,
      decoration: pw.BoxDecoration(),
      children: [
        rrr(outgoingDetails!.docNo),
        rrr(outgoingDetails.quantity.toString()),
        rrr(outgoingDetails.clientName.toString()),
        rrr(outgoingDetails.date.toString()),
        rrr(outgoingDetails.details),
      ]
          .map((cell) => cell is pw.Text
              ? cell
              : pw.Container(
                  alignment: pw.Alignment.bottomCenter,
                  height: 50,
                  child: cell,
                ))
          .toList(),
    ),
  ]
      // ],
      );

  widgets.add(h);
  widgets.add(tb);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
    onLayout: (PdfPageFormat format) async => pdfDoc.save(),
    name: 'Outgoing Details',
  );
}

printCustomerDetails(CustomerModel? customerDetails) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final h = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our school logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Customer Details',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final tb = pw.Table(children: [
    pw.TableRow(
      decoration: pw.BoxDecoration(shape: pw.BoxShape.rectangle),
      children: [
        'Name',
        'Address',
        'Email',
        'Phone',
        'Text ID',
        'Discount',
        'Bank Details',
        'Notes',
      ]
          .map(
            (title) => pw.Container(
              margin: pw.EdgeInsets.only(bottom: 30),
              child: pw.Text(
                title,
                style: pw.TextStyle(
                  fontSize: 15,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
            ),
          )
          .toList(),
    ),
    // for (var product in listCust) ...[
    pw.TableRow(
      verticalAlignment: pw.TableCellVerticalAlignment.top,
      decoration: pw.BoxDecoration(),
      children: [
        rrr(customerDetails!.name),
        rrr(customerDetails.address.toString()),
        rrr(customerDetails.email.toString()),
        rrr(customerDetails.phone.toString()),
        rrr(customerDetails.textId),
        rrr(customerDetails.discount),
        rrr(customerDetails.bankDetails),
        rrr(customerDetails.notes),
      ]
          .map((cell) => cell is pw.Text
              ? cell
              : pw.Container(
                  alignment: pw.Alignment.bottomCenter,
                  height: 50,
                  child: cell,
                ))
          .toList(),
    ),
  ]
      // ],
      );

  widgets.add(h);
  widgets.add(tb);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
    onLayout: (PdfPageFormat format) async => pdfDoc.save(),
    name: 'Customer Details',
  );
}

printSupplierDetails(SupplierModel? supplierDetails) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final h = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our school logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Supplier Details',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final tb = pw.Table(children: [
    pw.TableRow(
      decoration: pw.BoxDecoration(shape: pw.BoxShape.rectangle),
      children: [
        'Name',
        'Address',
        'Email',
        'Phone',
        'Text ID',
        'Bank Details',
        'Notes',
      ]
          .map(
            (title) => pw.Container(
              margin: pw.EdgeInsets.only(bottom: 30),
              child: pw.Text(
                title,
                style: pw.TextStyle(
                  fontSize: 15,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
            ),
          )
          .toList(),
    ),
    // for (var product in listSupp) ...[
    pw.TableRow(
      verticalAlignment: pw.TableCellVerticalAlignment.top,
      decoration: pw.BoxDecoration(),
      children: [
        rrr(supplierDetails!.name),
        rrr(supplierDetails.address.toString()),
        rrr(supplierDetails.email.toString()),
        rrr(supplierDetails.phone.toString()),
        rrr(supplierDetails.textId),
        rrr(supplierDetails.bankDetails),
        rrr(supplierDetails.notes),
      ]
          .map((cell) => cell is pw.Text
              ? cell
              : pw.Container(
                  alignment: pw.Alignment.bottomCenter,
                  height: 50,
                  child: cell,
                ))
          .toList(),
    ),
  ]
      //  ],
      );

  widgets.add(h);
  widgets.add(tb);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
    onLayout: (PdfPageFormat format) async => pdfDoc.save(),
    name: 'Suppliers Details',
  );
}

PdfColor getcolorToName(String color) {
  String valueString = color.split('(0x')[1].split(')')[0]; // Extract hex value
  int value = int.parse(valueString, radix: 16);
  // PdfColor resultColor = PdfColor(value);
  // return resultColor;
  double red = ((value >> 16) & 0xFF) / 255.0;
  double green = ((value >> 8) & 0xFF) / 255.0;
  double blue = (value & 0xFF) / 255.0;

  PdfColor resultColor = PdfColor(red, green, blue);
  return resultColor;
}

pw.Text rrr(String text) {
  return pw.Text(
    text,
    style: const pw.TextStyle(fontSize: 13),
    maxLines: 2, // Set the maximum number of lines
    softWrap: true,
    overflow: pw.TextOverflow.span,
  );
}

Future<pw.Widget> getImage(String companyLogo) async {
  final netImage = await networkImage(
    companyLogo,
  );
  return pw.Image(netImage, width: 50, height: 50);
}
