import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:stock_app/controllers/report_controller.dart';
import 'package:stock_app/models/expense_model.dart';
import 'package:stock_app/models/in_out_model.dart';
import 'package:stock_app/models/report_model.dart';

var controller = Get.put(ReportsController());
addReportExpense(ExpenseModel expenseModel) {
  controller.addExpense(
      'Expenses',
      ExpensesReportModel(
        id: 'expenseId1',
        expenseType: expenseModel.category,
        amount: double.parse(expenseModel.amount),
        date: DateTime.now(),
      ));
}

////////////////////////////////////////
addTransactionReport(
    {required double amount,
    required String type,
    required String productName,
    required String description}) {
  controller.addTransactionsToFireStore(
      'Transactions',
      TransactionsModel(
        id: '',
        amount: amount ?? 0,
        type: type ?? '',
        productName: productName ?? '',
        description: description ?? '',
        date: DateTime.now(),
      ));
}

addDebtsCustomerReport(
    {required String customerName, required double totalDebts}) {
  controller.addDebtsCustomerToFireStore(
      'DebtsCustomer',
      DebtsCustomerModel(
        id: '',
        customerID: 'customerID',
        customerName: customerName,
        totalDebts: totalDebts,
      ));
}

addDebtsSupplierReport(
    {required String supplierName, required double totalDebts}) {
  controller.addDebtsSupplierToFireStore(
      'DebtsSupplier',
      DebtsSupplierModel(
        id: 'DebtsSupplier1',
        supplierID: 'SupplierID',
        supplierName: supplierName,
        totalDebts: totalDebts,
      ));
}

/////////////////////////////////////////////////////
final FirebaseFirestore _firestore = FirebaseFirestore.instance;
//int? year, month;
int year = 2023;
int month = 11;
String startOfMonth = '$year-${month.toString().padLeft(2, '0')}-01 - 00:00';
String endOfMonth =
    '$year-${(month + 1).toString().padLeft(2, '0')}-01 - 00:00';

DateTime startDate = DateFormat('dd-MM-yyyy - HH:mm').parse(startOfMonth);
DateTime endDate = DateFormat('dd-MM-yyyy - HH:mm').parse(endOfMonth);

Future<List<InOutModel>> getOutgoingProductsFromFirestore() async {
  var snapshot = await _firestore
      .collection('in_out_products')
      .where('docType', isEqualTo: 'Incoming')
      .where('date', isGreaterThanOrEqualTo: startDate)
      .where('date', isLessThan: endDate)
      .get();

  return snapshot.docs.map((doc) => InOutModel.fromJson(doc)).toList();
}
