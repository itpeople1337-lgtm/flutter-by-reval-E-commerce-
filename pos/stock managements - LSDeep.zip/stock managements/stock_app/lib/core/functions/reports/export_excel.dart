import 'dart:io';

import 'package:get/get.dart';

import 'package:stock_app/models/report_model.dart';
import 'package:syncfusion_flutter_xlsio/xlsio.dart' as excel;

Future<void> generateAndSaveExcelExpensesReport(
    List<ExpensesReportModel> listExpenses) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Expenses_Report'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('Expenses Report');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Date');
  sheet.getRangeByIndex(4, 2).setText('Expense Type');
  sheet.getRangeByIndex(4, 3).setText('Amount');

  // loop through the results to set the data in the excel sheet cells
  for (var i = 0; i < listExpenses.length; i++) {
    sheet.getRangeByIndex(i + 5, 1).setText(listExpenses[i].date.toString());
    sheet.getRangeByIndex(i + 5, 2).setText(listExpenses[i].expenseType);
    sheet.getRangeByIndex(i + 5, 3).setText(listExpenses[i].amount.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);
  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelprofitsAndLossesReport(
    List<ProfitLoss> profits) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Profits&Losses_Report'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('Profits&Losses Report');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Date');
  sheet.getRangeByIndex(4, 2).setText('Total purchases');
  sheet.getRangeByIndex(4, 3).setText('Total sales');
  sheet.getRangeByIndex(4, 4).setText('Expense');
  sheet.getRangeByIndex(4, 5).setText('profit/Loss');

  // loop through the results to set the data in the excel sheet cells
  for (var i = 0; i < profits.length; i++) {
    sheet.getRangeByIndex(i + 5, 1).setText(profits[i].month.toString());
    sheet
        .getRangeByIndex(i + 5, 2)
        .setText(profits[i].totalPurchases.toString());
    sheet.getRangeByIndex(i + 5, 3).setText(profits[i].totalSales.toString());
    sheet
        .getRangeByIndex(i + 5, 4)
        .setText(profits[i].totalExpenses.toString());
    sheet.getRangeByIndex(i + 5, 5).setText(profits[i].profit.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelTransactionsReport(
    List<TransactionsModel> trans) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Transactions_Report'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('Transactions Report');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch

  sheet.getRangeByIndex(4, 1).setText('Date');
  sheet.getRangeByIndex(4, 2).setText('Type');
  sheet.getRangeByIndex(4, 3).setText('Amount');
  sheet.getRangeByIndex(4, 4).setText('Description');

  // loop through the results to set the data in the excel sheet cells
  for (var i = 0; i < trans.length; i++) {
    sheet.getRangeByIndex(i + 5, 1).setText(trans[i].date.toString());
    sheet.getRangeByIndex(i + 5, 2).setText(trans[i].type.toString());
    sheet.getRangeByIndex(i + 5, 3).setText(trans[i].amount.toString());
    sheet.getRangeByIndex(i + 5, 4).setText(trans[i].description.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelStockMovementReport(
    List<TransactionsModel> stockMovement) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Stock Movement_Report'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('Stock Movement Report');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Date');
  sheet.getRangeByIndex(4, 2).setText('Product ID');
  sheet.getRangeByIndex(4, 3).setText('Product Name');
  sheet.getRangeByIndex(4, 4).setText('Movement Type');
  sheet.getRangeByIndex(4, 5).setText('Quantity');
  sheet.getRangeByIndex(4, 6).setText('Description');

  // loop through the results to set the data in the excel sheet cells
  for (var i = 0; i < stockMovement.length; i++) {
    sheet.getRangeByIndex(i + 5, 1).setText(stockMovement[i].date.toString());
    sheet.getRangeByIndex(i + 5, 2).setText(stockMovement[i].id.toString());
    sheet
        .getRangeByIndex(i + 5, 3)
        .setText(stockMovement[i].productName.toString());
    sheet.getRangeByIndex(i + 5, 4).setText(stockMovement[i].type.toString());
    sheet.getRangeByIndex(i + 5, 5).setText(stockMovement[i].amount.toString());
    sheet
        .getRangeByIndex(i + 5, 6)
        .setText(stockMovement[i].description.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelDebtsCustomerReport(
    List<DebtsCustomerModel> debtsCustomer) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Debts_Customer_Report'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('Debts Customer Report');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Customer ID');
  sheet.getRangeByIndex(4, 2).setText('Customer Name');
  sheet.getRangeByIndex(4, 3).setText('Total Debts');

  // loop through the results to set the data in the excel sheet cells
  for (var i = 0; i < debtsCustomer.length; i++) {
    sheet
        .getRangeByIndex(i + 5, 1)
        .setText(debtsCustomer[i].customerID.toString());
    sheet
        .getRangeByIndex(i + 5, 2)
        .setText(debtsCustomer[i].customerName.toString());
    sheet
        .getRangeByIndex(i + 5, 3)
        .setText(debtsCustomer[i].totalDebts.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelDebtsSupplierReport(
    List<DebtsSupplierModel> debtsSupplier) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Debts_Supplier_Report'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('Debts Supplier Report');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Customer ID');
  sheet.getRangeByIndex(4, 2).setText('Customer Name');
  sheet.getRangeByIndex(4, 3).setText('Total Debts');

  // loop through the results to set the data in the excel sheet cells
  for (var i = 0; i < debtsSupplier.length; i++) {
    sheet
        .getRangeByIndex(i + 5, 1)
        .setText(debtsSupplier[i].supplierID.toString());
    sheet
        .getRangeByIndex(i + 5, 2)
        .setText(debtsSupplier[i].supplierName.toString());
    sheet
        .getRangeByIndex(i + 5, 3)
        .setText(debtsSupplier[i].totalDebts.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelSalesCustomerReport(
    List<Sales> salesCustomer) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Sales_Customer_Report'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('Sales Customer Report');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  // sheet.getRangeByIndex(4, 1).setText('Customer ID');
  sheet.getRangeByIndex(4, 1).setText('Customer Name');
  sheet.getRangeByIndex(4, 2).setText('Total Sales');

  // loop through the results to set the data in the excel sheet cells
  for (var i = 0; i < salesCustomer.length; i++) {
    /// sheet.getRangeByIndex(i + 5, 1).setText(salesCustomer[i].id.toString());
    sheet.getRangeByIndex(i + 5, 1).setText(salesCustomer[i].type.toString());
    sheet
        .getRangeByIndex(i + 5, 2)
        .setText(salesCustomer[i].totalSales.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelSalesDateReport(List<Sales> salesDate) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Sales_Date_Report'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('Sales Date Report');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Date');
  sheet.getRangeByIndex(4, 2).setText('Total Sales');

  // loop through the results to set the data in the excel sheet cells
  for (var i = 0; i < salesDate.length; i++) {
    sheet.getRangeByIndex(i + 5, 1).setText(salesDate[i].type.toString());
    sheet.getRangeByIndex(i + 5, 2).setText(salesDate[i].totalSales.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelSalesMonthReport(
    List<Sales> salesMonth) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Sales_Month_Report'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('Sales Month Report');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Month');
  sheet.getRangeByIndex(4, 2).setText('Total Sales');

  // loop through the results to set the data in the excel sheet cells
  for (var i = 0; i < salesMonth.length; i++) {
    sheet.getRangeByIndex(i + 5, 1).setText(salesMonth[i].type.toString());
    sheet
        .getRangeByIndex(i + 5, 2)
        .setText(salesMonth[i].totalSales.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelSalesItemReport(List<Sales> salesItem) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Sales_Item_Report'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('Sales Item Report');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Item');
  sheet.getRangeByIndex(4, 2).setText('Total Sales');

  // loop through the results to set the data in the excel sheet cells
  for (var i = 0; i < salesItem.length; i++) {
    sheet.getRangeByIndex(i + 5, 1).setText(salesItem[i].type.toString());
    sheet.getRangeByIndex(i + 5, 2).setText(salesItem[i].totalSales.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}
