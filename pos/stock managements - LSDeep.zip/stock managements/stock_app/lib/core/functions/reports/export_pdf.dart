import 'package:get/get.dart';
import 'package:printing/printing.dart';
import 'package:stock_app/controllers/companyInfo_controller.dart';
import 'package:stock_app/core/functions/prints.dart';
import 'package:stock_app/models/report_model.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

var controller = Get.find<CompanyInfoController>();
var companyLogo = controller.data.image;
var companyName = controller.data.companyName;

printExpensesReport(List<ExpensesReportModel> listExpenses) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final h = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Expenses Report',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final tb = pw.Table(
    children: [
      pw.TableRow(
        decoration: const pw.BoxDecoration(shape: pw.BoxShape.rectangle),
        children: [
          'Date and Time',
          'Expense Type',
          'Amount',
        ]
            .map(
              (title) => pw.Container(
                margin: const pw.EdgeInsets.only(bottom: 20),
                child: pw.Text(
                  title,
                  style: pw.TextStyle(
                    fontSize: 15,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
              ),
            )
            .toList(),
      ),
      for (var expense in listExpenses) ...[
        pw.TableRow(
          verticalAlignment: pw.TableCellVerticalAlignment.top,
          decoration: const pw.BoxDecoration(),
          children: [
            textEdit(expense.date.toString()),
            textEdit(expense.expenseType.toString()),
            textEdit(expense.amount.toString()),
          ]
              .map((cell) => cell is pw.Text
                  ? cell
                  : pw.Container(
                      //alignment: pw.Alignment.bottomCenter,
                      // height: 50,
                      child: cell,
                    ))
              .toList(),
        ),
      ]
    ],
  );

  widgets.add(h);
  widgets.add(tb);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      // orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdfDoc.save(),
      name: 'Expenses Report');
}

printProfitsAndLossesReport(List<ProfitLoss> profits) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final h = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'profit/Loss Report',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final tb = pw.Table(
    children: [
      pw.TableRow(
        decoration: const pw.BoxDecoration(shape: pw.BoxShape.rectangle),
        children: [
          'Date',
          'Total purchases',
          'Total sales',
          'Expense',
          'profit/Loss',
        ]
            .map(
              (title) => pw.Container(
                margin: const pw.EdgeInsets.only(bottom: 20),
                child: pw.Text(
                  title,
                  style: pw.TextStyle(
                    fontSize: 15,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
              ),
            )
            .toList(),
      ),
      for (var profit in profits) ...[
        pw.TableRow(
          verticalAlignment: pw.TableCellVerticalAlignment.top,
          decoration: const pw.BoxDecoration(),
          children: [
            textEdit(profit.month.toString()),
            textEdit(profit.totalPurchases.toString()),
            textEdit(profit.totalSales.toString()),
            textEdit(profit.totalExpenses.toString()),
            textEdit(profit.profit.toString()),
          ]
              .map((cell) => cell is pw.Text
                  ? cell
                  : pw.Container(
                      //alignment: pw.Alignment.bottomCenter,
                      // height: 50,
                      child: cell,
                    ))
              .toList(),
        ),
      ]
    ],
  );

  widgets.add(h);
  widgets.add(tb);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      // orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdfDoc.save(),
      name: 'profit/Loss Report');
}

printTransactionsReport(List<TransactionsModel> transs) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final header = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Transactions Report',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final body = pw.Table(
    children: [
      pw.TableRow(
        decoration: const pw.BoxDecoration(shape: pw.BoxShape.rectangle),
        children: [
          'Date',
          'Type',
          'Amount',
          'Description',
        ]
            .map(
              (title) => pw.Container(
                margin: const pw.EdgeInsets.only(bottom: 20),
                child: pw.Text(
                  title,
                  style: pw.TextStyle(
                    fontSize: 15,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
              ),
            )
            .toList(),
      ),
      for (var trans in transs) ...[
        pw.TableRow(
          verticalAlignment: pw.TableCellVerticalAlignment.top,
          decoration: const pw.BoxDecoration(),
          children: [
            textEdit(trans.date.toString()),
            textEdit(trans.type.toString()),
            textEdit(trans.amount.toString()),
            textEdit(trans.description.toString()),
          ]
              .map((cell) => cell is pw.Text
                  ? cell
                  : pw.Container(
                      //alignment: pw.Alignment.bottomCenter,
                      // height: 50,
                      child: cell,
                    ))
              .toList(),
        ),
      ]
    ],
  );

  widgets.add(header);
  widgets.add(body);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      // orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdfDoc.save(),
      name: 'Transactions Report');
}

printStockMovementsReport(List<TransactionsModel> stockMovement) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final header = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Stock Movement Report',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final body = pw.Table(
    children: [
      pw.TableRow(
        decoration: const pw.BoxDecoration(shape: pw.BoxShape.rectangle),
        children: [
          'Date',
          'Product Name',
          'Movement Type',
          'Quantity',
          'Description',
        ]
            .map(
              (title) => pw.Container(
                margin: const pw.EdgeInsets.only(bottom: 20),
                child: pw.Text(
                  title,
                  style: pw.TextStyle(
                    fontSize: 15,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
              ),
            )
            .toList(),
      ),
      for (var stock in stockMovement) ...[
        pw.TableRow(
          verticalAlignment: pw.TableCellVerticalAlignment.top,
          decoration: const pw.BoxDecoration(),
          children: [
            textEdit(stock.date.toString()),
            textEdit(stock.productName.toString()),
            textEdit(stock.type.toString()),
            textEdit(stock.amount.toString()),
            textEdit(stock.description.toString()),
          ]
              .map((cell) => cell is pw.Text
                  ? cell
                  : pw.Container(
                      //alignment: pw.Alignment.bottomCenter,
                      // height: 50,
                      child: cell,
                    ))
              .toList(),
        ),
      ]
    ],
  );

  widgets.add(header);
  widgets.add(body);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      // orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdfDoc.save(),
      name: 'Stock Movement Report');
}

printDebtsByCustomerReport(List<DebtsCustomerModel> debtsCustomer) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final header = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Debts By Customer Report',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final body = pw.Table(
    children: [
      pw.TableRow(
        decoration: const pw.BoxDecoration(shape: pw.BoxShape.rectangle),
        children: [
          'Customer ID',
          'Customer Name',
          'Total Debts',
        ]
            .map(
              (title) => pw.Container(
                margin: const pw.EdgeInsets.only(bottom: 20),
                child: pw.Text(
                  title,
                  style: pw.TextStyle(
                    fontSize: 15,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
              ),
            )
            .toList(),
      ),
      for (var customer in debtsCustomer) ...[
        pw.TableRow(
          verticalAlignment: pw.TableCellVerticalAlignment.top,
          decoration: const pw.BoxDecoration(),
          children: [
            textEdit(customer.id.toString()),
            textEdit(customer.customerName.toString()),
            textEdit(customer.totalDebts.toString()),
          ]
              .map((cell) => cell is pw.Text
                  ? cell
                  : pw.Container(
                      //alignment: pw.Alignment.bottomCenter,
                      // height: 50,
                      child: cell,
                    ))
              .toList(),
        ),
      ]
    ],
  );

  widgets.add(header);
  widgets.add(body);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      // orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdfDoc.save(),
      name: 'Debts By Customer Report');
}

printDebtsBySupplierReport(List<DebtsSupplierModel> debtsSupplier) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final header = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Debts By Supplier Report',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final body = pw.Table(
    children: [
      pw.TableRow(
        decoration: const pw.BoxDecoration(shape: pw.BoxShape.rectangle),
        children: [
          'Supplier ID',
          'Supplier Name',
          'Total Debts',
        ]
            .map(
              (title) => pw.Container(
                margin: const pw.EdgeInsets.only(bottom: 20),
                child: pw.Text(
                  title,
                  style: pw.TextStyle(
                    fontSize: 15,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
              ),
            )
            .toList(),
      ),
      for (var supplier in debtsSupplier) ...[
        pw.TableRow(
          verticalAlignment: pw.TableCellVerticalAlignment.top,
          decoration: const pw.BoxDecoration(),
          children: [
            textEdit(supplier.id.toString()),
            textEdit(supplier.supplierName.toString()),
            textEdit(supplier.totalDebts.toString()),
          ]
              .map((cell) => cell is pw.Text
                  ? cell
                  : pw.Container(
                      //alignment: pw.Alignment.bottomCenter,
                      // height: 50,
                      child: cell,
                    ))
              .toList(),
        ),
      ]
    ],
  );

  widgets.add(header);
  widgets.add(body);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      // orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdfDoc.save(),
      name: 'Debts By Supplier Report');
}

printSalesByCustomerReport(List<Sales> salesCustomer) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final header = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Sales By Customer Report',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final body = pw.Table(
    children: [
      pw.TableRow(
        decoration: const pw.BoxDecoration(shape: pw.BoxShape.rectangle),
        children: [
          // 'Customer ID',
          'Customer Name',
          'Total Sales',
        ]
            .map(
              (title) => pw.Container(
                margin: const pw.EdgeInsets.only(bottom: 20),
                child: pw.Text(
                  title,
                  style: pw.TextStyle(
                    fontSize: 15,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
              ),
            )
            .toList(),
      ),
      for (var salCustomer in salesCustomer) ...[
        pw.TableRow(
          verticalAlignment: pw.TableCellVerticalAlignment.top,
          decoration: const pw.BoxDecoration(),
          children: [
            // textEdit(salCustomer.id.toString()),
            textEdit(salCustomer.type.toString()),
            textEdit(salCustomer.totalSales.toString()),
          ]
              .map((cell) => cell is pw.Text
                  ? cell
                  : pw.Container(
                      //alignment: pw.Alignment.bottomCenter,
                      // height: 50,
                      child: cell,
                    ))
              .toList(),
        ),
      ]
    ],
  );

  widgets.add(header);
  widgets.add(body);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      // orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdfDoc.save(),
      name: 'Sales By Customer Report');
}

printSalesByDateReport(List<Sales> salesDate) async {
  List<pw.Widget> widgets = [];
  // final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final header = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Sales By Date Report',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final body = pw.Table(
    children: [
      pw.TableRow(
        decoration: const pw.BoxDecoration(shape: pw.BoxShape.rectangle),
        children: [
          'Date',
          'Total Sales',
        ]
            .map(
              (title) => pw.Container(
                margin: const pw.EdgeInsets.only(bottom: 20),
                child: pw.Text(
                  title,
                  style: pw.TextStyle(
                    fontSize: 15,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
              ),
            )
            .toList(),
      ),
      for (var salesD in salesDate) ...[
        pw.TableRow(
          verticalAlignment: pw.TableCellVerticalAlignment.top,
          decoration: const pw.BoxDecoration(),
          children: [
            textEdit(salesD.type.toString()),
            textEdit(salesD.totalSales.toString()),
          ]
              .map((cell) => cell is pw.Text
                  ? cell
                  : pw.Container(
                      //alignment: pw.Alignment.bottomCenter,
                      // height: 50,
                      child: cell,
                    ))
              .toList(),
        ),
      ]
    ],
  );

  widgets.add(header);
  widgets.add(body);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      // orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdfDoc.save(),
      name: 'Sales By Date Report');
}

printSalesByMonthReport(List<Sales> salesManth) async {
  List<pw.Widget> widgets = [];
  //final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final header = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Sales By Month Report',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final body = pw.Table(
    children: [
      pw.TableRow(
        decoration: const pw.BoxDecoration(shape: pw.BoxShape.rectangle),
        children: [
          'Date',
          'Total Sales',
        ]
            .map(
              (title) => pw.Container(
                margin: const pw.EdgeInsets.only(bottom: 20),
                child: pw.Text(
                  title,
                  style: pw.TextStyle(
                    fontSize: 15,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
              ),
            )
            .toList(),
      ),
      for (var salesM in salesManth) ...[
        pw.TableRow(
          verticalAlignment: pw.TableCellVerticalAlignment.top,
          decoration: const pw.BoxDecoration(),
          children: [
            textEdit(salesM.type.toString()),
            textEdit(salesM.totalSales.toString()),
          ]
              .map((cell) => cell is pw.Text
                  ? cell
                  : pw.Container(
                      //alignment: pw.Alignment.bottomCenter,
                      // height: 50,
                      child: cell,
                    ))
              .toList(),
        ),
      ]
    ],
  );

  widgets.add(header);
  widgets.add(body);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      // orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdfDoc.save(),
      name: 'Sales By Month Report');
}

printSalesByItemReport(List<Sales> salesItem) async {
  List<pw.Widget> widgets = [];
  //final image = await imageFromAssetBundle('assets/school-logo.png');
  final netImage = await networkImage(companyLogo);

  final header = pw.Column(children: [
    pw.Align(
      alignment: pw.Alignment.topCenter,
      child: pw.Image(netImage,
          width: 100, height: 100), // our logo for the official PDF
    ),
    //pw.Row(children: []),
    pw.Text(
      companyName,
      style: const pw.TextStyle(fontSize: 17.00),
    ),
    pw.SizedBox(height: 10.00),
    pw.Align(
      alignment: pw.Alignment.topLeft,
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(
            'Sales By Item Report',
            style: const pw.TextStyle(fontSize: 15.00),
          ),
          pw.Text(
            selectedDateTime,
            style: const pw.TextStyle(fontSize: 15.00),
          ),
        ],
      ),
    ),
    pw.Divider(),
    pw.SizedBox(height: 15.00),
  ]);

  final body = pw.Table(
    children: [
      pw.TableRow(
        decoration: const pw.BoxDecoration(shape: pw.BoxShape.rectangle),
        children: [
          'Item Details',
          'Total Sales',
        ]
            .map(
              (title) => pw.Container(
                margin: const pw.EdgeInsets.only(bottom: 20),
                child: pw.Text(
                  title,
                  style: pw.TextStyle(
                    fontSize: 15,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
              ),
            )
            .toList(),
      ),
      for (var salesI in salesItem) ...[
        pw.TableRow(
          verticalAlignment: pw.TableCellVerticalAlignment.top,
          decoration: const pw.BoxDecoration(),
          children: [
            textEdit(salesI.type.toString()),
            textEdit(salesI.totalSales.toString()),
          ]
              .map((cell) => cell is pw.Text
                  ? cell
                  : pw.Container(
                      //alignment: pw.Alignment.bottomCenter,
                      // height: 50,
                      child: cell,
                    ))
              .toList(),
        ),
      ]
    ],
  );

  widgets.add(header);
  widgets.add(body);
  final pdfDoc = pw.Document();
  pdfDoc.addPage(
    pw.MultiPage(
      // orientation: pw.PageOrientation.landscape,
      pageFormat: PdfPageFormat.a4,
      build: (context) => widgets, //here goes the widgets list
    ),
  );
  Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdfDoc.save(),
      name: 'Sales By Item Report');
}

pw.Padding textEdit(String text) {
  return pw.Padding(
      padding: const pw.EdgeInsets.only(top: 6, bottom: 6, left: 10, right: 10),
      child: pw.Text(
        text,
        style: const pw.TextStyle(fontSize: 15),
        maxLines: 2, // Set the maximum number of lines
        softWrap: true,
        overflow: pw.TextOverflow.span,
      ));
}
