// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:stock_app/models/report_model.dart';

// var _collection = FirebaseFirestore.instance.collection('reports');

// Future<void> getExp(String documentId) async {
//   try {
//     var documentSnapshot = await _collection
//         .doc(documentId)
//         .get();

//     var data = documentSnapshot.data() as Map<String, dynamic>;

//     expenses.assignAll(
//       (data['expenses'] as List<dynamic>)
//           .map((reportData) => ExpensesModel.fromMap(reportData))
//           .toList(),
//     );

//     // Add similar lines for other reports
//   } catch (e) {
//     print('Error getting reports: $e');
//   }
// }

// Future<void> getPro(String documentId) async {
//   try {
//     var documentSnapshot = await _collection
//         .doc(documentId)
//         .get();

//     var data = documentSnapshot.data() as Map<String, dynamic>;

//     profitsAndLosses.assignAll(
//       (data['profitsAndLosses'] as List<dynamic>)
//           .map((reportData) => ProfitsModel.fromMap(reportData))
//           .toList(),
//     );

//     // Add similar lines for other reports
//   } catch (e) {
//     print('Error getting reports: $e');
//   }
// }
