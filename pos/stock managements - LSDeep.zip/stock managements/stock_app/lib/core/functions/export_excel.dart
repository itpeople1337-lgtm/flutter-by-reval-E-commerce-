import 'dart:io';

// import 'package:get/get.dart';
import 'package:get/get.dart';
import 'package:stock_app/models/customer_model.dart';
import 'package:stock_app/models/debts_model.dart';
import 'package:stock_app/models/expense_model.dart';
import 'package:stock_app/models/in_out_model.dart';
import 'package:stock_app/models/product_model.dart';
import 'package:stock_app/models/supplier_model.dart';
import 'package:syncfusion_flutter_xlsio/xlsio.dart' as excel;

///////////////// lists ////////////////////

Future<void> generateAndSaveExcelListCustomers(
    List<CustomerModel> listCustomers) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'List_Customers'; // the name of the excel

  sheet.getRangeByIndex(1, 1).setText('All Customers');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Name');
  sheet.getRangeByIndex(4, 2).setText('Address');
  sheet.getRangeByIndex(4, 3).setText('Email');
  sheet.getRangeByIndex(4, 4).setText('Phone');
  sheet.getRangeByIndex(4, 5).setText('Text ID');
  sheet.getRangeByIndex(4, 6).setText('Discount');
  sheet.getRangeByIndex(4, 7).setText('Bank Details');
  sheet.getRangeByIndex(4, 8).setText('Notes');

  // loop through the results to set the data in the excel sheet cells
  for (var i = 0; i < listCustomers.length; i++) {
    sheet.getRangeByIndex(i + 5, 1).setText(listCustomers[i].name);
    sheet
        .getRangeByIndex(i + 5, 2)
        .setText(listCustomers[i].address.toString());
    sheet.getRangeByIndex(i + 5, 3).setText(listCustomers[i].email.toString());
    sheet.getRangeByIndex(i + 5, 4).setText(listCustomers[i].phone.toString());
    sheet.getRangeByIndex(i + 5, 5).setText(listCustomers[i].textId.toString());
    sheet
        .getRangeByIndex(i + 5, 6)
        .setText(listCustomers[i].discount.toString());
    sheet
        .getRangeByIndex(i + 5, 7)
        .setText(listCustomers[i].bankDetails.toString());
    sheet.getRangeByIndex(i + 5, 8).setText(listCustomers[i].notes.toString());
    // save the document in the downloads file
    // final List<int> bytes = workbook.saveAsStream();
    // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

    // Build the file path with a unique timestamp to avoid overwriting
    final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
    final String uniqueFilePath =
        '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

    // Save the document in the downloads file
    final List<int> bytes = workbook.saveAsStream();
    File(uniqueFilePath).writeAsBytes(bytes);

    Get.snackbar('Done', 'Excel file successfully downloaded',
        snackPosition: SnackPosition.BOTTOM);
  }
}

Future<void> generateAndSaveExcelListExpenses(
    List<ExpenseModel> listExpenses) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'List_Expenses'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('All Expenses');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Amount');
  sheet.getRangeByIndex(4, 2).setText('Date and Time');
  sheet.getRangeByIndex(4, 3).setText('Expense Type');
  sheet.getRangeByIndex(4, 4).setText('Name');
  sheet.getRangeByIndex(4, 5).setText('Store');

  // loop through the results to set the data in the excel sheet cells
  for (var i = 0; i < listExpenses.length; i++) {
    sheet.getRangeByIndex(i + 5, 1).setText(listExpenses[i].amount);
    sheet.getRangeByIndex(i + 5, 2).setText(listExpenses[i].date.toString());
    sheet
        .getRangeByIndex(i + 5, 3)
        .setText(listExpenses[i].category.toString());
    sheet.getRangeByIndex(i + 5, 4).setText(listExpenses[i].name.toString());
    sheet.getRangeByIndex(i + 5, 5).setText(listExpenses[i].store.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelListIncoming(
    List<InOutModel> listIncomingProducts) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'List_Incoming'; // the name of the excel

  sheet.getRangeByIndex(1, 1).setText('All Incoming Products');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  sheet.getRangeByIndex(4, 1).setText('Document No');
  sheet.getRangeByIndex(4, 2).setText('Quantity');
  sheet.getRangeByIndex(4, 3).setText('Date and Time');
  sheet.getRangeByIndex(4, 4).setText('Client Name');
  sheet.getRangeByIndex(4, 5).setText('Description');

  for (var i = 0; i < listIncomingProducts.length; i++) {
    sheet.getRangeByIndex(i + 5, 1).setText(listIncomingProducts[i].docNo);
    sheet
        .getRangeByIndex(i + 5, 2)
        .setText(listIncomingProducts[i].quantity.toString());
    sheet
        .getRangeByIndex(i + 5, 3)
        .setText(listIncomingProducts[i].date.toString());
    sheet
        .getRangeByIndex(i + 5, 4)
        .setText(listIncomingProducts[i].clientName.toString());
    sheet
        .getRangeByIndex(i + 5, 5)
        .setText(listIncomingProducts[i].details.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelListOutgoing(
    List<InOutModel> listOutgoingProducts) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'List_Outgoing'; // the name of the excel

  sheet.getRangeByIndex(1, 1).setText('All Outgoing Products');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  sheet.getRangeByIndex(4, 1).setText('Document No');
  sheet.getRangeByIndex(4, 2).setText('Quantity');
  sheet.getRangeByIndex(4, 3).setText('Date and Time');
  sheet.getRangeByIndex(4, 4).setText('Client Name');
  sheet.getRangeByIndex(4, 5).setText('Description');

  for (var i = 0; i < listOutgoingProducts.length; i++) {
    sheet.getRangeByIndex(i + 5, 1).setText(listOutgoingProducts[i].docNo);
    sheet
        .getRangeByIndex(i + 5, 2)
        .setText(listOutgoingProducts[i].quantity.toString());
    sheet
        .getRangeByIndex(i + 5, 3)
        .setText(listOutgoingProducts[i].date.toString());
    sheet
        .getRangeByIndex(i + 5, 4)
        .setText(listOutgoingProducts[i].clientName.toString());
    sheet
        .getRangeByIndex(i + 5, 5)
        .setText(listOutgoingProducts[i].details.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelListProducts(
    List<ProductModel> lproducts) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'List_Products'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('All Products');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Name');
  sheet.getRangeByIndex(4, 2).setText('Quantity');
  sheet.getRangeByIndex(4, 3).setText('sellingprice');
  sheet.getRangeByIndex(4, 4).setText('buyingsprice');
  sheet.getRangeByIndex(4, 5).setText('Date');
  sheet.getRangeByIndex(4, 6).setText('Category');
  sheet.getRangeByIndex(4, 7).setText('Store');
  sheet.getRangeByIndex(4, 8).setText('Color');
  sheet.getRangeByIndex(4, 10).setText('Barcode');
  sheet.getRangeByIndex(4, 11).setText('Description');

  // loop through the results to set the data in the excel sheet cells
  for (var i = 0; i < lproducts.length; i++) {
    sheet.getRangeByIndex(i + 5, 1).setText(lproducts[i].name);
    sheet.getRangeByIndex(i + 5, 2).setText(lproducts[i].quantity.toString());
    sheet
        .getRangeByIndex(i + 5, 3)
        .setText(lproducts[i].sellingprice.toString());
    sheet
        .getRangeByIndex(i + 5, 4)
        .setText(lproducts[i].purchaseprice.toString());
    sheet.getRangeByIndex(i + 5, 5).setText(lproducts[i].date.toString());
    sheet.getRangeByIndex(i + 5, 6).setText(lproducts[i].category.toString());
    sheet.getRangeByIndex(i + 5, 7).setText(lproducts[i].storeName.toString());
    sheet.getRangeByIndex(i + 5, 8).setText(lproducts[i].color.toString());
    sheet.getRangeByIndex(i + 5, 10).setText(lproducts[i].barcode.toString());
    sheet.getRangeByIndex(i + 5, 11).setText(lproducts[i].details.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelListSuppliers(
    List<SupplierModel> listSuppliers) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'List_Suppliers'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('All Suppliers');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Name');
  sheet.getRangeByIndex(4, 2).setText('Address');
  sheet.getRangeByIndex(4, 3).setText('Email');
  sheet.getRangeByIndex(4, 4).setText('Phone');
  sheet.getRangeByIndex(4, 5).setText('Text ID');
  sheet.getRangeByIndex(4, 6).setText('Bank Details');
  sheet.getRangeByIndex(4, 7).setText('Notes');

  // loop through the results to set the data in the excel sheet cells
  for (var i = 0; i < listSuppliers.length; i++) {
    sheet.getRangeByIndex(i + 5, 1).setText(listSuppliers[i].name);
    sheet
        .getRangeByIndex(i + 5, 2)
        .setText(listSuppliers[i].address.toString());
    sheet.getRangeByIndex(i + 5, 3).setText(listSuppliers[i].email.toString());
    sheet.getRangeByIndex(i + 5, 4).setText(listSuppliers[i].phone.toString());
    sheet.getRangeByIndex(i + 5, 5).setText(listSuppliers[i].textId.toString());
    sheet
        .getRangeByIndex(i + 5, 6)
        .setText(listSuppliers[i].bankDetails.toString());
    sheet.getRangeByIndex(i + 5, 7).setText(listSuppliers[i].notes.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelDebtsCustomers(
    List<DebtsModel> listSuppliers) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Debts_Customers'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('Debts Customers');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Name');
  sheet.getRangeByIndex(4, 2).setText('totalDebt');
  sheet.getRangeByIndex(4, 3).setText('amountReceived');
  sheet.getRangeByIndex(4, 4).setText('remainingDebt');
  sheet.getRangeByIndex(4, 5).setText('date');
  sheet.getRangeByIndex(4, 6).setText('Notes');

  // loop through the results to set the data in the excel sheet cells
  for (var i = 0; i < listSuppliers.length; i++) {
    sheet.getRangeByIndex(i + 5, 1).setText(listSuppliers[i].clientName);
    sheet
        .getRangeByIndex(i + 5, 2)
        .setText(listSuppliers[i].totalDebt.toString());
    sheet
        .getRangeByIndex(i + 5, 3)
        .setText(listSuppliers[i].amountReceived.toString());
    sheet
        .getRangeByIndex(i + 5, 4)
        .setText(listSuppliers[i].remainingDebt.toString());
    sheet.getRangeByIndex(i + 5, 5).setText(listSuppliers[i].date.toString());
    sheet.getRangeByIndex(i + 5, 6).setText(listSuppliers[i].notes.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelDebtsSuppliers(
    List<DebtsModel> listSuppliers) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Debts_Suppliers'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('Debts Suppliers');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Name');
  sheet.getRangeByIndex(4, 2).setText('totalDebt');
  sheet.getRangeByIndex(4, 3).setText('amountReceived');
  sheet.getRangeByIndex(4, 4).setText('remainingDebt');
  sheet.getRangeByIndex(4, 5).setText('date');
  sheet.getRangeByIndex(4, 6).setText('Notes');

  // loop through the results to set the data in the excel sheet cells
  for (var i = 0; i < listSuppliers.length; i++) {
    sheet.getRangeByIndex(i + 5, 1).setText(listSuppliers[i].clientName);
    sheet
        .getRangeByIndex(i + 5, 2)
        .setText(listSuppliers[i].totalDebt.toString());
    sheet
        .getRangeByIndex(i + 5, 3)
        .setText(listSuppliers[i].amountReceived.toString());
    sheet
        .getRangeByIndex(i + 5, 4)
        .setText(listSuppliers[i].remainingDebt.toString());
    sheet.getRangeByIndex(i + 5, 5).setText(listSuppliers[i].date.toString());
    sheet.getRangeByIndex(i + 5, 6).setText(listSuppliers[i].notes.toString());
  }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

/////////////////// details ///////////////////
Future<void> generateAndSaveExcelProductDetails(
    ProductModel? productDetails) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Product_Details'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('Product Detalis');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Name');
  sheet.getRangeByIndex(4, 2).setText('Quantity');
  sheet.getRangeByIndex(4, 3).setText('sellingprice');
  sheet.getRangeByIndex(4, 4).setText('buyingsprice');
  sheet.getRangeByIndex(4, 5).setText('Date');
  sheet.getRangeByIndex(4, 6).setText('Category');
  sheet.getRangeByIndex(4, 7).setText('Store');
  sheet.getRangeByIndex(4, 8).setText('Color');
  sheet.getRangeByIndex(4, 10).setText('Barcode');
  sheet.getRangeByIndex(4, 11).setText('Description');

  // loop through the results to set the data in the excel sheet cells
  //for (var i = 0; i < productDetails!; i++) {
  sheet.getRangeByIndex(5, 1).setText(productDetails!.name);
  sheet.getRangeByIndex(5, 2).setText(productDetails.quantity.toString());
  sheet.getRangeByIndex(5, 3).setText(productDetails.sellingprice.toString());
  sheet.getRangeByIndex(5, 4).setText(productDetails.purchaseprice.toString());
  sheet.getRangeByIndex(5, 5).setText(productDetails.date.toString());
  sheet.getRangeByIndex(5, 6).setText(productDetails.category.toString());
  sheet.getRangeByIndex(5, 7).setText(productDetails.storeName.toString());
  sheet.getRangeByIndex(5, 8).setText(productDetails.color.toString());
  sheet.getRangeByIndex(5, 10).setText(productDetails.barcode.toString());
  sheet.getRangeByIndex(5, 11).setText(productDetails.details.toString());
  //   }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelsupplierDetails(
    SupplierModel? supplierDetails) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Supplier Details   '; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('Supplier Details');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Name');
  sheet.getRangeByIndex(4, 2).setText('Address');
  sheet.getRangeByIndex(4, 3).setText('Email');
  sheet.getRangeByIndex(4, 4).setText('Phone');
  sheet.getRangeByIndex(4, 5).setText('Text ID');
  sheet.getRangeByIndex(4, 6).setText('Bank Details');
  sheet.getRangeByIndex(4, 7).setText('Notes');

  // loop through the results to set the data in the excel sheet cells
  /// for (var i = 0; i < listSuppliers.length; i++) {
  sheet.getRangeByIndex(5, 1).setText(supplierDetails!.name);
  sheet.getRangeByIndex(5, 2).setText(supplierDetails.address.toString());
  sheet.getRangeByIndex(5, 3).setText(supplierDetails.email.toString());
  sheet.getRangeByIndex(5, 4).setText(supplierDetails.phone.toString());
  sheet.getRangeByIndex(5, 5).setText(supplierDetails.textId.toString());
  sheet.getRangeByIndex(5, 6).setText(supplierDetails.bankDetails.toString());
  sheet.getRangeByIndex(5, 7).setText(supplierDetails.notes.toString());
  // }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);
  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExceloutgoingDetails(
    InOutModel? outgoingDetails) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Outgoing Details'; // the name of the excel

  sheet.getRangeByIndex(1, 1).setText('Outgoing Details');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  sheet.getRangeByIndex(4, 1).setText('Document No');
  sheet.getRangeByIndex(4, 2).setText('Quantity');
  sheet.getRangeByIndex(4, 3).setText('Date and Time');
  sheet.getRangeByIndex(4, 4).setText('Client Name');
  sheet.getRangeByIndex(4, 5).setText('Description');

  // loop through the results to set the data in the excel sheet cells
  //for (var i = 0; i < listOutgoing.length; i++) {
  sheet.getRangeByIndex(5, 1).setText(outgoingDetails!.docNo);
  sheet.getRangeByIndex(5, 2).setText(outgoingDetails.quantity.toString());
  sheet.getRangeByIndex(5, 3).setText(outgoingDetails.date.toString());
  sheet.getRangeByIndex(5, 4).setText(outgoingDetails.clientName.toString());
  sheet.getRangeByIndex(5, 5).setText(outgoingDetails.details.toString());
  // }

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelincomingDetails(
    InOutModel? incomingDetails) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Incoming Details'; // the name of the excel

  sheet.getRangeByIndex(1, 1).setText('Incoming Details');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  sheet.getRangeByIndex(4, 1).setText('Document No');
  sheet.getRangeByIndex(4, 2).setText('Quantity');
  sheet.getRangeByIndex(4, 3).setText('Date and Time');
  sheet.getRangeByIndex(4, 4).setText('Client Name');
  sheet.getRangeByIndex(4, 5).setText('Description');

  // loop through the results to set the data in the excel sheet cells
  //for (var i = 0; i < listIncoming.length; i++) {
  sheet.getRangeByIndex(5, 1).setText(incomingDetails!.docNo);
  sheet.getRangeByIndex(5, 2).setText(incomingDetails.quantity.toString());
  sheet.getRangeByIndex(5, 3).setText(incomingDetails.date.toString());
  sheet.getRangeByIndex(5, 4).setText(incomingDetails.clientName.toString());
  sheet.getRangeByIndex(5, 5).setText(incomingDetails.details.toString());
  // }
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // await File('/storage/emulated/0/Download/$excelFile.xlsx')
  //     .writeAsBytes(bytes);
  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelexpenseDetails(
    ExpenseModel? expenseDetails) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'Expense_Details'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('Expense Details');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Amount');
  sheet.getRangeByIndex(4, 2).setText('Date and Time');
  sheet.getRangeByIndex(4, 3).setText('Expense Type');
  sheet.getRangeByIndex(4, 4).setText('Name');
  sheet.getRangeByIndex(4, 5).setText('Store');

  // loop through the results to set the data in the excel sheet cells
  // for (var i = 0; i <  expenseDetails.length; i++) {
  sheet.getRangeByIndex(5, 1).setText(expenseDetails!.amount);
  sheet.getRangeByIndex(5, 2).setText(expenseDetails.date.toString());
  sheet.getRangeByIndex(5, 3).setText(expenseDetails.category.toString());
  sheet.getRangeByIndex(5, 4).setText(expenseDetails.name.toString());
  sheet.getRangeByIndex(5, 5).setText(expenseDetails.store.toString());
  //}
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
}

Future<void> generateAndSaveExcelcustomerDetails(
    CustomerModel? customerDetails) async {
  final excel.Workbook workbook =
      excel.Workbook(); // create a new excel workbook
  final excel.Worksheet sheet = workbook
      .worksheets[0]; // the sheet we will be populating (only the first sheet)
  const String excelFile = 'customer Details'; // the name of the excel

  /// design how the data in the excel sheet will be presented
  /// you can get the cell to populate by index e.g., (1, 1) or by name e.g., (A1)
  sheet.getRangeByIndex(1, 1).setText('Customer Details');
  sheet.getRangeByIndex(2, 1).setText('Form 4 West'); // example class

  // set the titles for the subject results we want to fetch
  sheet.getRangeByIndex(4, 1).setText('Name');
  sheet.getRangeByIndex(4, 2).setText('Address');
  sheet.getRangeByIndex(4, 3).setText('Email');
  sheet.getRangeByIndex(4, 4).setText('Phone');
  sheet.getRangeByIndex(4, 5).setText('Text ID');
  sheet.getRangeByIndex(4, 6).setText('Discount');
  sheet.getRangeByIndex(4, 7).setText('Bank Details');
  sheet.getRangeByIndex(4, 8).setText('Notes');

  // loop through the results to set the data in the excel sheet cells
  //  for (var i = 0; i < listCustomers.length; i++) {
  sheet.getRangeByIndex(5, 1).setText(customerDetails!.name);
  sheet.getRangeByIndex(5, 2).setText(customerDetails.address.toString());
  sheet.getRangeByIndex(5, 3).setText(customerDetails.email.toString());
  sheet.getRangeByIndex(5, 4).setText(customerDetails.phone.toString());
  sheet.getRangeByIndex(5, 5).setText(customerDetails.textId.toString());
  sheet.getRangeByIndex(5, 6).setText(customerDetails.discount.toString());
  sheet.getRangeByIndex(5, 7).setText(customerDetails.bankDetails.toString());
  sheet.getRangeByIndex(5, 8).setText(customerDetails.notes.toString());
  // save the document in the downloads file
  // final List<int> bytes = workbook.saveAsStream();
  // File('/storage/emulated/0/Download/$excelFile.xlsx').writeAsBytes(bytes);

  // Build the file path with a unique timestamp to avoid overwriting
  final String timestamp = DateTime.now().millisecondsSinceEpoch.toString();
  final String uniqueFilePath =
      '/storage/emulated/0/Download/$excelFile-$timestamp.xlsx';

  // Save the document in the downloads file
  final List<int> bytes = workbook.saveAsStream();
  File(uniqueFilePath).writeAsBytes(bytes);

  Get.snackbar('Done', 'Excel file successfully downloaded',
      snackPosition: SnackPosition.BOTTOM);
  // }
}
