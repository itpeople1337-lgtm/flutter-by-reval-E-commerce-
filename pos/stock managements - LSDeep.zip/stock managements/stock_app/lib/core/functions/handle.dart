import 'package:flutter/material.dart';
import 'package:get/get.dart';

openDialogExit(String pageName) async {
  await Get.defaultDialog(
    title: 'Exit!!',
    content: const Text(' Are You Sure ?'),
    actions: [
      TextButton(
        onPressed: () {
          Get.back();
        },
        child: const Text('Cancel'),
      ),
      TextButton(
        onPressed: () {
          Get.offNamed(pageName);
        },
        child: const Text('OK'),
      ),
    ],
  );
}
