// ignore_for_file: constant_identifier_names

import 'package:get/get.dart';
import 'package:stock_app/views/auth/login_view.dart';
import 'package:stock_app/views/auth/register_view.dart';
import 'package:stock_app/views/home/categories/add_category.dart';
import 'package:stock_app/views/home/categories/categories.dart';
import 'package:stock_app/views/home/categories/expenses_categries.dart';
import 'package:stock_app/views/home/categories/products_categories.dart';
import 'package:stock_app/views/home/customers/add_customer.dart';
import 'package:stock_app/views/home/customers/customers.dart';
import 'package:stock_app/views/home/debts/debtsby_customer.dart';
import 'package:stock_app/views/home/debts/debtsby_supplier.dart';
import 'package:stock_app/views/home/debts/list_debts.dart';
import 'package:stock_app/views/home/drawer/notes/ui/pages/note_page.dart';
import 'package:stock_app/views/home/drawer/settings/list_settings.dart';
import 'package:stock_app/views/home/drawer/stores/stores.dart';
import 'package:stock_app/views/home/expenses/add_expense.dart';
import 'package:stock_app/views/home/expenses/expenses.dart';
import 'package:stock_app/views/home/home_screen/home.dart';
import 'package:stock_app/views/home/incoming/incoming.dart';
import 'package:stock_app/views/home/outgoing/outgoing.dart';
import 'package:stock_app/views/home/products/add_product.dart';
import 'package:stock_app/views/home/products/list_products.dart';
import 'package:stock_app/views/home/reports/reports.dart';
import 'package:stock_app/views/home/suppliers/add_supplier.dart';
import 'package:stock_app/views/home/suppliers/suppliers.dart';
import 'package:stock_app/views/onboarding/onboarding.dart';

class AppPages {
  // static const INITIAL = Routes.INITIALPAGE;

  static final routes = [
    // init page
    // GetPage(
    //   name: '/',
    //   page: () => const Language(),
    //   // middlewares: [
    //   //   MyMiddelWare(),
    //   // ],
    // ),

    //on boarding
    GetPage(
      name: '/', //name: Routes.OnBoarding,
      page: () => const OnBoarding(),
      //binding: BindingsBuilder(() => Get.put(ProductController())),
    ),
    // //auth
    GetPage(
      name: Routes.LOGIn,
      page: () => LoginView(),
      transition: Transition.leftToRight,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.REGISTER,
      page: () => RegisterView(),
      transition: Transition.leftToRight,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.MAINHOME,
      page: () => const HomeScreen(),
      transition: Transition.leftToRight,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.ALLPRODUCTS,
      page: () => const ListProducts(''),
      transition: Transition.rightToLeft,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.AddProduct,
      page: () => AddProduct(),
      transition: Transition.leftToRight,
      transitionDuration: const Duration(milliseconds: 400),
    ),

    GetPage(
      name: Routes.Incoming,
      page: () => const Incoming(),
      transition: Transition.rightToLeft,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.Outgoing,
      page: () => const Outgoing(),
      transition: Transition.downToUp,
      transitionDuration: const Duration(milliseconds: 400),
    ),

    GetPage(
      name: Routes.ALLCustomer,
      page: () => const ListCustomers(''),
      transition: Transition.rightToLeft,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.AddCustomer,
      page: () => AddCustomer(),
      transition: Transition.downToUp,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.ALLSuppliers,
      page: () => const ListSuppliers(''),
      transition: Transition.upToDown,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.AddSupplier,
      page: () => AddSupplier(),
      transition: Transition.downToUp,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.ALLExpenses,
      page: () => const ListExpenses(),
      transition: Transition.leftToRight,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.AddExpeses,
      page: () => AddExpense(),
      transition: Transition.downToUp,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.ALLRepoerts,
      page: () => const ListReports(),
      transition: Transition.leftToRight,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.CATEGORIES,
      page: () => const Categories(),
      transition: Transition.downToUp,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.ALLProductsCategories,
      page: () => const ListProductsCategories(),
      transition: Transition.rightToLeft,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.ALLExpensesCategories,
      page: () => const ListExpensesCategories(),
      transition: Transition.leftToRight,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.Stores,
      page: () => const ListStores(),
      transition: Transition.upToDown,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.NOTES,
      page: () => NotePage(),
      transition: Transition.upToDown,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    ///////////////////////////
    GetPage(
      name: Routes.AddCategory,
      page: () => AddCategory(),
      transition: Transition.downToUp,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.DebtsCustomer,
      page: () => const ListDebtsCustomers(''),
      transition: Transition.leftToRight,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    GetPage(
      name: Routes.DebtsSuppliers,
      page: () => const ListDebtsSuppliers(''),
      transition: Transition.leftToRight,
      transitionDuration: const Duration(milliseconds: 400),
    ),

    GetPage(
      name: Routes.ListDebts,
      page: () => const ListDebts(),
      transition: Transition.leftToRight,
      transitionDuration: const Duration(milliseconds: 400),
    ),

    GetPage(
      name: Routes.SETTINGS,
      page: () => const ListSettings(),
      transition: Transition.upToDown,
      transitionDuration: const Duration(milliseconds: 400),
    ),
    // GetPage(
    //   name: Routes.Adddoc,
    //   page: () => AddDocument(),
    // ),
  ];
}

abstract class Routes {
  //onboarding
  static const OnBoarding = '/onboarding';
  //onboarding
  static const INITIALPAGE = '/initialPage';
  //auth
  static const LOGIn = '/login';
  static const REGISTER = '/register';
  static const FORGETPASSORD = '/forget-password';
  static const VERTIYFyCode = '/vertify-code';
  static const VERTIYFyCode_REGISTER = '/vertify-code-register';
  static const RESETPASSwORD = '/reset-password';
  static const CHECK_EMAIL = '/check-email';
  static const VALIDATE_EMAIL = '/validate-email';
  static const SUCCESS_RESETPASSWORD = '/success-reset-password';
  static const SUCCESS_REGISTERtion = '/success-registertion';

//all
  static const ALLPRODUCTS = '/allproducts';
  //static const ALLDOCS = '/alldoct';
  static const Incoming = '/incoming';
  static const Outgoing = '/outgoing';
  static const DebtsCustomer = '/debtsCustomers';
  static const DebtsSuppliers = '/debtsSuppliers';
  static const ALLCustomer = '/allcustomers';
  static const ALLSuppliers = '/allsuppliers';

  static const ALLExpenses = '/allexpenses';
  static const ALLRepoerts = '/allreports';
  static const Stores = '/allStores';
  // static const Stocks = '/allStocks';
  static const ListDebts = '/ListDebts';
  static const ALLProductsCategories = '/allProductsCategories';
  static const ALLExpensesCategories = '/allExpensesCategories';
//add
  static const AddProduct = '/addproduct';
  // static const Adddoc = '/adddoc';
  static const AddInOutProduct = '/add_in_out';
  static const AddCategory = '/addcategory';
  static const AddSupplier = '/addsuplier';
  static const AddCustomer = '/addcustomer';
  static const AddExpeses = '/addexpenses';
  static const BESTSELLING = '/bestselling';
  static const PRODUCTSBYCATEGORY = '/broductsbycategory';

  static const MAINHOME = '/';
  static const HOME = '/products';
  static const APPHOME = '/apphome';
  static const CATEGORIES = '/categories';
  static const SETTINGS = '/settings';
  static const NOTES = '/notes';
}
