import 'package:flutter/material.dart';

class PrintLog extends StatelessWidget {
  const PrintLog({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: MaterialButton(
          onPressed: () async {},
          child: const Text('Click To Handel'),
        ),
      ),
    );
  }
}
