import 'dart:io';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:image_picker/image_picker.dart';
import 'package:stock_app/models/user_model.dart';
import 'package:stock_app/services/firestore_user.dart';
import 'package:stock_app/services/local_storage_user.dart';
import 'package:stock_app/views/control_view.dart';
import 'package:path/path.dart';

class AuthController extends GetxController {
  String? email, password, name, confirmPassword;
  UserModel? _currentUser;
  UserModel? get currentUser => _currentUser;
  String? nm;

  final Rxn<User> _user = Rxn<User>();
  GoogleSignInAccount? _googleUser;
  String? get user => _user.value?.email;
  final _auth = FirebaseAuth.instance;
  bool _loading = false;
  get loading => _loading;

  @override
  void onInit() {
    super.onInit();
    _user.bindStream(_auth.authStateChanges());
    getCurrentUser();
  }

  // get current user from local storage
  getCurrentUser() async {
    _currentUser = await LocalStorageUser.getUserData();
    update();
    nm = currentUser!.name;
  }

  // sign up email and password if you dont have account
  Future<String> signUpWithEmailAndPassword() async {
    try {
      _loading = true;
      update();

      await _auth
          .createUserWithEmailAndPassword(email: email!, password: password!)
          .then((user) {
        saveUser(user);
      });
      _loading = false;
      update();
      Get.offAll(const ControlView());
    } on FirebaseAuthException catch (error) {
      String message = 'Couldn\'t sign up';
      Get.snackbar(
        'Failed to login..',
        message,
        snackPosition: SnackPosition.BOTTOM,
      );

      switch (error.code) {
        case 'email-already-in-use':
          message = 'Email already in use, Please pick another email!';
          break;
        case 'invalid-email':
          message = 'Enter valid e-mail';
          break;
        case 'operation-not-allowed':
          message = 'Email/password accounts are not enabled';
          break;
        case 'weak-password':
          message = 'Password must be more than 5 characters';
          break;
        case 'too-many-requests':
          message = 'Too many requests, Please try again later.';
          break;
      }
      return message;
    } catch (e) {
      return 'Couldn\'t sign up';
    }
    return 'Couldn\'t sign up';
  }

// sign in email and password if you have account
  signInWithEmailAndPassword() async {
    try {
      _loading = true;
      update();
      await _auth
          .signInWithEmailAndPassword(email: email!, password: password!)
          .then((user) {
        FirestoreUser().getUserFromFirestore(user.user!.uid).then((doc) {
          saveUserLocal(
              UserModel.fromJson(doc.data() as Map<dynamic, dynamic>));
        });
      });
      _loading = false;
      update();
      Get.offAll(const ControlView());
    } on FirebaseAuthException catch (exception, s) {
      //  print(exception.toString() + '$s');

      Get.snackbar(
        'Failed to login..',
        '$exception$s',
        snackPosition: SnackPosition.BOTTOM,
      );
      switch ((exception).code) {
        case 'invalid-email':
          return 'Email address is malformed.';
        case 'wrong-password':
          return 'Wrong password.';
        case 'user-not-found':
          return 'No user corresponding to the given email address.';
        case 'user-disabled':
          return 'This user has been disabled.';
        case 'too-many-requests':
          return 'Too many attempts to sign in as this user.';
      }
      return 'Unexpected firebase error, Please try again.';
    } catch (e, s) {
      Get.snackbar(
        'Failed to login..',
        '$e$s',
        snackPosition: SnackPosition.BOTTOM,
      );
      return 'Login failed, Please try again.';
    }
  }

// // sign in with google
  void signInWithGoogleAccount() async {
    try {
      _loading = true;
      GoogleSignIn googleSignIn = GoogleSignIn(scopes: ['email']);
      _googleUser = await googleSignIn.signIn();

      GoogleSignInAuthentication googleSignInAuthentication =
          await _googleUser!.authentication;
      final googleAuthCredential = GoogleAuthProvider.credential(
        idToken: googleSignInAuthentication.idToken,
        accessToken: googleSignInAuthentication.accessToken,
      );

      await _auth.signInWithCredential(googleAuthCredential).then((user) {
        saveUser(user);
      });
      _loading = false;
      Get.offAll(const ControlView());
    } catch (error) {
      String errorMessage =
          error.toString().substring(error.toString().indexOf(' ') + 1);
      Get.snackbar(
        'Failed to login..',
        errorMessage,
        snackPosition: SnackPosition.BOTTOM,
      );
    }
  }
//////// sign in with facebook works but you need to connect with your facebook account developer
  // void signInWithFacebookAccount() async {
  //   try {
  //     final _facebookSignIn = await FacebookAuth.instance.login();

  //     final _facebookAuthCredential =
  //         FacebookAuthProvider.credential(_facebookSignIn.accessToken!.token);

  //     await _auth.signInWithCredential(_facebookAuthCredential).then((user) {
  //       saveUser(user);
  //     });
  //     Get.offAll(ControlView());
  //   } catch (error) {
  //     Get.snackbar(
  //       'Failed to login..',
  //       error.toString(),
  //       snackPosition: SnackPosition.BOTTOM,
  //     );
  //   }
  // }
  updateCurrentUser() async {
    try {
      UserModel userModel = UserModel(
        userId: _currentUser!.userId,
        email: email!,
        name: name!,
        pic: picUrl == null ? _currentUser!.pic : picUrl!,
      );
      await FirebaseAuth.instance.currentUser!.updateEmail(email!);
      await FirebaseAuth.instance.currentUser!.updatePassword(password!);
      FirestoreUser().addUserToFirestore(userModel);
      await LocalStorageUser.setUserData(userModel);
      getCurrentUser();
      Get.back();
    } catch (error) {
      String errorMessage =
          error.toString().substring(error.toString().indexOf(' ') + 1);
      Get.snackbar(
        'Failed to update..',
        errorMessage,
        snackPosition: SnackPosition.BOTTOM,
      );
    }
  }

  void signOut() async {
    try {
      await _auth.signOut();
      LocalStorageUser.clearUserData();
    } catch (error) {
      print(error);
    }
  }

// save user in local storage
  void saveUser(UserCredential? userCredential) async {
    //UserCredential? userCredential;
    UserModel userModel = UserModel(
      userId: userCredential!.user!.uid,
      email: userCredential.user!.email!,
      name: name == null ? userCredential.user!.displayName! : name!,
      pic: userCredential.user!.photoURL == null
          ? 'default'
          : "${userCredential.user!.photoURL!}?width=400",
    );
    FirestoreUser().addUserToFirestore(userModel);
    saveUserLocal(userModel);
  }

  void saveUserLocal(UserModel userModel) async {
    LocalStorageUser.setUserData(userModel);
  }

  File? imageFile;
  String? picUrl;

  cameraImage() async {
    final pickedFile = await ImagePicker().pickImage(
      source: ImageSource.camera,
      maxHeight: 400,
      maxWidth: 400,
    );
    imageFile = File(pickedFile!.path);
    update();
  }

  galleryImage() async {
    final pickedFile = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxHeight: 400,
      maxWidth: 400,
    );
    imageFile = File(pickedFile!.path);
    update();
  }

// "profile" that name of folder in firebase
  uploadImageToFirebase() async {
    String fileName = basename(imageFile!.path);
    Reference firebaseStorageRef =
        FirebaseStorage.instance.ref().child('profile/$fileName');
    UploadTask uploadTask = firebaseStorageRef.putFile(imageFile!);
    picUrl = await (await uploadTask).ref.getDownloadURL();
  }
}
