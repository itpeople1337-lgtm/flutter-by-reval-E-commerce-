import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:stock_app/models/category_model.dart';
import 'package:stock_app/services/firestore_category.dart';

class CategoryController extends GetxController {
  late String name;
  var listCategoriesProducts = <CategoryModel>[].obs;
  var listCategoriesExpenses = <CategoryModel>[].obs;
  List<String> expenseCategory = [];
  String? selectedType;
  List<String> categoryType = ['Products', 'Expenses'];
  final _loading = true.obs;
  get loading => _loading;

  /// all curd functions for product category & expanse category
  /// in firebase i create collection('categories') or product category & expanse category
  getCategoriesByProductFromFireStore() async {
    _loading(true);
    var categoriesProduct =
        await CategoryServices().getCategoryByProductIdFromFirestore();
    listCategoriesProducts.assignAll(categoriesProduct);

    _loading(false);
    update();
  }

  getCategoriesByExpenseFromFireStore() async {
    _loading(true);
    var categoriesExpense =
        await CategoryServices().getCategoryByExpenseIdFromFirestore();
    listCategoriesExpenses.assignAll(categoriesExpense);

    _loading(false);
    update();
  }

  addCategoryToFireStore() async {
    try {
      CategoryModel categoryModel = CategoryModel(
        categoryId: '',
        name: name,
        selectedType: selectedType!,
      );
      await FirebaseFirestore.instance
          .collection('categories')
          .add(categoryModel.toJson());
      update();
    } catch (e) {}
  }

  updateCategoryToFireStore(CategoryModel categoryModel) async {
    await CategoryServices().updateCategoryIdInFirestore(categoryModel);
  }

  deleteCategoryToFireStore(String categoryId) async {
    await CategoryServices().deleteCategoryIdFromFirestore(categoryId);
  }

// get category name product or expense
  getType(String val) {
    selectedType = val;
    update();
  }
  // List<String> getCategoryByProduct() {
  //   return expenseCategory =
  //       listCategoriesProducts.map((ob) => ob.selectedType).toList();
  // }
}
