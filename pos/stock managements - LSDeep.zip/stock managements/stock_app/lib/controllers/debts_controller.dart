import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_cupertino_datetime_picker/flutter_cupertino_datetime_picker.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:stock_app/core/functions/export_excel.dart';
import 'package:stock_app/core/functions/prints.dart';
import 'package:stock_app/core/functions/reports/add_report.dart';
import 'package:stock_app/models/debts_model.dart';
import 'package:stock_app/models/product_model.dart';
import 'package:stock_app/services/firestore_debts.dart';
import 'package:stock_app/views/home/customers/customers.dart';
import 'package:stock_app/views/home/suppliers/suppliers.dart';

class DebtsController extends GetxController {
  late String amountReceived, remainingDebt, docId, totalDebt, notes;
  var listDebtsCustomers = <DebtsModel>[].obs;
  var listDebtsSuppliers = <DebtsModel>[].obs;
  var selectedDateTime = 'Pick Date'.obs;
  var selectClientName = 'Pick Client'.obs;
  var clientType = ''.obs;
  final _loading = true.obs;
  get loading => _loading;
  var title = ''.obs;
  RxInt selectedValue = 0.obs;
  void setSelectedValue(int value) {
    selectedValue.value = value;
  }

  DebtsModel? incomingDetails;
  DebtsModel? outgoingDetails;

  var productList = <String>[];
  var selectedProducts = <ProductModel>[].obs;
// to select any screen shoule be open ListCustomers or ListSuppliers
// word 'get' i put it to handle choose when you click on ListCustomers screen
// and select value you will have two navigation one for customer details
//and other for return customer name so i handle it by add 'get' word
  addClientName() async {
    if (title == 'New Debts Customer') {
      selectClientName.value =
          await Get.to(() => const ListCustomers('get')) ?? 'Pick Client';
      clientType.value = 'Customer';
    } else if (title == 'New Debts Supplier') {
      selectClientName.value =
          await Get.to(() => const ListSuppliers('get')) ?? 'Pick Client';
      clientType.value = 'Supplier';
    } else {
      return;
    }
    update();
  }

  getDebtsCustomersFromFireStore() async {
    _loading(true);
    var debtsCustomers = await DebtsServices().getDebtsCustomersFromFirestore();
    listDebtsCustomers.assignAll(debtsCustomers);
    _loading(false);
    update();
  }

  getDebtsSuppliersFromFireStore() async {
    _loading(true);
    var outgoingProducts =
        await DebtsServices().getDebtsSuppliersFromFirestore();
    listDebtsSuppliers.assignAll(outgoingProducts);
    _loading(false);
    update();
  }

  addDebtsToFireStore() async {
    try {
      DebtsModel debtsModel = DebtsModel(
        date: selectedDateTime.value,
        clientName: selectClientName.value,
        amountReceived: amountReceived,
        remainingDebt: remainingDebt,
        totalDebt: totalDebt,
        clientType: clientType.value,
        notes: notes,
        docId: '',
      );
      await FirebaseFirestore.instance
          .collection('debts')
          .add(debtsModel.toJson());
      debtstoCustomerOrSupplier();
      addTransactionReport(
          amount: double.parse(totalDebt),
          type: 'Debts',
          description: description.value,
          productName: selectClientName.value);
      update();
    } catch (e) {}
  }

  var description = ''.obs;
  debtstoCustomerOrSupplier() {
    if (clientType.value == 'Customer') {
      addDebtsCustomerReport(
        customerName: selectClientName.value,
        totalDebts: double.parse(totalDebt),
      );
      description.value = 'New debt for customer';
    } else if (clientType.value == 'Supplier') {
      addDebtsSupplierReport(
        supplierName: selectClientName.value,
        totalDebts: double.parse(totalDebt),
      );
      description.value = 'New debt for supplier';
    } else {
      return;
    }
  }

  DateTime? selectdate;
  dateTimePickerWidget(BuildContext context) {
    return DatePicker.showDatePicker(
      context,
      dateFormat: 'dd MMMM yyyy HH:mm',
      initialDateTime: DateTime.now(),
      minDateTime: DateTime(2000),
      maxDateTime: DateTime(3000),
      onMonthChangeStartWithFirstDate: true,
      onConfirm: (dateTime, List<int> index) {
        selectdate = dateTime;
        selectedDateTime.value =
            DateFormat('dd-MMM-yyyy - HH:mm').format(selectdate!);
        //  print("aaaaaaaaaaaaaaa" + selectedDateTime.value);
      },
    );
  }

  updateDebtsToFireStore(DebtsModel debtsModel) async {
    await DebtsServices().updateDebtsInFirestore(debtsModel);
  }

  deleteDebtsFromFireStore(String docId) async {
    await DebtsServices().deleteDebtsFromFirestore(docId);
  }

  void handleClicklistDebtsCustomers(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelDebtsCustomers(listDebtsCustomers);
        }
        break;
      case 'Print To Pdf':
        {
          printDebtsCustomers(listDebtsCustomers);
        }
        break;
    }
  }

  void handleClicklistDebtsSuppliers(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelDebtsCustomers(listDebtsSuppliers);
        }
        break;
      case 'Print To Pdf':
        {
          printDebtsSuppliers(listDebtsSuppliers);
        }
        break;
    }
  }
}
