import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:stock_app/core/functions/export_excel.dart';
import 'package:stock_app/core/functions/prints.dart';
import 'package:stock_app/core/functions/reports/add_report.dart';
import 'package:stock_app/models/customer_model.dart';
import 'package:stock_app/services/firestore_customer.dart';
import 'package:url_launcher/url_launcher.dart' as UrlLauncher;
import 'package:url_launcher/url_launcher.dart';

class CustomerController extends GetxController {
  late String name,
      address,
      email,
      phone,
      textId,
      notes,
      bankDetails,
      discount,
      customerId;
  var totalSalesCustomer = 0.0.obs;
  var listCustomers = <CustomerModel>[].obs;
  var filterListCustomers = <CustomerModel>[].obs;
  final _loading = true.obs;
  get loading => _loading;
  CustomerModel? customerDetails;

  getCustomersFromFireStore() async {
    _loading(true);
    var customers = await CustomerServices().getCustomersIdFromFirestore();
    listCustomers.value.assignAll(customers);
    _loading(false);
    filterCustomers('');
    update();
  }

  // to filter search in customer screen
  void filterCustomers(String searchField) {
    if (searchField.isEmpty) {
      filterListCustomers.assignAll(listCustomers);
      update();
    } else {
      filterListCustomers.assignAll(listCustomers
          .where((exc) =>
              exc.name.toLowerCase().contains(searchField.toLowerCase()))
          .toList());
    }
    update();
  }

  addCustomerToFireStore() async {
    try {
      CustomerModel customerModel = CustomerModel(
        name: name,
        address: address,
        email: email,
        phone: phone,
        textId: textId,
        notes: notes,
        bankDetails: bankDetails,
        discount: discount,
        customerId: '',
      );
      await FirebaseFirestore.instance
          .collection('customers')
          .add(customerModel.toJson());
      addTransactionReport(
          amount: 0,
          type: 'customer',
          description: 'new customer',
          productName: name);
      update();
    } catch (e) {}
  }

  updateCustomerToFireStore(CustomerModel customerModel) async {
    await CustomerServices().updateCustomerIdInFirestore(customerModel);
    filterCustomers('');
    update();
  }

  deleteCustomerToFireStore(String customerId) async {
    await CustomerServices().deleteCustomerIdFromFirestore(customerId);

    update();
  }

// handle drop menu
  void handleClick(String value) {
    switch (value) {
      case 'Phone Call':
        {
          UrlLauncher.launch('tel:+${phone.toString()}');
        }
        break;
      case 'Send SMS':
        {
          // UrlLauncher.launch('mailto:$sms');
          _textMe();
        }
        break;
      case 'Send Email':
        {
          UrlLauncher.launch('mailto:$email');
        }
        break;
      case 'Whats Up':
        {
          _sendWhatsUp();
        }
        break;
    }
  }

  _textMe() async {
    // Android
    var uri = 'sms:+$phone?body=hello%20there';
    if (await canLaunch(uri)) {
      await launch(uri);
    } else {
      // iOS
      var uri = 'sms:$phone?body=hello%20there';
      if (await canLaunch(uri)) {
        await launch(uri);
      } else {
        throw 'Could not launch $uri';
      }
    }
  }

  _sendWhatsUp() {
    final Uri url = Uri(
      scheme: 'https',
      host: 'wa.me',
      path: '+$phone',
    );
    // UrlLauncher.launch(url);
    launchUrl(url);
  }

  ////////////////////////////////////////////
// handle export excel and print pdf
  void handleClicklistCustomers(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelListCustomers(listCustomers);
        }
        break;
      case 'Print To Pdf':
        {
          printListCustomers(listCustomers);
        }
        break;
    }
  }

  //////////////////////////////////////////
  void handleClickcustomerDetails(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelcustomerDetails(customerDetails);
        }
        break;
      case 'Print To Pdf':
        {
          printCustomerDetails(customerDetails);
        }
        break;
    }
  }
}
