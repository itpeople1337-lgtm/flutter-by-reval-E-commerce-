import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:flutter_cupertino_datetime_picker/flutter_cupertino_datetime_picker.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import 'package:stock_app/core/functions/export_excel.dart';
import 'package:stock_app/core/functions/prints.dart';
import 'package:stock_app/models/product_model.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/services/firestore_product.dart';
import 'package:stock_app/views/home/categories/products_categories.dart';
import 'package:stock_app/views/home/drawer/stores/stores.dart';

class ProductController extends GetxController {
  late String name,
      // storeName,
      details,
      sellingprice,
      purchaseprice,
      productId,
      quantity;

  Color selectedColor = Colors.white;

  File? imageFile;
  String picUrl = 'assets/images/profile_pic.png';
  var listproducts = <ProductModel>[].obs;
  var filteredProducts = <ProductModel>[].obs;
  ////////////////////////////////////
  var selectedDateTime = 'Selected Date:'.obs;
  var selectCategoryName = 'Select Category'.obs;
  var selectStoreName = 'Select Store'.obs;
  var getValuebarcode = ''.obs;
  RxInt selectedValue = 0.obs;
  void setSelectedValue(int value) {
    selectedValue.value = value;
  }

  ProductModel? productDetails;
  String? selectedStore;

  final _loading = false;
  get loading => _loading;
  DateTime? selectdate;
  late QRViewController controllerQRView;

  clearData() {
    selectCategoryName = 'Select Category'.obs;
    selectStoreName = 'Select Store'.obs;
    selectedDateTime = 'Selected Date:'.obs;
    selectedColor = Colors.white;
    getValuebarcode = ''.obs;
    imageFile = null;
  }

  dateTimePickerWidget(BuildContext context) {
    return DatePicker.showDatePicker(
      context,
      dateFormat: 'dd MMMM yyyy HH:mm',
      initialDateTime: DateTime.now(),
      minDateTime: DateTime(2000),
      maxDateTime: DateTime(3000),
      onMonthChangeStartWithFirstDate: true,
      onConfirm: (dateTime, List<int> index) {
        selectdate = dateTime;
        selectedDateTime.value =
            DateFormat('dd-MMM-yyyy - HH:mm').format(selectdate!);
        //  print("aaaaaaaaaaaaaaa" + selectedDateTime.value);
      },
    );
  }

  getProductsFromFireStore() async {
    // _loading(true);
    var products = await ProductService().getProductsFromFirestore();
    // lproducts.value = products;
    listproducts.assignAll(products);
    filterProducts("");
    update();
  }

  void filterProducts(String searchField) {
    if (searchField.isEmpty) {
      filteredProducts.assignAll(listproducts);
    } else {
      filteredProducts.assignAll(listproducts
          .where((product) =>
              product.name.toLowerCase().contains(searchField.toLowerCase()))
          .toList());
    }
    update();
  }

  addProductToFireStore() async {
    var strcolor = selectedColor.toString();
    // double amount = double.parse(purchaseprice) * double.parse(quantity);
    try {
      await uploadImageToFirebase();
      ProductModel productModel = ProductModel(
        name: name,
        storeName: selectStoreName.value,
        image: picUrl,
        details: details,
        date: selectedDateTime.value,
        quantity: quantity,
        barcode: getValuebarcode.value,
        sellingprice: sellingprice,
        purchaseprice: purchaseprice,
        productId: '',
        category: selectCategoryName.value,
        color: strcolor,
      );
      await FirebaseFirestore.instance
          .collection('products')
          .add(productModel.toJson());

      update();
    } catch (e) {}
  }

  updateProductToFireStore(ProductModel productModel) async {
    await ProductService().updateProductInFirestore(productModel);
    update();
  }

  deleteProductFromFireStore(String productId) async {
    await ProductService().deleteProductFromFirestore(productId);

    // update();
  }

  selectCategory() async {
    selectCategoryName.value =
        await Get.to(() => const ListProductsCategories()) ?? 'Select Category';
    update();
  }

  selectStore() async {
    selectStoreName.value =
        await Get.to(() => const ListStores()) ?? 'Select Store';
    update();
  }

  cameraImage() async {
    final pickedFile = await ImagePicker().pickImage(
      source: ImageSource.camera,
      maxHeight: 400,
      maxWidth: 400,
    );
    imageFile = File(pickedFile!.path);
    update();
  }

  uploadImageToFirebase() async {
    String fileName = basename(imageFile!.path);
    Reference firebaseStorageRef =
        FirebaseStorage.instance.ref().child('products/$fileName');
    UploadTask uploadTask = firebaseStorageRef.putFile(imageFile!);
    picUrl = await (await uploadTask).ref.getDownloadURL();
    update();
  }

  galleryImage() async {
    final pickedFile = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxHeight: 400,
      maxWidth: 400,
    );
    imageFile = File(pickedFile!.path);
    update();
  }

////////////// handel get Color  ///////////////

  pickColor() {
    Get.defaultDialog(
      title: 'Choose Color',
      content: Column(
        children: [
          ColorPicker(
            pickerColor: selectedColor,
            onColorChanged: (col) {
              selectedColor = col;
              // colorToString = col.toString();
              update();
            },
          ),
          TextButton(
            onPressed: () {
              Get.back();
            },
            child: const Text('SELECT'),
          ),
        ],
      ),
    );
    update();
  }

  /////////////// handel barcode /////////////////
  void onQRViewCreated(QRViewController controller) {
    controllerQRView = controller;
    controller.scannedDataStream.listen((scanData) {
      String scannedValue = scanData.code!;
      _getBarcodeValue(scannedValue);
      Get.offNamed(Routes.AddProduct);
      // Navigator.of(context).pop();
    });
  }

  void _getBarcodeValue(String scannedValue) {
    print('Scanned data: $scannedValue');
    getValuebarcode.value = scannedValue;
    update();
  }
//////////////////// handel pdf and excel /////////////////////

  void handleClickproductDetails(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelProductDetails(productDetails);
        }
        break;
      case 'Print To Pdf':
        {
          printProductDetails(productDetails);
        }
        break;
    }
  }

  void handleClicklistProducts(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelListProducts(listproducts);
        }
        break;
      case 'Print To Pdf':
        {
          printListProducts(listproducts);
        }
        break;
    }
  }
}
