import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stock_app/routes.dart';
import 'package:stock_app/services/local_services.dart';

import '../core/constants/app_images.dart';

abstract class OnBoardingController extends GetxController {
  next() {}
  onPageChange(int index) {}
}

class OnBoardingControllerImp extends OnBoardingController {
  late PageController pageController;
  int currentPage = 0;
  MyServices myServices = Get.find();
  @override
  void onInit() {
    super.onInit();
    pageController = PageController();
  }

  @override
  next() {
    currentPage++;
    if (currentPage > onBoardingList.length - 1) {
      myServices.sharedPreferences.setString('onboarding', '1');
      Get.offAllNamed(Routes.LOGIn);
    }
    pageController.animateToPage(
      currentPage,
      duration: const Duration(milliseconds: 900),
      curve: Curves.easeInOut,
    );
    update();
  }

  skip() {
    currentPage--;
    pageController.animateToPage(
      currentPage,
      duration: const Duration(milliseconds: 900),
      curve: Curves.easeInOut,
    );
    update();
  }

  @override
  onPageChange(int index) {
    currentPage = index;
    update();
  }
}

class OnBoarding {
  final String? title, image, body0; // body1;
  OnBoarding({
    required this.title,
    required this.image,
    required this.body0,
    // required this.body1,
  });
}

List<OnBoarding> onBoardingList = [
  OnBoarding(
    title: '1'.tr,
    image: ImagesAssets.onBoardingImage0,
    body0: '2'.tr,
    //body1: '4'.tr,
  ),
  OnBoarding(
    title: '3'.tr,
    image: ImagesAssets.onBoardingImage1,
    body0: '4'.tr,
    // body1: '4'.tr,
  ),
  OnBoarding(
    title: '5'.tr,
    image: ImagesAssets.onBoardingImage2,
    body0: '6'.tr,
    //body1: '7'.tr,
  ),
  OnBoarding(
    title: '7'.tr,
    image: ImagesAssets.onBoardingImage3,
    body0: '8'.tr,
    // body1: '10'.tr,
  ),
  OnBoarding(
    title: '9'.tr,
    image: ImagesAssets.onBoardingImage4,
    body0: '10'.tr,
    // body1: '10'.tr,
  ),
  OnBoarding(
    title: '11'.tr,
    image: ImagesAssets.onBoardingImage5,
    body0: '12'.tr,
    //body1: '10'.tr,
  ),
];
