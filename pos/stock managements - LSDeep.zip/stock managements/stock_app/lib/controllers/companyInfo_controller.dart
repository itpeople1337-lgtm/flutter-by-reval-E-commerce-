import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:stock_app/models/user_model.dart';
import 'package:path/path.dart';

class CompanyInfoController extends GetxController {
  // fake data for init
  @override
  void onInit() {
    getCompanyInfo();
    super.onInit();
  }

  CompanyInfoModel companyInfo = CompanyInfoModel(
    id: '',
    companyName: 'Co.  Mishra',
    companyAddress: 'Co.  Mishra - NewYourk',
    companyEmail: 'companyname@gmail.com',
    companySign: 'Co.  Mishra',
    image:
        'https://static.vecteezy.com/system/resources/thumbnails/008/214/517/small/abstract-geometric-logo-or-infinity-line-logo-for-your-company-free-vector.jpg',
  );
  var data;
  late String companyName, companyEmail, companySign, companyAddress;

  File? imageFile;
  String picUrl = 'assets/school-logo.png';
  final _loading = true.obs;
  get loading => _loading;
  var companyInfoModelList = <CompanyInfoModel>[].obs;

  getCompanyInfo() async {
    _loading(true);
    var com = await CompanyServices().getCompanyFromFirestore();
    companyInfoModelList.assignAll(com);
    if (companyInfoModelList.isEmpty) {
      data = companyInfo;
    } else {
      data = companyInfoModelList[0];
    }
    _loading(false);
    update();
  }

  addCompanyToFireStore() async {
    await uploadImageToFirebase();
    try {
      CompanyInfoModel comModel = CompanyInfoModel(
        companyName: companyName,
        companyAddress: companyAddress,
        companyEmail: companyEmail,
        image: picUrl,
        companySign: companySign,
      );
      await FirebaseFirestore.instance
          .collection('companyInfo')
          .add(comModel.toJson());
      update();
    } catch (e) {}
  }

  updateCompanyToFireStore(CompanyInfoModel companyInfoModel) async {
    await CompanyServices().updateCompanyInFirestore(companyInfoModel);
  }

  deleteCompanyfromFireStore(String id) async {
    if (companyInfoModelList.isEmpty) {
      Get.snackbar("73".tr, "225".tr);
    }
    await CompanyServices().deleteCompanyFromFirestore(id);
  }

  cameraImage() async {
    final pickedFile = await ImagePicker().pickImage(
      source: ImageSource.camera,
      maxHeight: 400,
      maxWidth: 400,
    );
    imageFile = File(pickedFile!.path);
    update();
  }

  galleryImage() async {
    final pickedFile = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      maxHeight: 400,
      maxWidth: 400,
    );
    imageFile = File(pickedFile!.path);
    update();
  }

  uploadImageToFirebase() async {
    String fileName = basename(imageFile!.path);
    Reference firebaseStorageRef =
        FirebaseStorage.instance.ref().child('company/$fileName');
    UploadTask uploadTask = firebaseStorageRef.putFile(imageFile!);
    picUrl = await (await uploadTask).ref.getDownloadURL();
    update();
  }
}

class CompanyServices {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<CompanyInfoModel>> getCompanyFromFirestore() async {
    var snapshot = await _firestore.collection('companyInfo').get();
    return snapshot.docs.map((doc) => CompanyInfoModel.fromJson(doc)).toList();
  }

  Future<void> updateCompanyInFirestore(
      CompanyInfoModel companyInfoModel) async {
    try {
      await _firestore
          .collection('companyInfo')
          .doc(companyInfoModel.id)
          .update(companyInfoModel.toJson());
    } catch (e) {
      print('Error updating companyInfo: $e');
    }
  }

  Future<void> deleteCompanyFromFirestore(String id) async {
    try {
      await _firestore.collection('companyInfo').doc(id).delete();
    } catch (e) {
      print('Error deleting companyInfo: $e');
    }
  }
}
