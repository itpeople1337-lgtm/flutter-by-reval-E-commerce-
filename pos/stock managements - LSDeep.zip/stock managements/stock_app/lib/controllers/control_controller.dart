import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:stock_app/core/constants/app_colors.dart';
import 'package:stock_app/views/home/home_screen/home.dart';
import 'package:stock_app/views/profile/profile.dart';
import 'package:stock_app/views/charts/sales.dart';

class ControlController extends GetxController {
  Widget _currentScreen = const HomeScreen();
  int _navigatorIndex = 1;

  Widget get currentScreen => _currentScreen;

  int get navigatorIndex => _navigatorIndex;
  SharedPreferences? prefs;
  Color bg = Colors.white;
  changeCurrentScreen(int index) {
    _navigatorIndex = index;
    switch (index) {
      case 0:
        _currentScreen = Chart();
        bg = Colors.white;
        break;

      case 1:
        _currentScreen = const HomeScreen();
        bg = Colors.white;
        break;
      case 2:
        _currentScreen = const ProfileView();
        bg = baseColor;
        break;
    }
    update();
  }
}
