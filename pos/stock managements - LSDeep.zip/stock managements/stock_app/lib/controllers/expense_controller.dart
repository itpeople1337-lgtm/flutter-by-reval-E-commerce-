import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_cupertino_datetime_picker/flutter_cupertino_datetime_picker.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:stock_app/core/functions/export_excel.dart';
import 'package:stock_app/core/functions/prints.dart';
import 'package:stock_app/core/functions/reports/add_report.dart';
import 'package:stock_app/models/expense_model.dart';
import 'package:stock_app/models/report_model.dart';
import 'package:stock_app/services/firestore_expense.dart';

class ExpenseController extends GetxController {
  DateTime selectedDate = DateTime.now();
  var slectedExpenseType = 'select Type Expenses'.obs;
  var selectedDateTime = 'Pick Date'.obs;

  late String name, expenseId, amount, store;
  var listExpenses = <ExpenseModel>[].obs;
  var filteredExpenses = <ExpenseModel>[].obs;
  final _loading = true.obs;
  get loading => _loading;
  var listExpensesMonth = <Sales>[].obs;
  ExpenseModel? expenseDetails;
  DateTime? selectdate;

  getExpensesFromFireStore() async {
    _loading(true);
    var expenses = await ExpenseServices().getExpensesIdFromFirestore();
    listExpenses.assignAll(expenses);
    _loading(false);
    filterExpenses('');
    calculateExpensesByMonth();
    update();
  }

  void filterExpenses(String searchField) {
    if (searchField.isEmpty) {
      filteredExpenses.assignAll(listExpenses);
    } else {
      filteredExpenses.assignAll(listExpenses
          .where((exc) =>
              exc.name.toLowerCase().contains(searchField.toLowerCase()))
          .toList());
    }
    update();
  }

  addExpenseToFireStore() async {
    try {
      ExpenseModel expenseModel = ExpenseModel(
        name: name,
        amount: amount,
        date: selectdate!, //selectedDateTime.value,
        category: slectedExpenseType.value,
        store: store,
        expenseId: '',
      );
      await FirebaseFirestore.instance
          .collection('expenses')
          .add(expenseModel.toJson());
      addReportExpense(expenseModel);
      addTransactionReport(
          amount: double.parse(amount),
          type: 'Expenses',
          description: 'New Expenses',
          productName: '');
      update();
    } catch (e) {}
  }

  updateExpensesToFireStore(ExpenseModel expenseModel) async {
    await ExpenseServices().updateExpenseIdInFirestore(expenseModel);
  }

  deleteExpenseFromFireStore(String expenseId) async {
    await ExpenseServices().deleteExpenseIdFromFirestore(expenseId);
  }

  dateTimePickerWidget(BuildContext context) {
    return DatePicker.showDatePicker(
      context,
      dateFormat: 'dd MMMM yyyy HH:mm',
      initialDateTime: DateTime.now(),
      minDateTime: DateTime(2000),
      maxDateTime: DateTime(3000),
      onMonthChangeStartWithFirstDate: true,
      onConfirm: (dateTime, List<int> index) {
        selectdate = dateTime;
        selectedDateTime.value =
            DateFormat('dd-MMM-yyyy - HH:mm').format(selectdate!);
        //  print("aaaaaaaaaaaaaaa" + selectedDateTime.value);
      },
    );
  }

////////////////////////////////////////////////
  void handleClickExpenseDetails(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelexpenseDetails(expenseDetails);
        }
        break;
      case 'Print To Pdf':
        {
          printExpenseDetails(expenseDetails);
        }
        break;
    }
  }

  void handleClickListExpenses(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelListExpenses(listExpenses);
        }
        break;
      case 'Print To Pdf':
        {
          printListExpenses(listExpenses);
        }
        break;
    }
  }

// calculate expense monthly

  calculateExpensesByMonth() {
    Map<String, double> salesByMonth = {};
    for (var product in listExpenses) {
      double totalPrice = double.parse(product.amount);
      String month = '${product.date.month}-${product.date.year}';

      salesByMonth.update(
        month,
        (value) => value + totalPrice,
        ifAbsent: () => totalPrice,
      );
    }
    listExpensesMonth.clear();
    listExpensesMonth.value = salesByMonth.entries
        .map((entry) => Sales(type: entry.key, totalSales: entry.value))
        .toList();
    for (var month in listExpensesMonth) {
      print('شهر النفقات: ${month.type} - Total Sales: ${month.totalSales}');
    }
    update();
  }
}
