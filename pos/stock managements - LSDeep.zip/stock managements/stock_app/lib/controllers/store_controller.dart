import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:stock_app/models/store_model.dart';
import 'package:stock_app/services/firestore_store.dart';

class StoreController extends GetxController {
  ///////////////////////////
  late String name;

  var listStores = <StoreModel>[].obs;
  final _loading = true.obs;
  get loading => _loading;

  getStoresFromFireStore() async {
    _loading(true);
    var stores = await StoreServices().getStoreIdFromFirestore();
    listStores.assignAll(stores);

    _loading(false);
    update();
  }

  addStoreToFireStore() async {
    try {
      StoreModel customerModel = StoreModel(
        storeId: '',
        name: name,
      );
      await FirebaseFirestore.instance
          .collection('stores')
          .add(customerModel.toJson());
      update();
    } catch (e) {}
  }

  updateStoreToFireStore(StoreModel storeModel) async {
    await StoreServices().updateStoreIdInFirestore(storeModel);
  }

  deleteStoreToFireStore(String storeId) async {
    await StoreServices().deleteStoreIdFromFirestore(storeId);
  }
}
