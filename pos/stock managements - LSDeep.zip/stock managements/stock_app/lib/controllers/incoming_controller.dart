import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_cupertino_datetime_picker/flutter_cupertino_datetime_picker.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import 'package:stock_app/core/functions/export_excel.dart';
import 'package:stock_app/core/functions/prints.dart';
import 'package:stock_app/core/functions/reports/add_report.dart';
import 'package:stock_app/models/in_out_model.dart';
import 'package:stock_app/models/product_model.dart';
import 'package:stock_app/models/report_model.dart';
import 'package:stock_app/services/firestore_incoming.dart';
import 'package:stock_app/services/local_services.dart';
import 'package:stock_app/views/home/products/list_products.dart';
import 'package:stock_app/views/home/suppliers/suppliers.dart';

class IncomingController extends GetxController {
  late String docNo, image, goods, docId, details;
  // var Get.find<MyServices>().listIncomingProducts = <InOutModel>[].obs;
  var filterIncomingProducts = <InOutModel>[].obs;
  var selectedDateTime = 'Pick Date'.obs;
  var selectClientName = 'Pick Client'.obs;

  var details2 = 'Details: '.obs;
  var docType = ''.obs;
  final _loading = true.obs;
  get loading => _loading;
  String? title;
  RxInt selectedValue = 0.obs;
  void setSelectedValue(int value) {
    selectedValue.value = value;
  }

  var lproducts = <ProductModel>[].obs;
  final MyServices productService = Get.put(MyServices());
  ProductModel? getSelectProduct;
  InOutModel? incomingDetails;

  DateTime? selectdatee;

  var enteredValue = ''.obs;
  var totalpPrice = 0.0.obs; //Revenue
  var sumQuantity = 0.0.obs; //
  String? type, desc;
  var purchaseListMonth = <Sales>[].obs;

  getProduct() async {
    getSelectProduct = await Get.to(() => const ListProducts('get'));
    lproducts.add(getSelectProduct!);
    openDialog();
    update();
  }

  quantandPrice(ProductModel productModel) {
    details2.value += '  ${productModel.name}:${enteredValue.value}';
    sumQuantity.value += int.parse(enteredValue.value);

    totalpPrice.value +=
        int.parse(productModel.purchaseprice) * int.parse(enteredValue.value);
    enteredValue.value = '';
    update();
  }

  addClientName() async {
    selectClientName.value = await Get.to(() => const ListSuppliers('get'));
    docType.value = 'Incoming';
    type = 'Incoming';
    desc = 'New Incoming Goods';

    update();
  }

  clearData() {
    details2.value = 'Details: ';
    totalpPrice.value = 0;
    sumQuantity.value = 0;
    lproducts.clear();
    selectedDateTime.value = 'Pick Date';
    selectClientName.value = 'Pick Client';
    update();
  }

  openDialog() async {
    await Get.defaultDialog(
      title: 'Enter  Quantity',
      content: TextField(
        onChanged: (value) {
          enteredValue.value = value;
          update();
        },
        keyboardType: TextInputType.number,
        // controller: _textFieldController,
        decoration: const InputDecoration(hintText: 'Enter Quantity'),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Get.back();
          },
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () {
            // enteredValue.value = _textFieldController.text;
            Get.back(result: enteredValue);
            quantandPrice(getSelectProduct!);
          },
          child: const Text('OK'),
        ),
      ],
    );

    update();
  }

  dateTimePickerWidget(BuildContext context) {
    return DatePicker.showDatePicker(
      context,
      dateFormat: 'dd MMMM yyyy HH:mm',
      initialDateTime: DateTime.now(),
      minDateTime: DateTime(2000),
      maxDateTime: DateTime(3000),
      onMonthChangeStartWithFirstDate: true,
      onConfirm: (dateTime, List<int> index) {
        selectdatee = dateTime;
        selectedDateTime.value =
            DateFormat('dd-MMM-yyyy - HH:mm').format(selectdatee!);
        //  print("aaaaaaaaaaaaaaa" + selectedDateTime.value);
      },
    );
  }

  var listIncomingProducts = <InOutModel>[].obs;
  getIncomingFromFireStore() async {
    //  await productService.loadProducts();

    // _loading(true);
    var incomingProducts =
        await IncomingServices().getIncomingProductsFromFirestore();
    listIncomingProducts.assignAll(incomingProducts);
    // _loading(false);
    filterIncoming('');
    calculatePurchaseByMonth();
    update();
  }

  void filterIncoming(String searchField) {
    if (searchField.isEmpty) {
      filterIncomingProducts.assignAll(listIncomingProducts);
    } else {
      filterIncomingProducts.assignAll(listIncomingProducts
          .where((ing) =>
              ing.clientName.toLowerCase().contains(searchField.toLowerCase()))
          .toList());
    }
    // calculatePurchaseByMonth();
    update();
  }

  addIncomingToFireStore() async {
    try {
      InOutModel inOutModel = InOutModel(
        clientName: selectClientName.value,
        details: details2.value, //details,
        date: selectdatee!,
        docNo: docNo,
        quantity: sumQuantity.value, //details2.value,
        price: totalpPrice.value, // totalPrice.value.toString(),
        docType: docType.value,
        docId: '',
      );
      await FirebaseFirestore.instance
          .collection('incoming')
          .add(inOutModel.toJson());
      addTransactionReport(
        amount: totalpPrice.value.toDouble(),
        type: type!,
        description: desc!,
        productName: details2.value,
      );

      update();
    } catch (e) {}
  }

  updateIncomingInFireStore(InOutModel inOutModel) async {
    await IncomingServices().updateIncomingInFirestore(inOutModel);
  }

  deleteIncomingFromFireStore(String docId) async {
    await IncomingServices().deleteIncomingFromFirestore(docId);
  }

  /////////////////////////////////////////////////

  void handleClicklistIncoming(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelListIncoming(listIncomingProducts);
        }
        break;
      case 'Print To Pdf':
        {
          printListIncoming(listIncomingProducts);
        }
        break;
    }
  }

  void handleClickincomingDetails(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelincomingDetails(incomingDetails);
        }
        break;
      case 'Print To Pdf':
        {
          printIncomingDetails(incomingDetails);
        }
        break;
    }
  }

// calculate Purchase monthly
  calculatePurchaseByMonth() {
    Map<String, double> salesByMonth = {};
    for (var product in listIncomingProducts) {
      double totalPrice = product.price; //product.quantity *
      String month = '${product.date.month}-${product.date.year}';

      salesByMonth.update(
        month,
        (value) => value + totalPrice,
        ifAbsent: () => totalPrice,
      );
    }
    purchaseListMonth.clear();
    purchaseListMonth.value = salesByMonth.entries
        .map((entry) => Sales(type: entry.key, totalSales: entry.value))
        .toList();

    for (var month in purchaseListMonth) {
      print('شهر المشتريات: ${month.type} - Total Sales: ${month.totalSales}');
    }
    // combineLists();
    update();
  }
}
