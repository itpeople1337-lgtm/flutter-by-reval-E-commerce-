import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_cupertino_datetime_picker/flutter_cupertino_datetime_picker.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:stock_app/core/functions/export_excel.dart';
import 'package:stock_app/core/functions/prints.dart';
import 'package:stock_app/core/functions/reports/add_report.dart';
import 'package:stock_app/models/in_out_model.dart';
import 'package:stock_app/models/product_model.dart';
import 'package:stock_app/models/report_model.dart';
import 'package:stock_app/services/firestore_outgoing.dart';
import 'package:stock_app/views/home/customers/customers.dart';
import 'package:stock_app/views/home/products/list_products.dart';

class OutgoingController extends GetxController {
  late String docNo, image, goods, docId, details;
  var filterIncomingProducts = <InOutModel>[].obs;
  var filterOutgoingProducts = <InOutModel>[].obs;
  var selectedDateTime = 'Pick Date'.obs;
  var selectClientName = 'Pick Client'.obs;
  var details2 = 'Details: '.obs;
  var docType = ''.obs;
  final _loading = true.obs;
  get loading => _loading;
  String? title;
  RxInt selectedValue = 0.obs;
  void setSelectedValue(int value) {
    selectedValue.value = value;
  }

  var lproducts = <ProductModel>[].obs;
  var listOutgoingProducts = <InOutModel>[].obs;
  ProductModel? getSelectProduct;
  InOutModel? incomingDetails;
  InOutModel? outgoingDetails;

  DateTime? selectdatee;
  // final MyServices productService = Get.put(MyServices());
  var enteredValue = ''.obs;
  var totalpPrice = 0.0.obs; //Revenue
  var sumQuantity = 0.0.obs;
  String? type, desc;

  getProduct() async {
    getSelectProduct = await Get.to(() => const ListProducts('get'));
    lproducts.add(getSelectProduct!);
    openDialog();
    update();
  }

  quantandPrice(ProductModel productModel) {
    details2.value += '${productModel.name}:Qt${enteredValue.value}';
    sumQuantity.value += int.parse(enteredValue.value);

    totalpPrice.value +=
        int.parse(productModel.sellingprice) * int.parse(enteredValue.value);
    enteredValue.value = '';
    update();
  }

  addClientName() async {
    selectClientName.value = await Get.to(() => const ListCustomers('get'));
    docType.value = 'Outgoing';
    type = 'Outgoing';
    desc = 'New Outgoing Goods';
    update();
  }

  handleExitPage() {}

  clearData() {
    details2.value = 'Details: ';
    totalpPrice.value = 0;
    sumQuantity.value = 0;
    lproducts.clear();
    selectedDateTime.value = 'Pick Date';
    selectClientName.value = 'Pick Client';
    update();
  }

  openDialog() async {
    await Get.defaultDialog(
      title: 'Enter  Quantity',
      content: TextField(
        onChanged: (value) {
          enteredValue.value = value;
          update();
        },
        keyboardType: TextInputType.number,
        decoration: const InputDecoration(hintText: 'Enter Quantity'),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Get.back();
          },
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () {
            Get.back(result: enteredValue);
            quantandPrice(getSelectProduct!);
          },
          child: const Text('OK'),
        ),
      ],
    );

    update();
  }

  dateTimePickerWidget(BuildContext context) {
    return DatePicker.showDatePicker(
      context,
      dateFormat: 'dd MMMM yyyy HH:mm',
      initialDateTime: DateTime.now(),
      minDateTime: DateTime(2000),
      maxDateTime: DateTime(3000),
      onMonthChangeStartWithFirstDate: true,
      onConfirm: (dateTime, List<int> index) {
        selectdatee = dateTime;
        selectedDateTime.value =
            DateFormat('dd-MMM-yyyy - HH:mm').format(selectdatee!);
      },
    );
  }

  getOutgoingFromFireStore() async {
    var incomingProducts =
        await OutgoingServices().getOutgoingProductsFromFirestore();
    listOutgoingProducts.assignAll(incomingProducts);

    filterOutgoing('');
    calculateTotalByClients();
    calculateSalesByMonth();
    update();
  }

  addOutgoingToFireStore() async {
    try {
      InOutModel inOutModel = InOutModel(
        clientName: selectClientName.value,
        details: details2.value, //details,
        date: selectdatee!,
        docNo: docNo,
        quantity: sumQuantity.value,
        price: totalpPrice.value,
        docType: docType.value,
        docId: '',
      );
      await FirebaseFirestore.instance
          .collection('outgoing')
          .add(inOutModel.toJson());
      addTransactionReport(
        amount: totalpPrice.value.toDouble(),
        type: type!,
        description: desc!,
        productName: details2.value,
      );

      update();
    } catch (e) {}
  }

  updateOutgoingInFireStore(InOutModel inOutModel) async {
    await OutgoingServices().updateOutgoingInFirestore(inOutModel);
  }

  deleteOutgoingFromFireStore(String docId) async {
    await OutgoingServices().deleteOutgoingFromFirestore(docId);
  }

  void filterOutgoing(String searchField) {
    if (searchField.isEmpty) {
      filterOutgoingProducts.assignAll(listOutgoingProducts);
    } else {
      filterOutgoingProducts.assignAll(listOutgoingProducts
          .where((out) =>
              out.clientName.toLowerCase().contains(searchField.toLowerCase()))
          .toList());
    }
    update();
  }

  void handleClicklistOutgoing(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelListOutgoing(listOutgoingProducts);
        }
        break;
      case 'Print To Pdf':
        {
          printListOutgoing(listOutgoingProducts);
        }
        break;
    }
  }

  void handleClickoutgoingDetails(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExceloutgoingDetails(outgoingDetails);
        }
        break;
      case 'Print To Pdf':
        {
          printOutgoingDetails(outgoingDetails);
        }
        break;
    }
  }

  ///////////////////////////////////////////
  var top3List = <Sales>[].obs;
  var salesListMonth = <Sales>[].obs;
  var salesListDay = <Sales>[].obs;
  var listOfIDs = <String>[].obs;
  var salesClientsList = <Sales>[].obs;
  var salesItemsList = <Sales>[].obs;
  var bestSalesList = <Sales>[].obs;

  calculateTotalByClients() {
    Map<String, double> clientsTotal = {};
    for (var product in listOutgoingProducts) {
      double totalPrice = product.price;

      clientsTotal.update(
        product.clientName,
        (value) => value + totalPrice,
        ifAbsent: () => totalPrice,
      );
    }
    salesClientsList.value = clientsTotal.entries
        .map((entry) => Sales(type: entry.key, totalSales: entry.value))
        .toList();
    listOfIDs.value.clear();
    listOfIDs.value = List.generate(salesClientsList.length,
        (index) => (index + 1).toString().padLeft(3, '0'));
    listOfIDs.insert(0, 'Customer ID');
    for (var clientSales in salesClientsList) {
      print(
          'Customer: ${clientSales.type} - Total Sales: ${clientSales.totalSales}');
    }
    calculateSalesByItem();
    update();
  }

  calculateSalesByItem() {
    Map<String, double> salesByItem = {};

    for (var product in listOutgoingProducts) {
      double totalPrice = product.price;
      salesByItem.update(
        product.details,
        (value) => value + totalPrice,
        ifAbsent: () => totalPrice,
      );
    }

    salesItemsList.value = salesByItem.entries
        .map((entry) => Sales(type: entry.key, totalSales: entry.value))
        .toList();
    for (var quntity in salesItemsList) {
      print('quntity: ${quntity.type} - Total Sales: ${quntity.totalSales}');
    }
    calculateTop3();
    update();
  }

  updateIDs(String id) {
    listOfIDs.value.clear();
    listOfIDs.value = List.generate(salesItemsList.length,
        (index) => (index + 1).toString().padLeft(3, '0'));
    listOfIDs.insert(0, id);
    update();
  }

  calculateTop3() {
    salesClientsList.sort((a, b) => b.totalSales.compareTo(a.totalSales));
    var top3Clients = salesClientsList.take(3).toList();

    salesItemsList.sort((a, b) => b.totalSales.compareTo(a.totalSales));
    var top3Items = salesItemsList.take(3).toList();

    var combinedList = [...top3Clients, ...top3Items];
    // // Remove duplicates based on type
    combinedList = combinedList.toSet().toList();
    bestSalesList.value = combinedList
        .map((sales) => Sales(
              type: sales.type,
              totalSales: sales.totalSales,
            ))
        .toList();

    bestSalesList.assignAll(combinedList);
    bestSalesList.value = bestSalesList.toSet().toList();
    for (var sales in bestSalesList) {
      print('Type: ${sales.type} - Total Sales: ${sales.totalSales}');
    }
    print('length length  ${bestSalesList.length}');
    update();
  }

  calculateSalesByMonth() {
    Map<String, double> salesByMonth = {};
    for (var product in listOutgoingProducts) {
      double totalPrice = product.price; //product.quantity *
      String month = '${product.date.month}-${product.date.year}';

      salesByMonth.update(
        month,
        (value) => value + totalPrice,
        ifAbsent: () => totalPrice,
      );
    }
    salesListMonth.value = salesByMonth.entries
        .map((entry) => Sales(type: entry.key, totalSales: entry.value))
        .toList();
    listOfIDs.value.clear();
    listOfIDs.value = List.generate(salesListMonth.length,
        (index) => (index + 1).toString().padLeft(3, '0'));
    listOfIDs.insert(0, 'ID');
    //  update();
    for (var month in salesListMonth) {
      print('شهر المبيعات: ${month.type} - Total Sales: ${month.totalSales}');
    }
    update();
  }

  calculateSalesByDay() {
    Map<String, double> salesByDay = {};

    for (var product in listOutgoingProducts) {
      double totalPrice = product.price; //product.quantity *
      String day =
          '${product.date.day}-${product.date.month}-${product.date.year}';
      salesByDay.update(
        day,
        (value) => value + totalPrice,
        ifAbsent: () => totalPrice,
      );
    }
    salesListDay.value = salesByDay.entries
        .map((entry) => Sales(type: entry.key, totalSales: entry.value))
        .toList();
    listOfIDs.value.clear();
    listOfIDs.value = List.generate(
        salesListDay.length, (index) => (index + 1).toString().padLeft(3, '0'));
    listOfIDs.insert(0, 'ID');

    for (var day in salesListDay) {
      //  print('day: ${day.type} - Total Sales: ${day.totalSales}');
    }
    update();
  }
}
