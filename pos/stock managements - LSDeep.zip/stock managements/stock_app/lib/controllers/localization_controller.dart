import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:stock_app/core/constants/app_theme.dart';
import 'package:stock_app/services/local_services.dart';

class LocalController extends GetxController {
  Locale? language;
  var switchValueen = true.obs;
  var switchValuear = false.obs;
  var switchValuFr = false.obs;
  var switchValueSp = false.obs;
  var switchValuePt = false.obs;
  MyServices myServices = Get.find();

  ThemeData appTheme = themeEnglish;

  changeLange(String langCode) {
    if (langCode == 'en') {
      switchValueen.value = true;
      switchValuear.value = false;
      switchValuFr.value = false;
      switchValueSp.value = false;
      switchValuePt.value = false;
      update();
    } else if (langCode == 'ar') {
      switchValueen.value = false;
      switchValuear.value = true;
      switchValuFr.value = false;
      switchValueSp.value = false;
      switchValuePt.value = false;
      update();
    } else if (langCode == 'fr') {
      switchValueen.value = false;
      switchValuear.value = false;
      switchValuFr.value = true;
      switchValueSp.value = false;
      switchValuePt.value = false;
      update();
    } else if (langCode == 'es') {
      switchValueen.value = false;
      switchValuear.value = false;
      switchValuFr.value = false;
      switchValueSp.value = true;
      switchValuePt.value = false;
      update();
    } else if (langCode == 'pt') {
      switchValueen.value = false;
      switchValuear.value = false;
      switchValuFr.value = false;
      switchValueSp.value = false;
      switchValuePt.value = true;
      update();
    }

    Locale locale = Locale(langCode);
    myServices.sharedPreferences.setString('lang', langCode);
    //  appTheme = langCode == 'en' ? themeEnglish : themeArabic;
    // Get.changeTheme(appTheme);
    // update();
    Get.updateLocale(locale);
  }

  @override
  void onInit() {
    String? sharedPreLang = myServices.sharedPreferences.getString('lang');
    if (sharedPreLang == 'ar') {
      language = const Locale('ar');
      appTheme == themeArabic;
    } else if (sharedPreLang == 'en') {
      language = const Locale('en');
      appTheme = themeEnglish;
    } else if (sharedPreLang == 'fr') {
      language = const Locale('fr');
      appTheme = themeEnglish;
    } else if (sharedPreLang == 'es') {
      language = const Locale('es');
      appTheme = themeEnglish;
    } else if (sharedPreLang == 'pt') {
      language = const Locale('pt');
      appTheme = themeEnglish;
    } else {
      language = Locale(Get.deviceLocale!.languageCode);
      appTheme = themeEnglish;
    }
    super.onInit();
  }
}
