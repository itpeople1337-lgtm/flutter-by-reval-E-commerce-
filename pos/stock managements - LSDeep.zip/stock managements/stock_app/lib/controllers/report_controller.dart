import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:stock_app/controllers/expense_controller.dart';
import 'package:stock_app/controllers/incoming_controller.dart';
import 'package:stock_app/controllers/outgoing_controller.dart';
import 'package:stock_app/core/functions/reports/export_excel.dart';
import 'package:stock_app/core/functions/reports/export_pdf.dart';
import 'package:stock_app/models/report_model.dart';
import 'package:stock_app/services/firestore_report.dart';

class ReportsController extends GetxController {
  @override
  void onInit() {
    calculateProfitLossMonth();
    super.onInit();
  }

  var expensesList = <ExpensesReportModel>[].obs;
  var transactionsList = <TransactionsModel>[].obs;
  var stockMovementList = <TransactionsModel>[].obs;
  var purchasesSupplierList = <PurchasesSupplierModel>[].obs;
  var debtsCustomerList = <DebtsCustomerModel>[].obs;
  var debtsSupplierList = <DebtsSupplierModel>[].obs;
  var recorderReportList = <RecorderReportModel>[].obs;
  ///////////////////////////////////////////////////
  var list = <String>[].obs;
  var listTransDate = <String>[].obs;
  var monthsInYear = <String>[].obs;
  var lastAssignedId = 0.obs;
  var selectedDate = DateTime.now().obs;

////////////////// Adding Methods /////////////////
  Future<void> addExpense(String reportId, ExpensesReportModel expense) async {
    await FireStoreReport().getExpensesCollection(reportId).add({
      'id': expense.id,
      'expenseType': expense.expenseType,
      'amount': expense.amount,
      'date': expense.date,
    });

    update();
  }

  Future<void> addTransactionsToFireStore(
      String reportId, TransactionsModel transactionsModel) async {
    lastAssignedId.value++;
    String formattedId = lastAssignedId.value.toString().padLeft(3, '0');

    await FireStoreReport().getTransactionsCollection(reportId).add({
      'id': formattedId, //transactionsModel.id,
      'amount': transactionsModel.amount,
      'type': transactionsModel.type,
      'productName': transactionsModel.productName,
      'date': transactionsModel.date,
      'description': transactionsModel.description,
    });

    update();
  }

  Future<void> addpurchasesSupplierToFireStore(
      String reportId, PurchasesSupplierModel purchasesSupplier) async {
    await FireStoreReport().getPurchasesSupplierCollection(reportId).add({
      'id': purchasesSupplier.id,
      'name': purchasesSupplier.name,
      'totalPurchases': purchasesSupplier.totalPurchases,
    });

    update();
  }

  Future<void> addDebtsCustomerToFireStore(
      String reportId, DebtsCustomerModel debtsCustomerModel) async {
    lastAssignedId.value++;
    String formattedId = lastAssignedId.value.toString().padLeft(3, '0');

    await FireStoreReport().getDebtsCustomerCollection(reportId).add({
      'id': formattedId, //debtsCustomerModel.id,
      'customerID': debtsCustomerModel.customerID,
      'customerName': debtsCustomerModel.customerName,
      'totalDebts': debtsCustomerModel.totalDebts,
    });

    update();
  }

  Future<void> addDebtsSupplierToFireStore(
      String reportId, DebtsSupplierModel debtsSupplierModel) async {
    lastAssignedId.value++;
    String formattedId = lastAssignedId.value.toString().padLeft(3, '0');
    await FireStoreReport().getDebtsSupplierCollection(reportId).add({
      'id': formattedId, //debtsSupplierModel.id,
      'supplierID': debtsSupplierModel.supplierID,
      'supplierName': debtsSupplierModel.supplierName,
      'totalDebts': debtsSupplierModel.totalDebts,
    });

    update();
  }

  Future<void> addRecorderReportToFireStore(
      String reportId, RecorderReportModel recorderReportModel) async {
    await FireStoreReport().getRecorderReportsCollection(reportId).add({
      'id': recorderReportModel.id,
      'action': recorderReportModel.action,
      'description': recorderReportModel.description,
      'date': recorderReportModel.date,
    });

    update();
  }

////////////////////////////// get Methods ///////////////////////////////

  Future<void> getExpenses(String reportId) async {
    var querySnapshot =
        await FireStoreReport().getExpensesCollection(reportId).get();
    expensesList.assignAll(
      querySnapshot.docs.map(
        (doc) => ExpensesReportModel(
          id: doc['id'],
          expenseType: doc['expenseType'],
          amount: doc['amount'],
          date: (doc['date'] as Timestamp).toDate(),
        ),
      ),
    );
    list.clear();
    list.value = expensesList.map((excp) => excp.date.toString()).toList();
    list.insert(0, 'Date');
    update();
  }

  Future<void> getTransactions(String id) async {
    var querySnapshot = await FireStoreReport()
        .getTransactionsCollection(id)
        .orderBy('date')
        .get();
    transactionsList.assignAll(
      querySnapshot.docs.map(
        (doc) => TransactionsModel(
          id: doc['id'],
          amount: doc['amount'],
          type: doc['type'],
          productName: doc['productName'],
          description: doc['description'],
          date: (doc['date'] as Timestamp).toDate(),
        ),
      ),
    );
    lastAssignedId.value = transactionsList
        .map((transaction) => int.tryParse(transaction.id) ?? 0)
        .fold(0, (max, current) => max > current ? max : current);
    listTransDate.value =
        transactionsList.map((excp) => excp.date.toString()).toList();
    listTransDate.insert(0, 'Date');
    update();
    getStockMovement();
  }

  var listOfIDs = <String>[].obs;
  Future<void> getStockMovement() async {
    print(
        'Before filtering: filteredProducts length: ${stockMovementList.length}');
    stockMovementList.assignAll(transactionsList
        .where((product) =>
            product.type.contains('Outgoing') ||
            product.type.contains('Incoming'))
        .toList());
    print(
        'After filtering: filteredProducts length: ${stockMovementList.length}');

    update();
  }

  updateIDs(String id) {
    listOfIDs.value.clear();
    listOfIDs.value = List.generate(
        stockMovementList.length, //'Movement ID'
        (index) => (index + 1).toString().padLeft(3, '0'));
    listOfIDs.insert(0, id);
    update();
  }

  Future<void> getPurchasesSupplier(String reportId) async {
    var querySnapshot =
        await FireStoreReport().getPurchasesSupplierCollection(reportId).get();
    purchasesSupplierList.assignAll(
      querySnapshot.docs.map(
        (doc) => PurchasesSupplierModel(
          id: doc['id'],
          name: doc['name'],
          totalPurchases: doc['totalPurchases'],
        ),
      ),
    );
    list.clear();
    list.value = purchasesSupplierList.map((value) => value.id).toList();
    list.insert(0, 'Supplier ID');
    update();
  }

  Future<void> getDebtsCustomer(String reportId) async {
    var querySnapshot = await FireStoreReport()
        .getDebtsCustomerCollection(reportId)
        .orderBy('id')
        .get();
    debtsCustomerList.assignAll(
      querySnapshot.docs.map(
        (doc) => DebtsCustomerModel(
          id: doc['id'],
          customerID: doc['customerID'],
          customerName: doc['customerName'],
          totalDebts: doc['totalDebts'],
        ),
      ),
    );
    lastAssignedId.value = debtsCustomerList
        .map((debts) => int.tryParse(debts.id) ?? 0)
        .fold(0, (max, current) => max > current ? max : current);
    list.clear();
    list.value = debtsCustomerList.map((value) => value.id.toString()).toList();
    list.insert(0, 'Customer ID');
    update();
  }

  Future<void> getDebtsSupplier(String reportId) async {
    var querySnapshot = await FireStoreReport()
        .getDebtsSupplierCollection(reportId)
        .orderBy('id')
        .get();
    debtsSupplierList.assignAll(
      querySnapshot.docs.map(
        (doc) => DebtsSupplierModel(
          id: doc['id'],
          supplierID: doc['supplierID'],
          supplierName: doc['supplierName'],
          totalDebts: doc['totalDebts'],
        ),
      ),
    );
    lastAssignedId.value = debtsSupplierList
        .map((debts) => int.tryParse(debts.id) ?? 0)
        .fold(0, (max, current) => max > current ? max : current);
    list.clear();
    list.value = debtsSupplierList.map((value) => value.id.toString()).toList();
    list.insert(0, 'Supplier ID');

    update();
  }

  Future<void> getRecorderReports(String reportId) async {
    var querySnapshot =
        await FireStoreReport().getRecorderReportsCollection(reportId).get();
    recorderReportList.assignAll(
      querySnapshot.docs.map(
        (doc) => RecorderReportModel(
          id: doc['id'],
          action: doc['action'],
          description: doc['description'],
          date: (doc['date'] as Timestamp).toDate(),
        ),
      ),
    );
    list.clear();
    list.value =
        recorderReportList.map((value) => value.date.toString()).toList();
    list.insert(0, 'Date');
    update();
  }

  ///////////////////////////////////////
  var listDatesMonth = <String>[].obs;

  final controllerOut = Get.put(OutgoingController());
  final controllerIn = Get.put(IncomingController());
  final controllerexp = Get.put(ExpenseController());

  var purchaseListMonth = <Sales>[].obs;
  var expensesListMonth = <Sales>[].obs;
  var salesListMonth = <Sales>[].obs;
  var profitLossList = <ProfitLoss>[].obs;

  calculateProfitLossMonth() {
    purchaseListMonth = controllerIn.purchaseListMonth;
    expensesListMonth = controllerexp.listExpensesMonth;
    salesListMonth = controllerOut.salesListMonth;
    // Create a map to store data for each month
    Map<String, ProfitLoss> profitLossMap = {};

    // Add purchase data to the map
    for (var purchase in controllerIn.purchaseListMonth) {
      profitLossMap.update(
        purchase.type,
        (value) => ProfitLoss(
          month: value.month,
          totalSales: value.totalSales,
          totalExpenses: value.totalExpenses,
          totalPurchases: value.totalPurchases + purchase.totalSales,
        ),
        ifAbsent: () => ProfitLoss(
          month: purchase.type,
          totalPurchases: purchase.totalSales,
          totalSales: 0.0,
          totalExpenses: 0.0,
        ),
      );
    }

    // Add sales data to the map
    for (var sale in controllerOut.salesListMonth) {
      profitLossMap.update(
        sale.type,
        (value) => ProfitLoss(
          month: value.month,
          totalPurchases: value.totalPurchases,
          totalExpenses: value.totalExpenses,
          totalSales: value.totalSales + sale.totalSales,
        ),
        ifAbsent: () => ProfitLoss(
          month: sale.type,
          totalPurchases: 0.0,
          totalSales: sale.totalSales,
          totalExpenses: 0.0,
        ),
      );
    }

    // Add expenses data to the map
    for (var expense in controllerexp.listExpensesMonth) {
      profitLossMap.update(
        expense.type,
        (value) => ProfitLoss(
          month: value.month,
          totalPurchases: value.totalPurchases,
          totalSales: value.totalSales,
          totalExpenses: value.totalExpenses + expense.totalSales,
        ),
        ifAbsent: () => ProfitLoss(
          month: expense.type,
          totalPurchases: 0.0,
          totalSales: 0.0,
          totalExpenses: expense.totalSales,
        ),
      );
    }

    // Convert the map values to a list of ProfitLoss
    profitLossList.value = profitLossMap.values.toList();
    profitLossList.sort((a, b) => a.month.compareTo(b.month));

    // Calculate profit for each month
    for (var profitLoss in profitLossList) {
      profitLoss.calculateProfit();
    }

    for (var month in profitLossList) {
      print('Month: ${month.month} - Total Sales: ${month.profit}');
    }
    listDatesMonth.value =
        profitLossList.map((date) => date.month.toString()).toList();
    listDatesMonth.insert(0, 'Date');

    update();
  }

////////////////////// handle methods /////////////////

  void handleClickExpensesReport(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelExpensesReport(expensesList);
        }
        break;
      case 'Print To Pdf':
        {
          printExpensesReport(expensesList);
        }
        break;
    }
  }

  void handleClickTransactionsReport(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelTransactionsReport(transactionsList);
        }
        break;
      case 'Print To Pdf':
        {
          printTransactionsReport(transactionsList);
        }
        break;
    }
  }

  void handleClickStockMovementReport(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelStockMovementReport(stockMovementList);
        }
        break;
      case 'Print To Pdf':
        {
          printStockMovementsReport(stockMovementList);
        }
        break;
    }
  }

  void handleClickDebtsCustomerReport(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelDebtsCustomerReport(debtsCustomerList);
        }
        break;
      case 'Print To Pdf':
        {
          printDebtsByCustomerReport(debtsCustomerList);
        }
        break;
    }
  }

  void handleClickDebtsSupplierReport(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelDebtsSupplierReport(debtsSupplierList);
        }
        break;
      case 'Print To Pdf':
        {
          printDebtsBySupplierReport(debtsSupplierList);
        }
        break;
    }
  }

  void handleClickSalesCustomerReport(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelSalesCustomerReport(
              controllerOut.salesClientsList);
        }
        break;
      case 'Print To Pdf':
        {
          printSalesByCustomerReport(controllerOut.salesClientsList);
        }
        break;
    }
  }

  void handleClickSalesDateReport(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelSalesDateReport(controllerOut.salesListDay);
        }
        break;
      case 'Print To Pdf':
        {
          printSalesByDateReport(controllerOut.salesListDay);
        }
        break;
    }
  }

  void handleClickSalesMonthReport(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelSalesMonthReport(controllerOut.salesListMonth);
        }
        break;
      case 'Print To Pdf':
        {
          printSalesByMonthReport(controllerOut.salesListMonth);
        }
        break;
    }
  }

  void handleClickSalesItemReport(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelSalesItemReport(controllerOut.salesItemsList);
        }
        break;
      case 'Print To Pdf':
        {
          printSalesByItemReport(controllerOut.salesItemsList);
        }
        break;
    }
  }

  void handleClickprofitsAndLossesReport(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelprofitsAndLossesReport(profitLossList);
        }
        break;
      case 'Print To Pdf':
        {
          printProfitsAndLossesReport(profitLossList);
        }
        break;
    }
  }
}
