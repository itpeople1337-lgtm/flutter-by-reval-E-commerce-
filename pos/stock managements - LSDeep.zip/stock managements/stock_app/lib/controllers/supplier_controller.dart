import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:stock_app/core/functions/export_excel.dart';
import 'package:stock_app/core/functions/prints.dart';
import 'package:stock_app/core/functions/reports/add_report.dart';
import 'package:stock_app/models/supplier_model.dart';
import 'package:stock_app/services/firestore_supplier.dart';
import 'package:url_launcher/url_launcher.dart' as UrlLauncher;
import 'package:url_launcher/url_launcher.dart';

class SupplierController extends GetxController {
  ///////////////////////////
  late String name,
      address,
      email,
      phone,
      textId,
      notes,
      bankDetails,
      customerId;
  var listSuppliers = <SupplierModel>[].obs;
  var filterListSuppliers = <SupplierModel>[].obs;
  final _loading = true.obs;
  get loading => _loading;
  SupplierModel? supplierDetails;

  getSuppliersFromFireStore() async {
    _loading(true);
    var suppliers = await SupplierServices().getSuppliersFromFirestore();
    listSuppliers.assignAll(suppliers);

    _loading(false);
    filterSuppliers('');
    update();
  }

  void filterSuppliers(String searchField) {
    if (searchField.isEmpty) {
      filterListSuppliers.assignAll(listSuppliers);
    } else {
      filterListSuppliers.assignAll(listSuppliers
          .where((exc) =>
              exc.name.toLowerCase().contains(searchField.toLowerCase()))
          .toList());
    }
    update();
  }

  addSupplierToFireStore() async {
    try {
      SupplierModel supplierModel = SupplierModel(
        name: name,
        address: address,
        email: email,
        phone: phone,
        textId: textId,
        notes: notes,
        bankDetails: bankDetails,
        supplierId: '',
      );
      await FirebaseFirestore.instance
          .collection('suppliers')
          .add(supplierModel.toJson());
      addTransactionReport(
          amount: 0,
          type: 'suppliers',
          description: 'new supplier',
          productName: name);
      update();
    } catch (e) {}
  }

  updateSuppliersToFireStore(SupplierModel supplierModel) async {
    await SupplierServices().updateSupplierInFirestore(supplierModel);
  }

  deleteSuppliersToFireStore(String supplierId) async {
    await SupplierServices().deleteSupplierFromFirestore(supplierId);
  }

  void handleClick(String value) {
    switch (value) {
      case 'View Transactions':
        {
          _viewTransactions();
        }
        break;
      case 'Phone Call':
        {
          UrlLauncher.launch('tel:+${phone.toString()}');
        }
        break;
      case 'Send SMS':
        {
          // UrlLauncher.launch('mailto:$sms');
          _textMe();
        }
        break;
      case 'Send Email':
        {
          UrlLauncher.launch('mailto:$email');
        }
        break;
      case 'Whats Up':
        {
          _sendWhatsUp();
        }
        break;
    }
  }

  _textMe() async {
    // Android
    var uri = 'sms:+$phone?body=hello%20there';
    if (await canLaunch(uri)) {
      await launch(uri);
    } else {
      // iOS
      var uri = 'sms:$phone?body=hello%20there';
      if (await canLaunch(uri)) {
        await launch(uri);
      } else {
        throw 'Could not launch $uri';
      }
    }
  }

  _sendWhatsUp() {
    final Uri url = Uri(
      scheme: 'https',
      host: 'wa.me',
      path: '+$phone',
    );
    // UrlLauncher.launch(url);
    launchUrl(url);
  }

  _viewTransactions() {}

  /////////////////////////////////////

  void handleClicklistSuppliers(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelListSuppliers(listSuppliers);
        }
        break;
      case 'Print To Pdf':
        {
          printListSuppliers(listSuppliers);
        }
        break;
    }
  }

  void handleClicksupplierDetails(String value) {
    switch (value) {
      case 'Export To Excel':
        {
          generateAndSaveExcelsupplierDetails(supplierDetails);
        }
        break;
      case 'Print To Pdf':
        {
          printSupplierDetails(supplierDetails);
        }
        break;
    }
  }
}
