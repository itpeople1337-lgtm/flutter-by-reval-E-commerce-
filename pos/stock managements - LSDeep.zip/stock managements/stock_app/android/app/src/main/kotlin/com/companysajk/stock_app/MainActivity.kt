package com.companysajk.stock_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
